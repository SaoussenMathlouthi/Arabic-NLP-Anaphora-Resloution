package classificationSVM;

import java.io.*;

import java.util.*;

import org.jdom2.*;

import java.util.Iterator;

import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.bayes.NaiveBayes;
import weka.classifiers.bayes.NaiveBayesUpdateable;
import weka.classifiers.meta.FilteredClassifier;
import weka.classifiers.trees.J48;
import weka.core.*;
import weka.core.converters.ArffLoader;
import weka.core.FastVector;
import weka.core.Instance;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.Remove;



import org.jdom2.input.*;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

import classificationSVM.ReadTxtFile;
import classificationSVM.MethodeUtile;

import classificationSVM.Mot;



import weka.core.Attribute;

public class ConstructFileArffPrNonRef1 {
  static Instances corpus = null;
  //static int NumPronom=0;
  
  public ConstructFileArffPrNonRef1() {}
  //static Instance inst1 = new DenseInstance(37);
  static List<List<String>> ListParam=LectureFichierTexte.ReadFile("Delimiteur1.txt");
  static List<String> ListDelimiteurSpec=LectureFichierTexte.Parametre(ListParam, 0);
  //static List<String> ListDelimiteurSpec=ListParam.get(0);
  static List<String> ListVerbClimAmb=LectureFichierTexte.Parametre(ListParam, 1);
  //static List<String> ListVerbClimAmb=ListParam.get(1);
  static List<String> ListPartSpec=LectureFichierTexte.Parametre(ListParam, 2);
  //static List<String> ListPartSpec=ListParam.get(2);
  static List<String> ListVerbImpers=LectureFichierTexte.Parametre(ListParam, 3);
  //static List<String> ListVerbImpers=ListParam.get(3);
  static List<String> ListDelimiteurTemps=LectureFichierTexte.Parametre(ListParam, 4);
  //static List<String> ListDelimiteurTemps=ListParam.get(4);
  static List<String> ListDelimPronDemonst=LectureFichierTexte.Parametre(ListParam, 5);
  static List<String> ListDelimiteurJourNuit=LectureFichierTexte.Parametre(ListParam, 6);
  static List<String> ListAdjDef=LectureFichierTexte.LectureChaines("AdjDefini.txt");
  static List<String> ListProverb=LectureFichierTexte.LecturePhrasesProverb("Proverbes.txt");
  static List<InstancePronom> ListInstance=new ArrayList<InstancePronom>();
 
public static Instances CreationCorpus1(String choice, String[] ListTextes){
	  /****
	   * Construction de la liste d'attributs
	   */
	
	  //Mot m=null;
	/*public static Mot m=null;
	 public static Mot mp1=null;
	 public static Mot mp2=null;
	 public static Mot ms1=null;
	 public static Mot ms2=null;
	 public static Mot ms3=null;
	 public static Mot ms4=null;*/

	
	  FastVector attributes = new FastVector(37);
	    FastVector mots1 = new FastVector();
	    mots1 = null;
	    List<String> ListMots=new ArrayList<String>();
	    
	    List<MotProperty> ListWord=null;
	    //List<Mot> ListElementMot=null;
	    //int NumPronom=0;
	    //List<InstancePronom> ListInstanceF=new ArrayList<InstancePronom>();
	   
	    //Attribute Identifiant = new Attribute("ID");
	    /***
	     * Création des attributsmy_nominal_pos du pronom courant: VGRad et VgEnc
	     */
	    FastVector my_nominal_vg = new FastVector(3);
	    for(int i=0;i<224;i++){
	    	my_nominal_vg.addElement(Integer.toString(i));
	    }
	    my_nominal_vg.addElement("");
	    
	    Attribute vgrad = new Attribute("VGRad",my_nominal_vg);
	    //Attribute vgrad = new Attribute("VGRad");
	    
	    FastVector my_nominal_vgenc = new FastVector(3);
	    for(int i=0;i<66;i++){
	    	my_nominal_vgenc.addElement(Integer.toString(i));
	    }
	    my_nominal_vgenc.addElement("");
	    
	    Attribute vgenc = new Attribute("vgEnc",my_nominal_vgenc);
	    //Attribute vgenc = new Attribute("vgEnc");
	    System.out.println(vgrad.toString());

	    /***
	     * Création de l'attribut GenreRad et GenreEnc 
	     */

	    FastVector my_nominal_gen = new FastVector(3);
	    my_nominal_gen.addElement("F");
	    my_nominal_gen.addElement("M");
	    my_nominal_gen.addElement("MF");
	    my_nominal_gen.addElement("MMFF");
	    my_nominal_gen.addElement("Inc");
	    my_nominal_gen.addElement("");
	    Attribute genRad = new Attribute("GenRad", my_nominal_gen);
	    Attribute genEnc = new Attribute("GenEnc", my_nominal_gen);
	    System.out.println(genEnc.toString());

	    /***
	     * Création de l'attribut NombreRad et NombreEnc
	     */

	    FastVector my_nominal_nbr = new FastVector(3);
	    my_nominal_nbr.addElement("S");
	    my_nominal_nbr.addElement("D");
	    my_nominal_nbr.addElement("P");
	    my_nominal_nbr.addElement("SS");
	    my_nominal_nbr.addElement("PP");
	    my_nominal_nbr.addElement("Inc");
	    my_nominal_nbr.addElement("");
	    Attribute nbrRad = new Attribute("NbrRad", my_nominal_nbr);
	    Attribute nbrEnc = new Attribute("NbrEnc", my_nominal_nbr);
	    System.out.println(nbrEnc.toString());
	    
	    FastVector my_nominal_classe = new FastVector(1);
	    my_nominal_classe.addElement("0");
	    my_nominal_classe.addElement("1");

	    /***
	     * Création de l'attribut classe
	     */

	    Attribute classe = new Attribute("classe", my_nominal_classe);
	   
	    /*****
	     * attributs contextuels à une fenêtre [-2,+4]
	     */

	    /***
	     * Création des attributs du mot précédent 1
	     */

	    //Attribute MotPrec = new Attribute("MotPrec", mots1);
	    //Attribute RadPrec = new Attribute("RadPrec", mots1);
	    Attribute VgPrec1 = new Attribute("VgPrec1",my_nominal_vg);
	    Attribute genPrec1 = new Attribute("GenPrec1", my_nominal_gen);
	    Attribute nbrPrec1 = new Attribute("NbrPrec1", my_nominal_nbr);
	    
	    
	    /***
	     * Création des attributs du mot précédent 2
	     */
	    Attribute VgPrec2 = new Attribute("VgPrec2",my_nominal_vg);
	    Attribute genPrec2 = new Attribute("GenPrec2", my_nominal_gen);
	    Attribute nbrPrec2 = new Attribute("NbrPrec2", my_nominal_nbr);
	    /***
	     * Création des attributs du mot suivant n°1
	     */
	     
	    Attribute VgSuiv1 = new Attribute("VgSuiv1",my_nominal_vg);
	    Attribute genSuiv1 = new Attribute("GenSuiv1", my_nominal_gen);
	    Attribute nbrSuiv1 = new Attribute("NbrSuiv1", my_nominal_nbr);
	    
	    /***
	     * Création des attributs du mot suivant n°2
	     */

	    Attribute VgSuiv2 = new Attribute("VgSuiv2",my_nominal_vg);
	    Attribute genSuiv2 = new Attribute("GenSuiv2", my_nominal_gen);
	    Attribute nbrSuiv2 = new Attribute("NbrSuiv2", my_nominal_nbr);
	    
	    /***
	     * Création des attributs du mot suivant n°3
	     */

	    Attribute VgSuiv3 = new Attribute("VgSuiv3",my_nominal_vg);
	    Attribute genSuiv3 = new Attribute("GenSuiv3", my_nominal_gen);
	    Attribute nbrSuiv3 = new Attribute("NbrSuiv3", my_nominal_nbr);

	    /***
	     * Création des attributs du mot suivant n°4
	     */

	    /*Attribute VgSuiv4 = new Attribute("VgSuiv4",my_nominal_vg);
	    Attribute genSuiv4 = new Attribute("GenSuiv4", my_nominal_gen);
	    Attribute nbrSuiv4 = new Attribute("NbrSuiv4", my_nominal_nbr);*/
	    
	    //Création de l'attribut position
	    FastVector my_nominal_pos = new FastVector(3);
	    for(int i=0;i<80;i++){
	    	my_nominal_pos.addElement(Integer.toString(i));
	    }
	    my_nominal_pos.addElement("");
	    Attribute posPron = new Attribute("PosPronoun",my_nominal_pos);
	    //Attribute posPron = new Attribute("PosPronoun");
	    
	    //Création de l'attribut existance delimiteur spécifique
	    FastVector my_nominal_test = new FastVector(1);
	    my_nominal_test.addElement("0");
	    my_nominal_test.addElement("1");
	    Attribute existDelim = new Attribute("SpecifDelimiter", my_nominal_test);
	    
	    //Création de l'attribut distance
	    Attribute distPrDelim = new Attribute("DistPronDelim",my_nominal_pos);
	    //Attribute distPrDelim = new Attribute("DistPronDelim");
	    
	  //Création de l'attribut Accord
	    //Attribute agreeGNP = new Attribute("AgreeGNP", my_nominal_test);
	    
	  //Création de l'attribut existance d'un nom suivant le pronom
	    Attribute followNoun = new Attribute("FollowNoun", my_nominal_test);
	    
	  //Création de l'attribut existance d'une particule spécifique suivant le pronom
	    Attribute followPartSpec = new Attribute("FollowPartSpec", my_nominal_test);
	    
	  //Création de l'attribut existance d'un verbe impersonnel après le pronom
	    Attribute impersonalVerb = new Attribute("ImpersonalVerb", my_nominal_test);
	  //Création de l'attribut existance d'un verbe impersonnel après le pronom
	    Attribute PronDemonst = new Attribute("PronDemonstratif", my_nominal_test);
	    
	  //Création de l'attribut existance d'un patron non-referentiel
	    Attribute rules1 = new Attribute("Rules1", my_nominal_test);
	  //Création de l'attribut existance d'un patron non-referentiel
	    Attribute rules2 = new Attribute("Rules2", my_nominal_test);
	  //Création de l'attribut existance d'un patron non-referentiel
	    Attribute rules3 = new Attribute("Rules3", my_nominal_test);
	  //Création de l'attribut existance d'un patron non-referentiel
	    Attribute rules4 = new Attribute("Rules4", my_nominal_test);
	  //Création de l'attribut existance d'un patron non-referentiel
	    Attribute rules5 = new Attribute("Rules5", my_nominal_test);
	  //Création de l'attribut existance d'un patron non-referentiel
	    Attribute rules6 = new Attribute("Rules6", my_nominal_test);
	    //Création de l'attribut existance d'un patron non-referentiel
	    Attribute rules7 = new Attribute("Rules7", my_nominal_test);
	    //Création de l'attribut existance d'un patron non-referentiel
	    Attribute proverb = new Attribute("Proverb", my_nominal_test);
	    

	    /***
	     * Création du vecteur des attributs
	     */

	   //attributes.addElement(motin);
	   //attributes.addElement(Identifiant);
	   
	   attributes.addElement(vgrad);
	   attributes.addElement(genRad);
	   attributes.addElement(nbrRad);
	   attributes.addElement(vgenc);
	   attributes.addElement(genEnc);
	   attributes.addElement(nbrEnc);
	  
	   attributes.addElement(VgPrec1);
	   attributes.addElement(genPrec1);
	   attributes.addElement(nbrPrec1);
	   
	   attributes.addElement(VgPrec2);
	   attributes.addElement(genPrec2);
	   attributes.addElement(nbrPrec2);
	   
	   attributes.addElement(VgSuiv1);
	   attributes.addElement(genSuiv1);
	   attributes.addElement(nbrSuiv1);
	   
	   attributes.addElement(VgSuiv2);
	   attributes.addElement(genSuiv2);
	   attributes.addElement(nbrSuiv2);
	   
	   attributes.addElement(VgSuiv3);
	   attributes.addElement(genSuiv3);
	   attributes.addElement(nbrSuiv3);
	   
	   /*attributes.addElement(VgSuiv4);
	   attributes.addElement(genSuiv4);
	   attributes.addElement(nbrSuiv4);*/
	   
	   attributes.addElement(posPron);
	   attributes.addElement(existDelim);
	   attributes.addElement(distPrDelim);
	   //attributes.addElement(agreeGNP);
	   attributes.addElement(followNoun);
	   attributes.addElement(followPartSpec);
	   attributes.addElement(impersonalVerb);
	   attributes.addElement(PronDemonst);
	   attributes.addElement(rules1);
	   attributes.addElement(rules2);
	   attributes.addElement(rules3);
	   attributes.addElement(rules4);
	   attributes.addElement(rules5);
	   attributes.addElement(rules6);
	   attributes.addElement(rules7);
	   attributes.addElement(proverb);
	   
	   attributes.addElement(classe);

	    /***
	     * 
	     */
	    
	    corpus = new Instances("Corpus", attributes, 0);
	    String texte=new String();
	    int nbr_mots=0;
	    // Make position the class attribute
	    corpus.setClass(classe);
	    for(int t=0;t<ListTextes.length;t++){
	    	//texte="test2SegV4Res.xml";
	    	texte=ListTextes[t];
	    	System.out.println("+++++++++++++++++++++++++++++++++++"+texte);
	    	//String texteDonne="texte"+Integer.toString(t);
	    	ListMots=new ArrayList<String>();
	    	//String [] ListMotsComp=new String[100];
	    	//ListElementMot=new ArrayList<Mot>();
		 	Texte txt = new Texte();
			  txt.nomfichier=texte;
			  List parags = txt.ExtractParagraphe();
			  for(int p=0;p<parags.size();p++){
				  System.out.println("nbr parags:"+parags.size());
				  Paragraphe parag=new Paragraphe();
				  parag.paragraphe=(Element)parags.get(p);
				  List phs=parag.ExtrairePhrases();
				  System.out.println("nbr phrase:"+phs.size());
				  //Iterator i = phs.iterator();
				  //while(i.hasNext()){
				  String clas = new String();
				  for(int i=0;i<phs.size();i++){
				    Phrase ph = new Phrase();
				    ph.phrase=(Element)phs.get(i);
				    System.out.println(ph.TextePhrase());
				    List mots=ph.ExtraireMots();
				    String[] dataWord =ph.TextePhrase().split(" ");
				    if(mots.size()==0){
				    	mots=ph.ExtraireMots2();
				    }
					ListMots=Remplir_Liste(ph);
					//ListMotsComp=Remplir_Liste2(ph);
				    System.out.println("taille phrase:"+mots.size());
				   
			    	//ListElementMot=new ArrayList<Mot>();
				    for(int j=0;j<mots.size();j++){
				    	nbr_mots++;
				    	ListWord=new ArrayList<MotProperty>();
				    	Mot m = null;
				    	//ListWord=new ArrayList<String>();
				    	m=new Mot();
						m.mot=(Element)mots.get(j);
						MotProperty w=new MotProperty(m.ExtraireVGRad(),m.ExtraireValeur(),m.ExtraireRad(),m.ExtraireGenre(),m.ExtraireNombre(),
								m.ExtraireVGEnc(),m.ExtraireValEnc(),m.ExtraireGenreanaph(),m.ExtraireNbranaph(),m.ExtraireVGProc());
						
						//ListWord.add(w);
						//ListWord.add(m.ExtraireValeur()+"/"+m.ExtraireVGRad()+"/"+m.ExtraireGenre()+"/"+m.e);
						//vg1=m.ExtraireVGRad();gen1=m.ExtraireGenre();nbr1=m.e
						//ListElementMot.add(m);
						
						
						//if(TypeAnaphore2(m).equals("Pronom personnel attaché")){
						if(!MethodeUtile.TypeAnaphore1(m).equals("")){
							Instance inst1 = new DenseInstance(37);
							System.out.println("mot courant:"+m.ExtraireValeur()+" vg courant:"+m.ExtraireVGRad());
							//String ident="Id"+Integer.toString(NumPronom);
							//inst1.setValue(Identifiant,ident);
							//inst1.setValue(Identifiant,NumPronom);
							//NumPronom++;
							//InstancePronom Inst= new InstancePronom(ident,texte,p,i,j);
							//InstancePronom Inst= new InstancePronom(NumPronom,texte,p,i,j);
							//ListInstance.add(Inst);
							String Ref=m.ExtraireRefAnaph();
							System.out.println("*********référentiel "+Ref);
							if(choice.equals("Etiq")){
								if(Ref.equals("non")){
									inst1.setValue(classe, "0");System.out.println("nouveau instance Non Referentiel");//inst1.setValue(classe, "NonRef");
								}
								else if(Ref.equals("oui")) {inst1.setValue(classe, "1");}//inst1.setValue(classe, "Ref");
							}
							else {inst1.setMissing(classe);System.out.println("non etiquete");}
							
							inst1.setValue(vgrad,"");
							inst1.setValue(genRad,"");
							inst1.setValue(nbrRad,"");
							inst1.setValue(vgenc,"");
							inst1.setValue(genEnc,"");
							inst1.setValue(nbrEnc,"");
							
							inst1.setValue(VgPrec1,"");
							inst1.setValue(genPrec1,"");
							inst1.setValue(nbrPrec1,"");
							inst1.setValue(VgPrec2,"");
							inst1.setValue(genPrec2,"");
							inst1.setValue(nbrPrec2,"");
							inst1.setValue(VgSuiv1,"");
							inst1.setValue(genSuiv1,"");
							inst1.setValue(nbrSuiv1,"");
							inst1.setValue(VgSuiv2,"");
							inst1.setValue(genSuiv2,"");
							inst1.setValue(nbrSuiv2,"");
							inst1.setValue(VgSuiv3,"");
							inst1.setValue(genSuiv3,"");
							inst1.setValue(nbrSuiv3,"");
							/*inst1.setMissing(vgrad);
							inst1.setMissing(genRad);
							inst1.setMissing(nbrRad);
							inst1.setMissing(vgenc);
							inst1.setMissing(genEnc);
							inst1.setMissing(nbrEnc);
							
							inst1.setMissing(VgPrec1);
							inst1.setMissing(genPrec1);
							inst1.setMissing(nbrPrec1);
							inst1.setMissing(VgPrec2);
							inst1.setMissing(genPrec2);
							inst1.setMissing(nbrPrec2);
							inst1.setMissing(VgSuiv1);
							inst1.setMissing(genSuiv1);
							inst1.setMissing(nbrSuiv1);
							inst1.setMissing(VgSuiv2);
							inst1.setMissing(genSuiv2);
							inst1.setMissing(nbrSuiv2);
							inst1.setMissing(VgSuiv3);
							inst1.setMissing(genSuiv3);
							inst1.setMissing(nbrSuiv3);*/
							
							inst1.setValue(rules1,"0");
							inst1.setValue(rules2,"0");
							inst1.setValue(rules3,"0");
							inst1.setValue(rules4,"0");
							inst1.setValue(rules5,"0");
							inst1.setValue(rules6,"0");
							inst1.setValue(rules7,"0");
							
							if(ListProverb.contains(ph.TextePhrase()))
								{inst1.setValue(proverb, "1");System.out.println("c'est un proverbe");}
							else inst1.setValue(proverb, "0");
							//inst1.setValue(motin, m.ExtraireValeur());
							//inst1.setValue(rad, FiltreRad(m.ExtraireRad()));
							//inst1.setValue(lem, m.ExtraireLem());									//les caractéristiques morphsyntaxiques des mots aux alentours du pronom
							//if(!m.ExtraireVGRad().equals(""))										
								inst1.setValue(vgrad, m.ExtraireVGRad());
							//else inst1.setValue(vgrad, "0");
							//inst1.setValue(enc, m.ExtraireValEnc());
							//if(!m.ExtraireVGEnc().equals(""))										//...
								inst1.setValue(vgenc, m.ExtraireVGEnc());
							//else inst1.setValue(vgenc, "0");//else inst1.setMissing(vgenc);
							//if(!m.ExtraireGenre().equals(""))
								inst1.setValue(genRad, m.ExtraireGenre());
							//else inst1.setValue(genRad, "Inc");//else inst1.setMissing(genRad);
							//if(!m.ExtraireNombre().equals(""))
								inst1.setValue(nbrRad, m.ExtraireNombre());
							//else inst1.setValue(nbrRad, "Inc");//else inst1.setMissing(nbrRad);
							//if(!m.ExtraireGenreanaph().equals(""))
								inst1.setValue(genEnc, m.ExtraireGenreanaph());
							//else inst1.setValue(genEnc, "Inc");//else inst1.setMissing(genEnc);
							//if(!m.ExtraireNbranaph().equals(""))
								inst1.setValue(nbrEnc, m.ExtraireNbranaph());
							//else inst1.setValue(nbrEnc, "Inc");//else inst1.setMissing(nbrEnc);
							
							if(m.ExtraireVGRad().equals("10") && !m.ExtraireValeur().equals("hNlk"))										
								inst1.setValue(PronDemonst, "1");
							else inst1.setValue(PronDemonst, "0");
							
							//System.out.println("num mot "+m.ExtraireNum());
							if(!m.ExtraireNum().equals(""))
								inst1.setValue(posPron,m.ExtraireNum());
							else inst1.setMissing(posPron);
							
								
							if(PosDelimiteur(ListMots)>Integer.parseInt(m.ExtraireNum()))		//Attribut Distance pronom 1er delimiteur
									inst1.setValue(distPrDelim,Integer.toString(Integer.parseInt(m.ExtraireNum())-PosDelimiteur(ListMots)));
							else inst1.setMissing(distPrDelim);
							//if(PosDelimiteurPart(ListMots)>Integer.parseInt(m.ExtraireNum()))
							//{inst1.setValue(distPrDelim,Integer.toString(Integer.parseInt(m.ExtraireNum())-PosDelimiteurPart(ListMots)));}
							
							/*if(AccordGNP(m,mots,j))										//Attribut accord Genre nombre entre pronom et 1er verbe suivant
								inst1.setValue(agreeGNP,1);
							else
								inst1.setValue(agreeGNP,0);*/
							
							if(ExisteVerbImp(mots,j))
								{inst1.setValue(impersonalVerb,"1");System.out.println("Existe verbe impersonnel");}
							else
								inst1.setValue(impersonalVerb,"0");
							
							if(j>0){	
								Mot mp1 = null;
								mp1=new Mot();
								mp1.mot=(Element)mots.get(j-1);
								//ListElementMot.add(m);
								MotProperty wp1=new MotProperty(mp1.ExtraireVGRad(),mp1.ExtraireValeur(),mp1.ExtraireRad(),mp1.ExtraireGenre(),mp1.ExtraireNombre(),
										mp1.ExtraireVGEnc(),mp1.ExtraireValEnc(),mp1.ExtraireGenreanaph(),mp1.ExtraireNbranaph(),mp1.ExtraireVGProc());
								Afficher(wp1);
								//ListWord.add(wp1);
								//System.out.println("vg pr:"+ListWord.get(1).getVg()+" vg cour:"+ListWord.get(0).getVg());
								//System.out.println("word "+wp1.getRad()+" "+w.getRad());
								//System.out.println("mot "+mp1.ExtraireRad()+" "+m.ExtraireRad());
								//inst1.setValue(MotPrec, mp.ExtraireValeur());
								//inst1.setValue(RadPrec, FiltreRad(mp.ExtraireRad()));
								//if(!mp1.ExtraireVGRad().equals(""))
									inst1.setValue(VgPrec1, mp1.ExtraireVGRad());
								//else inst1.setValue(VgPrec1, "0");//else inst1.setMissing(VgPrec1);
								//if(!mp1.ExtraireGenre().equals(""))
									inst1.setValue(genPrec1, mp1.ExtraireGenre());
								//else inst1.setValue(genPrec1, "Inc");//else inst1.setMissing(genPrec1);
								//if(!mp1.ExtraireNombre().equals(""))
									inst1.setValue(nbrPrec1, mp1.ExtraireNombre());
								//else inst1.setValue(nbrPrec1, "Inc");//else inst1.setMissing(nbrPrec1);
								//m.mot=(Element)mots.get(j);
								//mp1.mot=(Element)mots.get(j-1);
								//System.out.println("++vg preced:"+mp1.ExtraireVGRad());
								//System.out.println("++vg courant:"+m.ExtraireVGRad());
								//System.out.println(ListWord.get(0)+" "+ListWord.get(1));
								if(Patron7(wp1,w)||Patron7_3(wp1,w)){
									inst1.setValue(rules6,"1");	System.out.println("Existe Patron 7 ou 7_3!!!!");	}		//Attribut existe delimiteur
									
								if(j>1){
									Mot mp2 = null;
									mp2=new Mot();
									mp2.mot=(Element)mots.get(j-2);
									MotProperty wp2=new MotProperty(mp2.ExtraireVGRad(),mp2.ExtraireValeur(),mp2.ExtraireRad(),mp2.ExtraireGenre(),mp2.ExtraireNombre(),
											mp2.ExtraireVGEnc(),mp2.ExtraireValEnc(),mp2.ExtraireGenreanaph(),mp2.ExtraireNbranaph(),mp2.ExtraireVGProc());
									Afficher(wp2);
									//if(!mp2.ExtraireVGRad().equals(""))
										inst1.setValue(VgPrec2, mp2.ExtraireVGRad());
									//else inst1.setValue(VgPrec2, "0");//else inst1.setMissing(VgPrec2);
									//if(!mp2.ExtraireGenre().equals(""))
										inst1.setValue(genPrec2, mp2.ExtraireGenre());
									//else inst1.setValue(genPrec2, "Inc");//else inst1.setMissing(genPrec2);
									//if(!mp2.ExtraireNombre().equals(""))
										inst1.setValue(nbrPrec2, mp2.ExtraireNombre());
									//else inst1.setValue(nbrPrec2, "Inc");//else inst1.setMissing(nbrPrec2);
									if(Patron7_1(wp2,wp1,w)||Patron7_2(wp2,wp1,w)){
										inst1.setValue(rules6,"1");	System.out.println("Existe Patron 7_1 ou 7_2 !!!!");	}		//Attribut existe delimiteur
									
									if(Patron9(wp2,wp1,w)){
										inst1.setValue(rules7,"1");	System.out.println("Existe Patron 9!!!!");	}		//Attribut existe delimiteur
									
								}
							}
							
								
							if(j+1<mots.size()){
								Mot ms1 = null;
								ms1=new Mot();
								ms1.mot=(Element)mots.get(j+1);
								MotProperty ws1=new MotProperty(ms1.ExtraireVGRad(),ms1.ExtraireValeur(),ms1.ExtraireRad(),ms1.ExtraireGenre(),ms1.ExtraireNombre(),
										ms1.ExtraireVGEnc(),ms1.ExtraireValEnc(),ms1.ExtraireGenreanaph(),ms1.ExtraireNbranaph(),ms1.ExtraireVGProc());
								Afficher(ws1);
								//.setValue(MotSuiv1, ms1.ExtraireValeur());
								//inst1.setValue(RadSuiv1, FiltreRad(ms1.ExtraireRad()));
								//if(!ms1.ExtraireVGRad().equals(""))
									inst1.setValue(VgSuiv1, ms1.ExtraireVGRad());
								//else inst1.setValue(VgSuiv1, "0");//else inst1.setMissing(VgSuiv1);
								//if(!ms1.ExtraireGenre().equals(""))
									inst1.setValue(genSuiv1, ms1.ExtraireGenre());
								//else inst1.setValue(genSuiv1, "Inc");//else inst1.setMissing(genSuiv1);
								//if(!ms1.ExtraireNombre().equals(""))
									inst1.setValue(nbrSuiv1, ms1.ExtraireNombre());
								//else inst1.setValue(nbrSuiv1, "Inc");//else inst1.setMissing(nbrSuiv1);
								
								if(!ws1.getRad().equals("")){
									if(EstunNomNominatif(ws1.getVg()))					//Attribut existe nom suivant
										inst1.setValue(followNoun,"1");
									else
										inst1.setValue(followNoun,"0");
								}
								else inst1.setMissing(followNoun);
								
								if(Delimiter(FiltreRad(ws1.getRad()),ListPartSpec)) 	//Attribut existe particule spécifique
									{inst1.setValue(followPartSpec,"1");System.out.println("Existe particule spécifique");}
								else
									inst1.setValue(followPartSpec,"0");
								if(EstunModificateur(FiltreRad(w.getRad()), w.getVg())){
									//System.out.println("Recherche patron?");
									Afficher(w);Afficher(ws1);
									if(Patron8(w,ws1))
										{inst1.setValue(rules2,"1");	System.out.println("Existe Patron 8!!!!");	}			//Attribut existe delimiteur
									
									if(Patron4(w,ws1))
										{inst1.setValue(rules4,"1");	System.out.println("Existe Patron 4 !!!!");	}			//Attribut existe delimiteur
									
									if(dataWord.length>=2){
										if(Patron6_1(w,ws1,dataWord[j+2]))
											{inst1.setValue(rules5,"1");	System.out.println("Existe Patron 6_1 !!!!");	}
									}//Attribut existe delimiteur
																		
								}
								else if(w.getVg().equals("94")){		//pronom personnel isolé
									if(Patron4_1(w,ws1))
									{inst1.setValue(rules4,"1");	System.out.println("Existe Patron 4_1 !!!!");	}			//Attribut existe delimiteur
								
								}
								//System.out.println("Chercher patron 9"+w.getRad()+" "+ws1.getRad());
								else if(w.getVg().equals("10")){
									System.out.println("Chercher patron 9"+w.getRad()+" "+ws1.getRad());
									if(Patron9_1(w,ws1)){
										{inst1.setValue(rules7,"1");	System.out.println("Existe Patron 9_1 !!!!");	}
									}
								}
								
								if(j+2<mots.size()){
									Mot ms2 = null;
									ms2=new Mot();
									ms2.mot=(Element)mots.get(j+2);
									MotProperty ws2=new MotProperty(ms2.ExtraireVGRad(),ms2.ExtraireValeur(),ms2.ExtraireRad(),ms2.ExtraireGenre(),ms2.ExtraireNombre(),
											ms2.ExtraireVGEnc(),ms2.ExtraireValEnc(),ms2.ExtraireGenreanaph(),ms2.ExtraireNbranaph(),ms2.ExtraireVGProc());
									//inst1.setValue(MotSuiv2, ms2.ExtraireValeur());
									//inst1.setValue(RadSuiv2, FiltreRad(ms2.ExtraireRad()));
									//if(!ms2.ExtraireVGRad().equals(""))
										inst1.setValue(VgSuiv2, ms2.ExtraireVGRad());
									//else inst1.setValue(VgSuiv2, "0");//else inst1.setMissing(VgSuiv2);
									//if(!ms2.ExtraireGenre().equals(""))
										inst1.setValue(genSuiv2, ms2.ExtraireGenre());
									//else inst1.setValue(genSuiv2, "Inc");//else inst1.setMissing(genSuiv2);
									//if(!ms2.ExtraireNombre().equals(""))
										inst1.setValue(nbrSuiv2, ms2.ExtraireNombre());
									//else inst1.setValue(nbrSuiv2, "Inc");//else inst1.setMissing(nbrSuiv2);
									
									if(Delimiter(FiltreRad(ws1.getRad())+ " " +FiltreRad(ws2.getRad()),ListDelimiteurSpec))
										inst1.setValue(existDelim,"1");				//Attribut existe delimiteur
									else
										inst1.setValue(existDelim,"0");
									//System.out.println("vg courant:"+m.ExtraireVGRad());
									//System.out.println("suiv1:"+ms1.ExtraireValeur()+" suiv2:"+ms2.ExtraireValeur());
									if(EstunModificateur(FiltreRad(w.getRad()), w.getVg())){
										if(Patron1_1(w,ws1,ws2))
										{inst1.setValue(rules1,"1");	System.out.println("Existe Patron 1!!!!");	}			//Attribut existe delimiteur
								
									if(Patron2(w,ws1,ws2))
										{inst1.setValue(rules2,"1");	System.out.println("Existe Patron 2 !!!!");	}			//Attribut existe delimiteur
									
									if(Patron3(w,ws1,ws2)||Patron3_2(w,ws1,ws2))
									{inst1.setValue(rules3,"1");	System.out.println("Existe Patron 3!!!!");	}			//Attribut existe delimiteur
									
									if(Patron5(w,ws1,ws2)||Patron6(w,ws1,ws2)||Patron6_2(w,ws1,ws2))
										{inst1.setValue(rules5,"1");	System.out.println("Existe Patron 5 ou 6!!!!");	}			//Attribut existe delimiteur
									
									}
									
									
									if(j+3<mots.size()){
										Mot ms3 = null;
										ms3=new Mot();
										ms3.mot=(Element)mots.get(j+3);
										MotProperty ws3=new MotProperty(ms3.ExtraireVGRad(),ms3.ExtraireValeur(),ms3.ExtraireRad(),ms3.ExtraireGenre(),ms3.ExtraireNombre(),
												ms3.ExtraireVGEnc(),ms3.ExtraireValEnc(),ms3.ExtraireGenreanaph(),ms3.ExtraireNbranaph(),ms3.ExtraireVGProc());
										//inst1.setValue(MotSuiv3, ms3.ExtraireValeur());
										//inst1.setValue(RadSuiv3, FiltreRad(ms3.ExtraireRad()));
										//if(!ms3.ExtraireVGRad().equals(""))
											inst1.setValue(VgSuiv3, ms3.ExtraireVGRad());
										//else inst1.setValue(VgSuiv3, "0");//else inst1.setMissing(VgSuiv3);
										//if(!ms3.ExtraireGenre().equals(""))
											inst1.setValue(genSuiv3, ms3.ExtraireGenre());
										//else inst1.setValue(genSuiv3, "Inc");//else inst1.setMissing(genSuiv3);
										//if(!ms3.ExtraireNombre().equals(""))
											inst1.setValue(nbrSuiv3, ms3.ExtraireNombre());
										//else inst1.setValue(nbrSuiv3, "Inc");//else inst1.setMissing(nbrSuiv3);
										if(EstunModificateur(FiltreRad(w.getRad()), w.getVg())){
											if(Patron1_2(w,ws1,ws2,ws3)||Patron1_3(w,ws1,ws2,ws3))
												{inst1.setValue(rules1,"1");	System.out.println("Existe Patron 1");}			
											//else
												//inst1.setValue(rules1,0);
										}
									
										if(j+4<mots.size()){
											Mot ms4 = null;
											ms4=new Mot();
											ms4.mot=(Element)mots.get(j+4);
											MotProperty ws4=new MotProperty(ms4.ExtraireVGRad(),ms4.ExtraireValeur(),ms4.ExtraireRad(),ms4.ExtraireGenre(),ms4.ExtraireNombre(),
													ms4.ExtraireVGEnc(),ms4.ExtraireValEnc(),ms4.ExtraireGenreanaph(),ms4.ExtraireNbranaph(),ms4.ExtraireVGProc());
											//inst1.setValue(MotSuiv4, ms4.ExtraireValeur());
											//inst1.setValue(RadSuiv4, FiltreRad(ms4.ExtraireRad()));
											/*if(!ms4.ExtraireVGRad().equals(""))
												inst1.setValue(VgSuiv4, ms4.ExtraireVGRad());
											else inst1.setMissing(VgSuiv4);
											if(!ms4.ExtraireGenre().equals(""))
												inst1.setValue(genSuiv4, ms4.ExtraireGenre());
											else inst1.setMissing(genSuiv4);
											if(!ms4.ExtraireNombre().equals(""))
												inst1.setValue(nbrSuiv4, ms4.ExtraireNombre());
											else inst1.setMissing(nbrSuiv4);*/
											if(EstunModificateur(FiltreRad(w.getRad()), w.getVg())){
												if(Patron5_1(w,ws1,ws2,ws3,ws4))
													{inst1.setValue(rules5,"1");System.out.println("Existe Patron 5_1!!!!");}				//Attribut existe delimiteur
												
											}
										}
									}
								}
							}
							
							
						    inst1.setDataset(corpus);
						    corpus.add(inst1);
						    System.out.println("Nouvelle instance ajoutée");
					    }
				    }
				  } 
			  }
	    }
	    //ListInstanceF.addAll(ListInstance);
	  System.out.println("Nombre des mots: "+nbr_mots);
	  Instances inst = new Instances(corpus);
	  System.out.println("Nombre des attributs: " + inst.numAttributes());
	  System.out.println("Nombre des instances Data: " + inst.numInstances());
	  System.out.println("Nombre de classe: " + inst.numClasses());
	  

	  return corpus;
	}

public static void CreerFichier(String texte){
  try{
    //BufferedWriter writer = new BufferedWriter(new FileWriter(
        //texte.substring(0, texte.indexOf(".")).concat(".arff")));
	BufferedWriter writer = new BufferedWriter(new FileWriter(
      texte.concat(".arff")));
    writer.write(corpus.toString());
    System.out.println("corpus créé avec succès " + corpus.numInstances());
    writer.flush();
    writer.close();
  }
  catch (Exception e){System.out.println(e);}

}
static void enregistre(String fichier,Document document)
{
   try
   {
      
      XMLOutputter sortie = new XMLOutputter(Format.getPrettyFormat());
      
      
      sortie.output(document, new FileOutputStream(fichier));
   }
   catch (java.io.IOException e){}
}
public static void Resultat(Evaluation eval,String nom) throws JDOMException, IOException{

	SAXBuilder builder = new SAXBuilder();
    Document document = builder.build(new File("resultat.xml"));
    Element racine = document.getRootElement();
    
	  Element resultat = new Element("resultat");
	  racine.addContent(resultat);
	  resultat.setAttribute("Nom",nom);
	  Element table4 = new Element("numberofcorrectlyclassifiedinstances");
	  resultat.addContent(table4);
	  String kk=String.valueOf(eval.correct());
	  table4.addContent(kk);
	  Element table = new Element("CorrectlyClassifiedInstances");
	  resultat.addContent(table);
	  String pc=String.valueOf(eval.pctCorrect()); 
	  table.addContent(pc);
	  Element table1 = new Element("numberofIncorrectlyClassifiedInstances");
	  resultat.addContent(table1);
	  String hh=String.valueOf(eval.incorrect());
	  table1.addContent( hh);
	  Element table2 = new Element("IncorrectlyClassifiedInstances");
	  resultat.addContent(table2);
	  String pic=String.valueOf(eval.pctIncorrect()); 
	  table2.addContent(pic);
	  XMLOutputter sortie = new XMLOutputter(Format.getPrettyFormat());
	  sortie.output(document, new FileOutputStream("resultat.xml"));
	
}
public static List<String> Remplir_Liste(Phrase phr){
	List<String> ListMots=new ArrayList<String>();
	List Mots=phr.ExtraireMots();
	if(Mots.size()==0)
		Mots=phr.ExtraireMots2();
	//System.out.println("taille liste:"+Mots.size());
	for(int i=0;i<Mots.size();i++){
		Mot mt=new Mot();
		mt.mot=(Element) Mots.get(i);
		//System.out.println("lem mot:"+mt.ExtraireRad2());
		ListMots.add(mt.ExtraireRad());
	}
	/*System.out.println("Afficher Liste");
	for(int a=0;a<ListMots.size();a++){
		System.out.println(ListMots.get(a)+" ");
	}*/
	return ListMots;
}

public static void Afficher_Liste(List<String> ListMots){
	//System.out.println("Taille de la liste:"+ListMots.size());
	//System.out.println("Affichage");
	for(int a=0;a<ListMots.size();a++){
		System.out.println(ListMots.get(a)+" ");
	}
}
public static void Afficher(MotProperty w){
	System.out.print(w.getRad()+" ");System.out.print(w.getVg()+" "); System.out.print(w.getGenr()+" ");
	 System.out.print(w.getVal()+" "); System.out.print(w.getVgenc()+" ");System.out.println();
}
public static boolean ExisteVerbImp(List mots, int j){
	boolean exist=false;
	int i=j+1;
	while(i<mots.size() && !exist){
		Mot mc=new Mot();
		mc.mot=(Element)mots.get(i);
		if(Delimiter(FiltreRad(mc.ExtraireRad()),ListVerbImpers))
			exist=true;
		i++;
	}
	return exist;
}
public static boolean EstunNom(String VG){
	boolean x=false;
	if(!VG.equals("")){
			int vg=Integer.parseInt(VG);
		if ((vg>=19 && vg<=57)||(vg>=193 && vg<=197))
			x=true;
	}
	return x;
}
public static boolean EstunNomNominatif(String VG){
	boolean x=false;
	if(!VG.equals("")){
			int vg=Integer.parseInt(VG);
		if (vg==20||vg==23||vg==27||vg==30||vg==34||vg==37||vg==39||vg==40||vg==41
				||vg==44||vg==45||vg==49||vg==52||vg==56||vg==194)
			x=true;
	}
	return x;
}
public static boolean AccordGNP(Mot m, List mots, int pos){
	boolean test=false;
	boolean existVerb=false;
	int i=pos+1;
	Mot mc=new Mot();
	while(i<mots.size() && !existVerb ){
		mc=new Mot();
		mc.mot=(Element)mots.get(i);
		if(!mc.ExtraireVGRad().equals("")){
			if(EstunVerbe(mc.ExtraireVGRad()))
				existVerb=true;
		}
		i++;
	}
	if(existVerb){
		if((mc.ExtraireGenre().equals(m.ExtraireGenre()) && mc.ExtraireNombre().equals(m.ExtraireNombre()))||
				(mc.ExtraireGenre().equals(m.ExtraireGenreanaph()) && mc.ExtraireNombre().equals(m.ExtraireNbranaph())))
			test=true;
	}
	return test;
}
public static int PosDelimiteur(List<String> Mots){
	int pos=-1;
	int i=0;
	String Val1=new String();
	String Val2=new String();
	while(i<(Mots.size()-1) && pos==-1){
		Val1=(String) Mots.get(i);
		Val2=(String) Mots.get(i+1);
		//System.out.println("iteration "+i+" mot1:"+Val1+" mot2:"+Val2);
		if(!Val1.equals("") && !Val2.equals("")){
			//System.out.println(FiltreRad(Val1)+ " " +FiltreRad(Val2));
			if(Delimiter(FiltreRad(Val1)+ " " +FiltreRad(Val2),ListDelimiteurSpec)){
				pos=i;
				
				System.out.println("Existe Délimiteur");
			}
		}
		i++;
	}
	return pos;
}
public static int PosDelimiteurPart(List<String> Mots){
	int pos=-1;
	int i=0;
	String Val1=new String();
	
	while(i<(Mots.size()-1) && pos==-1){
		Val1=(String) Mots.get(i);
		
		//System.out.println("iteration "+i+" mot1:"+Val1+" mot2:"+Val2);
		if(!Val1.equals("")){
			//System.out.println(FiltreRad(Val1)+ " " +FiltreRad(Val2));
			if(Delimiter(FiltreRad(Val1),ListPartSpec)){
				pos=i;
				
				System.out.println("Existe Délimiteur particule");
			}
		}
		i++;
	}
	return pos;
}

public static boolean Patron1_1(MotProperty m, MotProperty ms1, MotProperty ms2){					//a.    (غير)إنه مِنَ + adjectif défini
	boolean verif=false;
	/*if(m.ExtraireVGEnc().equals("38") && m.ExtraireGenreanaph().equals("M") && 
			m.ExtraireNbranaph().equals("S") && FiltreRad(ms1.ExtraireRad()).equals("MiNo") && 
			ms1.ExtraireVGRad().equals("78") && ListAdjDefini(FiltreRad(ms2.ExtraireRad()),ListAdjDef) &&
			ms2.ExtraireVGRad().equals("203")){
		verif=true;
		}*/
	if(m.getVgenc().equals("38") && m.getGenrenc().equals("M") && 
			m.getNbrenc().equals("S") && FiltreRad(ms1.getRad()).equals("MiNo") && 
			ms1.getVg().equals("78") && ListAdjDefini(FiltreRad(ms2.getRad()),ListAdjDef) &&
			ms2.getVg().equals("203")){
		verif=true;
		}
	return verif;
}
public static boolean Patron1_2(MotProperty m, MotProperty ms1, MotProperty ms2, MotProperty ms3){
	boolean verif=false;
	/*if(m.ExtraireVGEnc().equals("38") && m.ExtraireGenreanaph().equals("M") && 
			m.ExtraireNbranaph().equals("S") && FiltreRad(ms1.ExtraireRad()).equals("MiNo") && 
			ms1.ExtraireVGRad().equals("78") && FiltreRad(ms2.ExtraireRad()).equals("RaYori") && 
			ListAdjDefini(FiltreRad(ms3.ExtraireRad()),ListAdjDef) && ms3.ExtraireVGRad().equals("203")){
		verif=true;
		}*/
	if(m.getVgenc().equals("38") && m.getGenrenc().equals("M") && 
			m.getNbrenc().equals("S") && FiltreRad(ms1.getRad()).equals("MiNo") && ms1.getVg().equals("78") 
			&& (FiltreRad(ms2.getRad()).equals("RaYori") ||FiltreRad(ms2.getRad()).equals("RaYor"))&& 
			ListAdjDefini(FiltreRad(ms3.getRad()),ListAdjDef) && ms3.getVg().equals("203")){
		verif=true;
		}
	return verif;
}
public static boolean Patron1_3(MotProperty m, MotProperty ms1, MotProperty ms2, MotProperty ms3){
	boolean verif=false;
	if(m.getVgenc().equals("38") && m.getGenrenc().equals("M") && 
			m.getNbrenc().equals("S") && FiltreRad(ms1.getRad()).equals("LaYosa") && 
			FiltreRad(ms2.getRad()).equals("MiNo") && ms2.getVg().equals("78") &&
			ListAdjDefini(ms3.getVal(),ListAdjDef) && (ms3.getVg().equals("203")||ms3.getVg().equals("50"))){
		System.out.println("Patron1_2");
		verif=true;
		}
	return verif;
}
public static boolean Patron2(MotProperty m, MotProperty ms1, MotProperty ms2){					//b.	إنه + status (حال) délimiteur spécifique
	boolean verif=false;
	/*if(m.ExtraireVGEnc().equals("38") && m.ExtraireGenreanaph().equals("M") && m.ExtraireNbranaph().equals("S") 
			&& Delimiter(FiltreRad(ms1.ExtraireRad())+ " " +FiltreRad(ms2.ExtraireRad()),ListDelimiteurSpec)){
		verif=true;
		}*/
	if(m.getVgenc().equals("38") && m.getGenrenc().equals("M") && m.getNbrenc().equals("S") 
			&& Delimiter(FiltreRad(ms1.getRad())+ " " +FiltreRad(ms2.getRad()),ListDelimiteurSpec)){
		verif=true;
		}
	return verif;
}
public static boolean Patron3(MotProperty m, MotProperty ms1, MotProperty ms2){					//c.	Modificateur + Pronom + <particule= مَنْ > + Verbe
	boolean verif=false;
	/*if(m.ExtraireVGEnc().equals("38") && m.ExtraireGenreanaph().equals("M") && m.ExtraireNbranaph().equals("S") 
			&& FiltreRad(ms1.ExtraireRad()).equals("MaNo") && EstunVerbe(ms2.ExtraireVGRad())){
		verif=true;
		}*/
	if(m.getVgenc().equals("38") && m.getGenrenc().equals("M") && m.getNbrenc().equals("S") 
			&& (FiltreRad(ms1.getRad()).equals("MaNo")||FiltreRad(ms1.getRad()).equals("MaN"))
			&& EstunVerbe(ms2.getVg())){
		verif=true;
		}
	return verif;
}
public static boolean Patron3_1(MotProperty m, MotProperty ms1, MotProperty ms2){					//Eliminer //c.	Modificateur + Pronom + <particule= مَنْ > + Verbe
	boolean verif=false;
	/*if(m.ExtraireVGEnc().equals("38") && m.ExtraireGenreanaph().equals("M") && m.ExtraireNbranaph().equals("S") 
			&& FiltreRad(ms1.ExtraireRad()).equals("Lal") && EstunNom(ms2.ExtraireVGRad())){
		verif=true;
		}*/
	if(m.getVgenc().equals("38") && m.getGenrenc().equals("M") && m.getNbrenc().equals("S") 
			&& FiltreRad(ms1.getRad()).equals("Lal") && EstunNom(ms2.getVg())){
		verif=true;
		}
	return verif;
}
public static boolean Patron3_2(MotProperty m, MotProperty ms1, MotProperty ms2){					//c.	Modificateur + Pronom + <particule= مَنْ > + Verbe
	boolean verif=false;
	/*if(m.ExtraireVGEnc().equals("38") && m.ExtraireGenreanaph().equals("M") && m.ExtraireNbranaph().equals("S") 
			&& FiltreRad(ms1.ExtraireRad()).equals("LaWoLl") && EstunNom(ms2.ExtraireVGRad()) && ms2.ExtraireValProc().equals("1")){
		verif=true;
		}*/
	if(m.getVgenc().equals("38") && m.getGenrenc().equals("M") && m.getNbrenc().equals("S") 
			&& FiltreRad(ms1.getRad()).equals("LaWoLal") && EstunNom(ms2.getVg()) && ms2.getVgproc().equals("1")){
		verif=true;
		}
	return verif;
}
public static boolean Patron4(MotProperty m, MotProperty ms1){					//e.	إنها  / إنه + verbe indiquant le climat ou l’ambiance 
	boolean verif=false;
	/*if(m.ExtraireVGEnc().equals("38") && (m.ExtraireGenreanaph().equals("M")||m.ExtraireGenreanaph().equals("F"))
			&& m.ExtraireNbranaph().equals("S") && Delimiter(FiltreRad(ms1.ExtraireRad()),ListVerbClimAmb)){
		verif=true;
		}*/
	if(m.getVgenc().equals("38") && (m.getGenrenc().equals("M")||m.getGenrenc().equals("F"))
			&& m.getNbrenc().equals("S") && Delimiter(FiltreRad(ms1.getRad()),ListVerbClimAmb)){
		verif=true;
		}
	return verif;
}
public static boolean Patron4_1(MotProperty m, MotProperty ms1){					//e.	إنها  / إنه + verbe indiquant le climat ou l’ambiance 
	boolean verif=false;
	/*if(m.ExtraireVGEnc().equals("38") && (m.ExtraireGenreanaph().equals("M")||m.ExtraireGenreanaph().equals("F"))
			&& m.ExtraireNbranaph().equals("S") && Delimiter(FiltreRad(ms1.ExtraireRad()),ListVerbClimAmb)){
		verif=true;
		}*/
	if(m.getVg().equals("94") && (m.getGenr().equals("M")||m.getGenr().equals("F"))
			&& m.getNbr().equals("S") && Delimiter(FiltreRad(ms1.getRad()),ListVerbClimAmb)){
		verif=true;
		}
	return verif;
}
public static boolean Patron5(MotProperty m, MotProperty ms1, MotProperty ms2){					//f.	إنّها  + nombre indiquant l’heure ou le temps
	boolean verif=false;
	/*if(m.ExtraireVGEnc().equals("38") && m.ExtraireGenreanaph().equals("F") && m.ExtraireNbranaph().equals("S") 
			&& ms1.ExtraireVGProc().equals("1") && EstunNombre(ms1.ExtraireVGRad()) &&
			Delimiter(FiltreRad(ms2.ExtraireRad2()),ListDelimiteurJourNuit)){
		verif=true;
		}*/
	if(m.getVgenc().equals("38") && m.getGenrenc().equals("F") && m.getNbrenc().equals("S") 
			&& ms1.getVgproc().equals("1") && EstunNombre(ms1.getVg()) &&
			Delimiter(FiltreRad(ms2.getVal()),ListDelimiteurJourNuit)){
		verif=true;
		}
	return verif;
}
public static boolean Patron5_1(MotProperty m, MotProperty ms1,MotProperty ms2,MotProperty ms3, MotProperty ms4){					//f.	إنّها  + nombre indiquant l’heure ou le temps
	boolean verif=false;
	/*if(m.ExtraireVGEnc().equals("38") && m.ExtraireGenreanaph().equals("F") && m.ExtraireNbranaph().equals("S") 
			&& ms1.ExtraireVGProc().equals("1") && EstunNombre(ms1.ExtraireVGRad()) &&
			Delimiter(FiltreRad(ms2.ExtraireRad2()),ListDelimiteurJourNuit)){
		verif=true;
		}*/
	if(m.getVgenc().equals("38") && m.getGenrenc().equals("F") && m.getNbrenc().equals("S") 
			&& ms1.getVgproc().equals("1") && EstunNombre(ms1.getVg()) &&
			(Delimiter(FiltreRad(ms2.getVal()),ListDelimiteurJourNuit)||Delimiter(FiltreRad(ms3.getVal()),ListDelimiteurJourNuit)||
					Delimiter(FiltreRad(ms4.getVal()),ListDelimiteurJourNuit))){
		verif=true;
		System.out.println("Patron5");
		}
	return verif;
}
public static boolean Patron6(MotProperty m, MotProperty ms1, MotProperty ms2){					//g.	إنّه  + (منذ  / مِنَ ) + délimiteur de temps
	boolean verif=false;
	/*if(m.ExtraireVGEnc().equals("38") && m.ExtraireGenreanaph().equals("M") && m.ExtraireNbranaph().equals("S") 
			&& Delimiter(FiltreRad(ms1.ExtraireRad()),ListDelimiteurTemps) && 
			(FiltreRad(ms2.ExtraireRad()).equals("EN")||EstunNombre(ms2.ExtraireVGRad()))){
		verif=true;
		}*/
	if(m.getVgenc().equals("38") && m.getGenrenc().equals("M") && m.getNbrenc().equals("S") 
			&& Delimiter(FiltreRad(ms1.getRad()),ListDelimiteurTemps) && 
			(FiltreRad(ms2.getRad()).equals("EN")||EstunNombre(ms2.getVg()))){
		verif=true;
		}
	return verif;
}
public static boolean Patron6_1(MotProperty m, MotProperty ms1,String Nombre){					//g.	إنّه  + (منذ  / مِنَ ) + délimiteur de temps
	boolean verif=false;
	/*if(m.ExtraireVGEnc().equals("38") && m.ExtraireGenreanaph().equals("M") && m.ExtraireNbranaph().equals("S") 
			&& Delimiter(FiltreRad(ms1.ExtraireRad()),ListDelimiteurTemps) && 
			(FiltreRad(ms2.ExtraireRad()).equals("EN")||EstunNombre(ms2.ExtraireVGRad()))){
		verif=true;
		}*/
	if(m.getVgenc().equals("38") && m.getGenrenc().equals("M") && m.getNbrenc().equals("S") 
			&& Delimiter(FiltreRad(ms1.getRad()),ListDelimiteurTemps) && (isNumeric(Nombre))){
		verif=true;
		}
	return verif;
}
public static boolean Patron6_2(MotProperty m, MotProperty ms1,MotProperty ms2){					//g.	إنّه  + (منذ  / مِنَ ) + délimiteur de temps
	boolean verif=false;
	/*if(m.ExtraireVGEnc().equals("38") && m.ExtraireGenreanaph().equals("M") && m.ExtraireNbranaph().equals("S") 
			&& Delimiter(FiltreRad(ms1.ExtraireRad()),ListDelimiteurTemps) && 
			(FiltreRad(ms2.ExtraireRad()).equals("EN")||EstunNombre(ms2.ExtraireVGRad()))){
		verif=true;
		}*/
	if(m.getVgenc().equals("38") && m.getGenrenc().equals("M") && m.getNbrenc().equals("S") 
			&& Delimiter(FiltreRad(ms1.getRad()),ListDelimiteurTemps) && (EstunNombre(ms2.getVg()))){
		verif=true;
		}
	return verif;
}
public static boolean Patron7(MotProperty mp1, MotProperty m){					//g.	ما + verbe+ pronom attaché
	boolean verif=false;
	//System.out.println(mp1.ExtraireValeur()+" "+m.ExtraireValeur());
	
	if(m.getVgenc().equals("47") && m.getGenrenc().equals("M") && m.getNbrenc().equals("S") 
			&& EstunVerbe(m.getVg()) &&	(FiltreRad(mp1.getRad()).equals("Mal")||FiltreRad(mp1.getRad()).equals("gaMAl"))
			&& EstuneParticule(mp1.getVg())){
		verif=true;
		}
	return verif;
}
public static boolean Patron7_1(MotProperty mp2,MotProperty mp1, MotProperty m){					//g.	d.	ما + verbe+ pronom attaché
	boolean verif=false;
	//System.out.println(mp1.ExtraireValeur()+" "+m.ExtraireValeur());
	
	if(m.getVgenc().equals("38") && m.getGenrenc().equals("M") && m.getNbrenc().equals("S") 
			&& EstunNom(m.getVg()) && Delimiter(FiltreRad(mp1.getRad()),ListVerbImpers) &&
			(FiltreRad(mp2.getRad()).equals("Mal")||FiltreRad(mp2.getRad()).equals("gaMAl"))
			&& EstuneParticule(mp2.getVg())){
		verif=true;
		System.out.println("Patron7");
		}
	return verif;
}
public static boolean Patron7_2(MotProperty mp2, MotProperty mp1, MotProperty m){					//g.	ما + verbe+ pronom attaché
	boolean verif=false;
	//System.out.println(mp1.ExtraireValeur()+" "+m.ExtraireValeur());
	
	if(m.getVgenc().equals("47") && m.getGenrenc().equals("M") && m.getNbrenc().equals("S") 
			&& EstunVerbe(m.getVg()) &&	FiltreRad(mp1.getRad()).equals("lLAViY") && FiltreRad(mp2.getRad()).equals("Mal")
			&& EstuneParticule(mp2.getVg())){
		verif=true;
		}
	return verif;
}
public static boolean Patron7_3(MotProperty mp1, MotProperty m){					//g.	إنّه  + (منذ  / مِنَ ) + délimiteur de temps
	boolean verif=false;
	//System.out.println(mp1.ExtraireValeur()+" "+m.ExtraireValeur());
	
	if(m.getVg().equals("94") && (m.getGenr().equals("M")||m.getGenr().equals("F"))
			&& m.getNbr().equals("S") && (FiltreRad(mp1.getRad()).equals("MaN")||FiltreRad(mp1.getRad()).equals("MaNo"))
			&& EstuneParticule(mp1.getVg())){
		verif=true;
		}
	return verif;
}
public static boolean Patron8(MotProperty m, MotProperty ms1){					//g.	إنّه  َ + Verbe impersonnel
	boolean verif=false;
	/*if(m.ExtraireVGEnc().equals("38") && m.ExtraireGenreanaph().equals("M") && m.ExtraireNbranaph().equals("S") 
			&& Delimiter(FiltreRad(ms1.ExtraireRad()),ListDelimiteurTemps) && 
			(FiltreRad(ms2.ExtraireRad()).equals("EN")||EstunNombre(ms2.ExtraireVGRad()))){
		verif=true;
		}*/
	if(m.getVgenc().equals("38") && m.getGenrenc().equals("M") && m.getNbrenc().equals("S") 
			&& Delimiter(FiltreRad(ms1.getRad()),ListVerbImpers)){
		verif=true;
		//System.out.println("Patron8");
		}
	return verif;
}
public static boolean Patron9(MotProperty mp2,MotProperty mp1, MotProperty m){					//g.	d.	ما + verbe+ pronom attaché
	boolean verif=false;
	//System.out.println(mp1.ExtraireValeur()+" "+m.ExtraireValeur());
	
	if(m.getVg().equals("10") && FiltreRad(m.getRad()).equals("huNalk") 
			&& Delimiter(mp2.getVal()+ " " +mp1.getVal(),ListDelimPronDemonst)){
		verif=true;
		System.out.println("Patron7");
		}
	return verif;
}
public static boolean Patron9_1(MotProperty m, MotProperty ms1){					//g.	d.	ما + verbe+ pronom attaché
	boolean verif=false;
	//System.out.println(mp1.ExtraireValeur()+" "+m.ExtraireValeur());
	
	if(m.getVg().equals("10") && FiltreRad(m.getRad()).equals("huNalk") 
			&& ((FiltreRad(ms1.getRad()).equals("MaNo"))||(FiltreRad(ms1.getRad()).equals("MaN")))){
		verif=true;
		System.out.println("Patron9_1");
		}
	return verif;
}
public static boolean isNumeric(String str)
{
    for (char c : str.toCharArray())
    {
        if (!Character.isDigit(c)) return false;
    }
    return true;
}
public static boolean EstuneParticule(String VG){
	boolean x=false;
	int vg=Integer.parseInt(VG);
	if ((vg>=72 && vg<=75)||(vg==70)||(vg==54)||(vg==18))
		x=true;
	return x;
}
public static boolean EstunNombre(String VG){
	boolean x=false;
	int vg=Integer.parseInt(VG);
	if ((vg>=208 && vg<=213)||(vg>=107 && vg<=112))
		x=true;
	return x;
}
public static boolean Delimiter(String Sequence,  List<String> ListDelimiter){
	boolean test=false;
	int i=0;
	while(i<ListDelimiter.size() && test==false){
		//System.out.println(ListDelimiter.get(i).replaceAll("   ","").replaceAll("  ","").replaceAll(" ","")+"="+Sequence.replaceAll("\\s",""));
		if(ListDelimiter.get(i).replaceAll("   ","").replaceAll("  ","").replaceAll(" ","").equals(Sequence.replaceAll("\\s","")))
			test=true;
		i++;
	}
	return test;
}
public static boolean ListAdjDefini(String adj,List<String> ListAdj){
	boolean test=false;
	int i=0;
	while(i<ListAdj.size() && test==false){
		if(ListAdj.get(i).equals(adj))
			test=true;
		i++;
	}
	return test;
}
public static boolean EstunVerbe(String VG){
	boolean x=false;
	if (!VG.equals("")){
		int vg=Integer.parseInt(VG);
		if (vg>=113 && vg<=191)
			x=true;
	}
	return x;
}
public static String FiltreRad(String rad){
	String radical=new String();
	if(rad.contains(";"))
		radical=rad.substring(0, rad.indexOf(";"));
	else radical=rad;
	return radical;
}
public static boolean EstunModificateur(String rad, String VG){
	boolean test=false;
		if(VG.equals("58") || VG.equals("59")){
			if(rad.equals("éiNA")|| rad.equals("èaNA")||rad.equals("LakiNA")||
					rad.equals("LaYoTa")||rad.equals("LagaLA")){
				test=true;
			}
		}
	return test;
}
public static int[] PosModificateur(List syntagmes){
	int Pos=-1;
	Iterator s = syntagmes.iterator();
	int[] ArrayPos = new int[3];
    int numMot=-1;
    int numSyn=-1;
    int wo=-1;
    ArrayPos[0]=numMot;	//num mot dans la phrase
	ArrayPos[1]=numSyn;	//num syntagme dans la phrase
    while(s.hasNext() && Pos==-1){
    	wo=-1;
      Syntagme syn = new Syntagme();
      syn.syntagme = (Element)s.next();
      numSyn++;
      List mots = syn.ExtraireMots();
      Iterator m = mots.iterator();
        while(m.hasNext() && Pos==-1){
        	 Mot w = new Mot();
             w.mot=(Element)m.next(); 
             numMot++;
             wo++;
             if(EstunModificateur(w.ExtraireRadE(),w.ExtraireVGRad2())){
            	 Pos=numMot;
            	 ArrayPos[0]=numMot;
            	 ArrayPos[1]=numSyn;
            	 ArrayPos[2]=wo;		//position du mot dans le syntagme
             }    
        }
    }
	return ArrayPos;
}

public static int PosModificateur1(List mots){
	int Pos=-1;
	int i=0;
    while(i<mots.size() && Pos==-1){
      Mot mt = new Mot();
	  mt.mot=(Element)mots.get(i);
             if(EstunModificateur(mt.ExtraireRadE(),mt.ExtraireVGRad())){
            	 Pos=i;
             } 
        i++;
     }
	return Pos;
}
public static void main(String[] args) {
    // Create the empty dataset "race" with above attributes
	//String TextesEtiq1=ReadTxtFile.LectureParametres().get(3);
	//String[] data1 = TextesEtiq1.split(",");
	String[] data1=new String[1];
	data1[0]="test1SegV3Res24.xml";
	ConstructFileArffPrNonRef1 cc = new ConstructFileArffPrNonRef1();
	//cc.CreationCorpus1("test1SegV3Res24.xml", "Etiq");
	//CreerFichier("TextesEtiq","Etiq");
	//cc.CreationCorpus1("", "NonEtiq");
	//CreerFichier("TextesNonEtiq","NonEtiq");
	cc.CreationCorpus1("Etiq",data1);
	CreerFichier("test1Seg");
	//Afficher_Liste(ListDelimiteurSpec);
	
  }
}



/*public static class classifier implements   Runnable {
	
	Classifier cls;
	String no ;
	public classifier(Classifier cl,String nom)  {
     cls = cl;
     no= nom;
   }
	 static ArrayList<Double> clsLabel=new ArrayList();
		static ArrayList<Double> clsLabel1=new ArrayList();
		static ArrayList<Double> clsLabel2=new ArrayList();
		Instances unlabeled;
		Instances labeled;
		
  public void run() {
	 
      try {
    	  
    	  Instances test = new Instances(
                  new BufferedReader(
                    new FileReader(chargertexte.chooser.getSelectedFile().getName()+".arff")));
    	// set class attribute
    	  test.setClassIndex(test.numAttributes() - 1);
    	 
    	  
    	  BufferedReader reader = new BufferedReader(
                  new FileReader("train1.xml.arff"));
    Instances train = new Instances(reader);
    
    train.setClassIndex(train.numAttributes() - 1);
    	  // create copy
    	  Instances essai = new Instances(test);
    	  cls.buildClassifier(train);
    
  		// evaluate classifier and print some statistics
  		  Evaluation eval1 = new Evaluation(essai);
  		  eval1.evaluateModel(cls, essai);
  		  Resultat(eval1,no);
  		 unlabeled = new Instances(
  		          new BufferedReader(
  		            new FileReader(chargertexte.chooser.getSelectedFile().getName()+".arff")));

  		// set class attribute
  		unlabeled.setClassIndex(unlabeled.numAttributes() - 1);

  		// create copy
  		 labeled = new Instances(unlabeled);
  		// label instances
      } catch (InterruptedException e) {
          return;
       } catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
  		
		
  		for (int i = 0; i <unlabeled.numInstances(); i++) {
  			double clsLabel;
			try {
				clsLabel = cls.classifyInstance(unlabeled.instance(i));
			
  			labeled.instance(i).setClassValue(clsLabel);
  		  
			
				
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				

  		}
	BufferedWriter writer1;
	try {
		writer1 = new BufferedWriter(
		            new FileWriter(chargertexte.chooser.getSelectedFile().getName()+".arff"));
	
	writer1.write(labeled.toString());
	writer1.newLine();
	writer1.flush();
	writer1.close();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
 */     






