package classificationSVM;

import java.io.*;

import java.util.*;

import org.jdom2.*;

import java.util.Iterator;

import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.bayes.NaiveBayes;
import weka.classifiers.bayes.NaiveBayesUpdateable;
import weka.classifiers.meta.FilteredClassifier;
import weka.classifiers.trees.J48;
import weka.core.*;
import weka.core.converters.ArffLoader;
import weka.core.converters.ArffSaver;
import weka.core.FastVector;
import weka.core.Instance;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.Remove;



import org.jdom2.input.*;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

import fichierArff.Mot;



import weka.core.Attribute;

public class CreateCorpus {
  static Instances UnlabelTemp = null;
  public CreateCorpus() {}
  static Instance inst1 = new DenseInstance(10);

public static  String CreationCorpusTemp(Instances Unlabel, int Iteration){
  /****
   * Construction de la liste d'attributs
   */

  FastVector attributes = new FastVector(10);
    FastVector mots1 = new FastVector();
    mots1 = null;

    String NewUnlabel="NewFileUnlabel"+Iteration+".arff";

    /***
     * Création des attributs Mot, Radical, Lemme, VGRad, Enc et VgEnc
     */

    Attribute motin = new Attribute("Mot", mots1);
    Attribute rad = new Attribute("Rad", mots1);
    Attribute lem = new Attribute("Lem", mots1);
    Attribute vgrad = new Attribute("VGRad");
    Attribute enc = new Attribute("Enc", mots1);
    Attribute vgenc = new Attribute("vgEnc");
    System.out.println(motin.toString());

    /***
     * Création de l'attribut GenreEnc
     */

    FastVector my_nominal_gen = new FastVector(2);
    my_nominal_gen.addElement("F");
    my_nominal_gen.addElement("M");
    my_nominal_gen.addElement("MF");
    my_nominal_gen.addElement("MMFF");
    my_nominal_gen.addElement("");
    Attribute genEnc = new Attribute("GenEnc", my_nominal_gen);
    System.out.println(genEnc.toString());

    /***
     * Création de l'attribut NombreEnc
     */

    FastVector my_nominal_nbr = new FastVector(3);
    my_nominal_nbr.addElement("S");
    my_nominal_nbr.addElement("D");
    my_nominal_nbr.addElement("P");
    my_nominal_nbr.addElement("SS");
    my_nominal_nbr.addElement("PP");
    my_nominal_nbr.addElement("");
    Attribute nbrEnc = new Attribute("NbrEnc", my_nominal_nbr);
    System.out.println(nbrEnc.toString());
    
    FastVector my_nominal_classe = new FastVector(1);
    my_nominal_classe.addElement("0");
    my_nominal_classe.addElement("1");

    /***
     * Création de l'attribut classe
     */

    Attribute classe = new Attribute("classe", my_nominal_classe);
   
    /*****
     * attributs contextuels à une fenêtre [-1,+4]
     */

    /***
     * Création des attributs du mot précédent
     */

    Attribute MotPrec = new Attribute("MotPrec", mots1);
    Attribute RadPrec = new Attribute("RadPrec", mots1);
    Attribute VgRadPrec = new Attribute("VgRadPrec");
    
    /***
     * Création des attributs du mot suivant n°1
     */
     
    Attribute MotSuiv1 = new Attribute("MotSuiv1", mots1);
    Attribute RadSuiv1 = new Attribute("RadSuiv1", mots1);
    Attribute VgRadSuiv1 = new Attribute("VgRadSuiv1");
    Attribute genSuiv1 = new Attribute("genSuiv1", my_nominal_gen);
    Attribute nbrSuiv1 = new Attribute("nbrSuiv1", my_nominal_nbr);
    
    /***
     * Création des attributs du mot suivant n°2
     */

    Attribute MotSuiv2 = new Attribute("MotSuiv2", mots1);
    Attribute RadSuiv2 = new Attribute("RadSuiv2", mots1);
    Attribute VgRadSuiv2 = new Attribute("VgRadSuiv2");
    Attribute genSuiv2 = new Attribute("genSuiv2", my_nominal_gen);
    Attribute nbrSuiv2 = new Attribute("nbrSuiv2", my_nominal_nbr);
    
    /***
     * Création des attributs du mot suivant n°3
     */

    Attribute MotSuiv3 = new Attribute("MotSuiv3", mots1);
    Attribute RadSuiv3 = new Attribute("RadSuiv3", mots1);
    Attribute VgRadSuiv3 = new Attribute("VgRadSuiv3");
    Attribute genSuiv3 = new Attribute("genSuiv3", my_nominal_gen);
    Attribute nbrSuiv3 = new Attribute("nbrSuiv3", my_nominal_nbr);

    /***
     * Création des attributs du mot suivant n°4
     */

    Attribute MotSuiv4 = new Attribute("MotSuiv4", mots1);
    Attribute RadSuiv4 = new Attribute("RadSuiv4", mots1);
    Attribute VgRadSuiv4 = new Attribute("VgRadSuiv4");
    Attribute genSuiv4 = new Attribute("genSuiv4", my_nominal_gen);
    Attribute nbrSuiv4 = new Attribute("nbrSuiv4", my_nominal_nbr);

    /***
     * Création du vecteur des attributs
     */

   //attributes.addElement(motin);
   //attributes.addElement(rad);
   //attributes.addElement(lem);
   attributes.addElement(vgrad);
   //attributes.addElement(enc);
   attributes.addElement(vgenc);
   attributes.addElement(genEnc);
   attributes.addElement(nbrEnc);
   //attributes.addElement(MotPrec);
   //attributes.addElement(RadPrec);
   attributes.addElement(VgRadPrec);
   //attributes.addElement(MotSuiv1);
   //attributes.addElement(RadSuiv1);
   attributes.addElement(VgRadSuiv1);
   //attributes.addElement(genSuiv1);
   //attributes.addElement(nbrSuiv1);
   //attributes.addElement(MotSuiv2);
   //attributes.addElement(RadSuiv2);
   attributes.addElement(VgRadSuiv2);
   //attributes.addElement(genSuiv2);
   //attributes.addElement(nbrSuiv2);
   //attributes.addElement(MotSuiv3);
   //attributes.addElement(RadSuiv3);
   attributes.addElement(VgRadSuiv3);
   //attributes.addElement(genSuiv3);
   //attributes.addElement(nbrSuiv3);
   //attributes.addElement(MotSuiv4);
   //attributes.addElement(RadSuiv4);
   attributes.addElement(VgRadSuiv4);
   //attributes.addElement(genSuiv4);
   //attributes.addElement(nbrSuiv4);
   
   attributes.addElement(classe);
   
  
	 try {
		 	UnlabelTemp = new Instances("Corpus-Temporaire", attributes, 0);

		    // Make position the class attribute
		   UnlabelTemp.setClass(classe);
		    System.out.println("nbr d'instance non etiquetés:"+Unlabel.numInstances());
		    int NbrInst=(40*Unlabel.numInstances())/100;
		    System.out.println(NbrInst);
		    int n=NbrInst;
		    int i=0;
		    while(n>0){
		    	i=(int)(Math.random() * (NbrInst + 1));
		    	inst1=Unlabel.instance(i);
		    	inst1.setDataset(UnlabelTemp);		//Ajouter l'instance choisi au fichier non étiqueté temporaire
		    	Unlabel.delete(i);				//Supprimer l'instance choisi du fichier non étiqueté initiale
		    	System.out.println("nouveau nbr d'instance"+Unlabel.numInstances());
		    	UnlabelTemp.add(inst1);
		        n=n-1;
		    }
		    System.out.println("nbr d'instance unlabel final:"+Unlabel.numInstances());
			 ArffSaver saver = new ArffSaver();
			 saver.setInstances(Unlabel);
			saver.setFile(new File(NewUnlabel));
			//saver.setDestination(new File("test.arff"));   // **not** necessary in 3.5.4 and later
			saver.writeBatch();
		  Instances m = new Instances(UnlabelTemp);
		  System.out.println("Nombre des attributs: " + m.numAttributes());
		  System.out.println("Nombre des instances Data: " + m.numInstances());
		  System.out.println("Nombre de classe: " + m.numClasses());
		  System.out.println("corpus créé avec succès " + UnlabelTemp.numInstances());
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 return NewUnlabel;

 // return FileTemp;
}

public static void CreerFichier(String texte){
  try{
	  
    BufferedWriter writer = new BufferedWriter(new FileWriter(
        texte));
    writer.write(UnlabelTemp.toString());
    writer.flush();
    writer.close();
  }
  catch (Exception e){}

}
static void enregistre(String fichier,Document document)
{
   try
   {
      
      XMLOutputter sortie = new XMLOutputter(Format.getPrettyFormat());
      
      
      sortie.output(document, new FileOutputStream(fichier));
   }
   catch (java.io.IOException e){}
}
public static void Resultat(Evaluation eval,String nom) throws JDOMException, IOException{

	SAXBuilder builder = new SAXBuilder();
    Document document = builder.build(new File("resultat.xml"));
    Element racine = document.getRootElement();
    
	  Element resultat = new Element("resultat");
	  racine.addContent(resultat);
	  resultat.setAttribute("Nom",nom);
	  Element table4 = new Element("numberofcorrectlyclassifiedinstances");
	  resultat.addContent(table4);
	  String kk=String.valueOf(eval.correct());
	  table4.addContent(kk);
	  Element table = new Element("CorrectlyClassifiedInstances");
	  resultat.addContent(table);
	  String pc=String.valueOf(eval.pctCorrect()); 
	  table.addContent(pc);
	  Element table1 = new Element("numberofIncorrectlyClassifiedInstances");
	  resultat.addContent(table1);
	  String hh=String.valueOf(eval.incorrect());
	  table1.addContent( hh);
	  Element table2 = new Element("IncorrectlyClassifiedInstances");
	  resultat.addContent(table2);
	  String pic=String.valueOf(eval.pctIncorrect()); 
	  table2.addContent(pic);
	  XMLOutputter sortie = new XMLOutputter(Format.getPrettyFormat());
	  sortie.output(document, new FileOutputStream("resultat.xml"));
	
}


public static void main(String[] args) {
    // Create the empty dataset "race" with above attributes

	 Instances Unlabel;
	 Instances NewUnlabel;
	try {
		Unlabel = new Instances(new BufferedReader(new FileReader("FileUnlabled1.arff")));
		CreateCorpus cc = new CreateCorpus();
		String NewFileUnlabled=cc.CreationCorpusTemp(Unlabel,1); //Créer le fichier temporaire de données non étiquetées 
		CreerFichier("FileUnlabelTemp.arff");
		NewUnlabel = new Instances(new BufferedReader(new FileReader(NewFileUnlabled)));
		System.out.println("nouveau taille fichier non étiqueté " + NewUnlabel.numInstances());

		
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
  }
}