package classificationSVM;
 
public class Anaphore {
	
	private int Num;
	//private String valeur;
	//private String type;
	//private String vg;
	private int NumMot;
	private int NumSyntag;
	private int NumPh;
	private int NumParag;
	//private String Genre;
	//private String Nombre;
	//private int numPhGlobal;
	private boolean Referentiel;
	
	public Anaphore(int num, int numMot,int numSynatg, int numPh,int numParag, boolean Ref){
		this.Num=num;
		//this.valeur=valeur;
		//this.type=type;
		//this.vg=vg;
		this.NumMot=numMot;
		this.NumSyntag=numSynatg;
		this.NumPh=numPh;
		this.NumParag=numParag;
		//this.Genre=Genre;
		//this.Nombre=Nombre;
		//this.numPhGlobal=numPhGlobal;
		this.Referentiel=Ref;
	}

	public int getNum() {
		return Num;
	}

	public void setNum(int num) {
		Num = num;
	}

	public int getNumMot() {
		return NumMot;
	}

	public void setNumMot(int numMot) {
		NumMot = numMot;
	}

	public int getNumSyntag() {
		return NumSyntag;
	}

	public void setNumSyntag(int numSyntag) {
		NumSyntag = numSyntag;
	}

	public int getNumPh() {
		return NumPh;
	}

	public void setNumPh(int numPh) {
		NumPh = numPh;
	}

	public int getNumParag() {
		return NumParag;
	}

	public void setNumParag(int numParag) {
		NumParag = numParag;
	}

	public boolean isReferentiel() {
		return Referentiel;
	}

	public void setReferentiel(boolean referentiel) {
		Referentiel = referentiel;
	}

	
}
