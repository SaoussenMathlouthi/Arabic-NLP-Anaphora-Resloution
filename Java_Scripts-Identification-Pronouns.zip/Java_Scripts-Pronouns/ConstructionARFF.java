package classificationSVM;

import java.io.*;

import java.util.*;

import org.jdom2.*;

import java.util.Iterator;

import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.bayes.NaiveBayes;
import weka.classifiers.bayes.NaiveBayesUpdateable;
import weka.classifiers.meta.FilteredClassifier;
import weka.classifiers.trees.J48;
import weka.core.*;
import weka.core.converters.ArffLoader;
import weka.core.FastVector;
import weka.core.Instance;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.Remove;



import org.jdom2.input.*;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

import classificationSVM.ReadTxtFile;



import weka.core.Attribute;

public class ConstructionARFF {
  static Instances corpus = null;
  public ConstructionARFF() {}


  public static void main(String[] args) {
	    // Create the empty dataset "race" with above attributes
	 
	 // ArffFile(false);
	String CorpusNonEtiq="CorpusNonEtiqueteFinal0";
	String TextesNonEtiq1=LectureFichierTexte.LectureParametres("Parametres.txt").get(5);
	String[] data = TextesNonEtiq1.split(",");
	ConstructArffUnlabeldFile(data, CorpusNonEtiq);
  }
  
public static void ArffFile(boolean labeled,String Corpus){

	//String CopusEtiq=new String();
	//String[] data = (String[])ArrayUtils.addAll(data1, data2);
	//String[]data= Arrays.copyOf(data1, data1.length + data2.length);
	//System.arraycopy(data2, 0, data, data1.length, data2.length);
	if(labeled){
		//CopusEtiq="CorpusEtiqueteEssai.arff";
		String TextesEtiq1=LectureFichierTexte.LectureParametres("Parametres0.txt").get(4);
		String TextesEtiq2=LectureFichierTexte.LectureParametres("Parametres0.txt").get(5);
		String[] data1 = TextesEtiq1.split(",");
		String[] data2 = TextesEtiq2.split(",");
		DisplayArray(data1);
		DisplayArray(data2);
		List<InstancePronom> ListInstanceEtiq=new ArrayList<InstancePronom>();
		int NumPron=0;
		ConstructFileArffPrNonRef1 cc1 = new ConstructFileArffPrNonRef1();
		Instances instances1=cc1.CreationCorpus1("Etiq",data1);
		//cc1.CreerFichier("CorpusEtiquete1","Etiq");
		//System.out.println("nbr instances 1: "+instances1.numInstances()+" NumPronom: "+NumPron);
		//DisplayList(ListInstanceEtiq);
		
		ConstructFileArffPrNonRef2 cc2 = new ConstructFileArffPrNonRef2();
		Instances instances2=cc2.CreationCorpus("Etiq",data2);
		//cc1.CreerFichier("CorpusEtiquete2","Etiq");
		System.out.println("nbr instances 2: "+instances2.numInstances());
		System.out.println("nbr instances 1: "+instances1.numInstances());
		DisplayList(ListInstanceEtiq);
		
		instances1.addAll(instances2);
		System.out.println("nbr instances total:"+instances1.numInstances());
		
		CreerFichier(Corpus,instances1);
	}
	else if(!labeled){
		String TextesEtiq1=LectureFichierTexte.LectureParametres("Parametres0.txt").get(6);
		String TextesEtiq2=LectureFichierTexte.LectureParametres("Parametres0.txt").get(7);
		String TextesEtiq3=LectureFichierTexte.LectureParametres("Parametres0.txt").get(8);
		String TextesEtiq4=LectureFichierTexte.LectureParametres("Parametres0.txt").get(11);
		String TextesEtiq5=LectureFichierTexte.LectureParametres("Parametres0.txt").get(12);
		String[] data1 = TextesEtiq1.split(",");
		String[] data2 = TextesEtiq2.split(",");
		String[] data3 = TextesEtiq3.split(",");
		String[] data4 = TextesEtiq4.split(",");
		String[] data5 = TextesEtiq5.split(",");
		DisplayArray(data1);
		DisplayArray(data2);
		DisplayArray(data3);
		DisplayArray(data4);
		DisplayArray(data5);
		List<InstancePronom> ListInstanceEtiq=new ArrayList<InstancePronom>();
		int NumPron=0;
		ConstructFileArffPrNonRef1 cc1 = new ConstructFileArffPrNonRef1();
		Instances instances1=cc1.CreationCorpus1("Etiq",data1);
		//cc1.CreerFichier("CorpusEtiquete1","Etiq");
		//System.out.println("nbr instances 1: "+instances1.numInstances()+" NumPronom: "+NumPron);
		//DisplayList(ListInstanceEtiq);
		
		ConstructFileArffPrNonRef2 cc2 = new ConstructFileArffPrNonRef2();
		Instances instances2=cc2.CreationCorpus("Etiq",data2);
		//cc1.CreerFichier("CorpusEtiquete2","Etiq");
		System.out.println("nbr instances 2: "+instances2.numInstances());
		DisplayList(ListInstanceEtiq);
		
		ConstructFileArffPrNonRef3 cc3 = new ConstructFileArffPrNonRef3();
		Instances instances3=cc3.CreationCorpus1("Etiq",data3,"Litteraire");
		System.out.println("nbr instances 3: "+instances3.numInstances());
		
		ConstructFileArffPrNonRef3 cc4 = new ConstructFileArffPrNonRef3();
		Instances instances4=cc4.CreationCorpus1("Etiq",data4,"Litteraire");
		System.out.println("nbr instances 4: "+instances4.numInstances());
		
		ConstructFileArffPrNonRef3 cc5 = new ConstructFileArffPrNonRef3();
		Instances instances5=cc5.CreationCorpus1("Etiq",data5,"EcoTech");
		System.out.println("nbr instances 5: "+instances5.numInstances());
		
		instances4.addAll(instances5);
		instances3.addAll(instances4);
		instances2.addAll(instances3);
		instances1.addAll(instances2);
		System.out.println("nbr instances total:"+instances1.numInstances());
		CreerFichier(Corpus,instances1);
	}
	
}
public static void ConstructionCorpusTest(String Corpus){
	
	String TextesEtiq2=LectureFichierTexte.LectureParametres("Parametres0.txt").get(9);
	String TextesEtiq3=LectureFichierTexte.LectureParametres("Parametres0.txt").get(10);
	
	String[] data2 = TextesEtiq2.split(",");
	String[] data3 = TextesEtiq3.split(",");
	
	DisplayArray(data2);
	DisplayArray(data3);
	List<InstancePronom> ListInstanceEtiq=new ArrayList<InstancePronom>();
	int NumPron=0;
	
	ConstructFileArffPrNonRef2 cc2 = new ConstructFileArffPrNonRef2();
	Instances instances2=cc2.CreationCorpus("Etiq",data2);
	//cc1.CreerFichier("CorpusEtiquete2","Etiq");
	System.out.println("nbr instances 2: "+instances2.numInstances());
	DisplayList(ListInstanceEtiq);
	
	ConstructFileArffPrNonRef3 cc3 = new ConstructFileArffPrNonRef3();
	Instances instances3=cc3.CreationCorpus1("Etiq",data3,"Litteraire");
	System.out.println("nbr instances 3: "+instances3.numInstances());
	
	instances2.addAll(instances3);
	
	System.out.println("nbr instances total:"+instances2.numInstances());
	CreerFichier(Corpus,instances2);
}
public static void ConstructArffTestFile(String[] ListTextNonEtiq, String CorpusNonEtiq){

	
		//List<InstancePronom> ListInstanceNomEtiq=new ArrayList<InstancePronom>();
		//int NumPronom=0;
		//String CorpusNonEtiq="CorpusNonEtiqueteFinal";
		//String TextesNonEtiq1=LectureFichierTexte.LectureParametres().get(5);
		//String[] data = TextesNonEtiq1.split(",");
		DisplayArray(ListTextNonEtiq);
		ConstructFileArffPrNonRef1 cc = new ConstructFileArffPrNonRef1();
		Instances instances1=cc.CreationCorpus1("Etiq",ListTextNonEtiq);
		//System.out.println("nbr instances : "+instances1.numInstances()+" List inst:"+ListInstanceNomEtiq.size());
		CreerFichier(CorpusNonEtiq,instances1);
		
	
}
public static void ConstructArffUnlabeldFile(String[] ListTextNonEtiq, String CorpusNonEtiq){

	
	//List<InstancePronom> ListInstanceNomEtiq=new ArrayList<InstancePronom>();
	//int NumPronom=0;
	//String CorpusNonEtiq="CorpusNonEtiqueteFinal";
	//String TextesNonEtiq1=LectureFichierTexte.LectureParametres().get(5);
	//String[] data = TextesNonEtiq1.split(",");
	DisplayArray(ListTextNonEtiq);
	ConstructFileArffPrNonRef1 cc = new ConstructFileArffPrNonRef1();
	Instances instances1=cc.CreationCorpus1("NonEtiq",ListTextNonEtiq);
	//System.out.println("nbr instances : "+instances1.numInstances()+" List inst:"+ListInstanceNomEtiq.size());
	CreerFichier(CorpusNonEtiq,instances1);
	

}

public static void CreerFichier(String texte, Instances corpus){
	  try{
	    //BufferedWriter writer = new BufferedWriter(new FileWriter(
	        //texte.substring(0, texte.indexOf(".")).concat(".arff")));
		//BufferedWriter writer = new BufferedWriter(new FileWriter(
	     // texte.concat(".arff")));
		BufferedWriter writer = new BufferedWriter(new FileWriter(texte));
	    writer.write(corpus.toString());
	    writer.flush();
	    writer.close();
	  }
	  catch (Exception e){}

}

public static void DisplayArray(String[] data){
	for(int i=0;i<data.length;i++){
		System.out.println(data[i]);
	}
}

public static void DisplayList(List<InstancePronom> data){
	for(int i=0;i<data.size();i++){
		System.out.print(data.get(i).getIdentifiant()+" ");
	}
}
}





