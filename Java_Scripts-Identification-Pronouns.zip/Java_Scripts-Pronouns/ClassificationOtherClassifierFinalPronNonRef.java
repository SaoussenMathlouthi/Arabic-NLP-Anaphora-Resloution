package classificationSVM;

//package Main;


import weka.classifiers.AbstractClassifier;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import libsvm.*;

import java.io.*;
import java.util.*;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;
import org.xml.sax.SAXException;



import weka.core.*;
import weka.classifiers.Evaluation;
import weka.classifiers.bayes.NaiveBayes;
import weka.classifiers.evaluation.Prediction;
import weka.classifiers.functions.LibSVM;
import weka.classifiers.functions.Logistic;
import weka.classifiers.lazy.IBk;
import weka.classifiers.meta.FilteredClassifier;
import weka.classifiers.trees.J48;
import weka.core.Instances;
import weka.core.converters.ArffSaver;
import weka.core.converters.ConverterUtils.DataSource;
import weka.filters.supervised.instance.SMOTE;



public class ClassificationOtherClassifierFinalPronNonRef {
	static Instances FileUnlabelTemp = null;
    static Instance inst1 = new DenseInstance(10);
  public ClassificationOtherClassifierFinalPronNonRef() {
  }

  public static void main(String[] argv) throws Exception
  {
	  
	  //String FileLabled="LabledCorpora.arff";
	  //String FileUnlabled="UnlabledCorpora.arff";
	  //String FileTemp="FileUnlabelTemp.arff";
	  
	  /*String FileTrainNonEtiq="TestBigData.arff";
	  String FileTrainNonEtiqSmote="TestBigDataSmote4200.arff";
	  String FileTrainEtiq="TrainDataNoyau.arff";
	  String FileTest="TestCorpus.arff";*/
	  //String FileTest="TestBigDataAncien.arff";
	  
	  //String FileTrainNonEtiq="TestBigData.arff";
	  //String FileTrainNonEtiqSmote="TestBigDataSmote4200.arff";
	  //String FileTrainEtiq="TrainDataNoyauSmote300.arff";
	  //String FileTest="TestCorpusSmote300.arff";
	  
	  String FileTrainNonEtiq="TrainNonEtiq_2emeExpr.arff";
	  String FileTrainNonEtiqSmote="TrainNonEtiq_2emeExprSmote7000.arff";
	  String FileTrainNonEtiqDuplic="TrainNonEtiq_2emeExprDuplic.arff";
	  
	  String FileTrainEtiq="TrainEtiq_2emeExpr.arff";
	  //String FileTrainEtiq="TrainEtiq_2emeExprDuplic.arff";
	  //String FileTrainEtiqInitial="TrainEtiq_2emeExpr_Noyau.arff";
	  
	  //String FileTest="Test_2emeExpr.arff";
	  String FileTest="Test_2emeExpr_Duplic.arff";
	  
	  //ConstructionCorpusEtiq(FileTrainEtiq);
	  //ConstructionCorpusNonEtiq(FileTrainNonEtiq);
	  				//DuplicationInstNonRef(FileTrainNonEtiq);
	  //ConstructionARFF.ConstructionCorpusTest(FileTest);
	  
	  WriteTxtFile.CreateWriteTxtFile("ListeProbabilit�s.txt", "");
	  WriteTxtFile.CreateWriteTxtFile("EvaluationTest.txt", "");
	  
	  //26/07/2020
	  String FileDist="ResultatValDist.txt";
	  String FileCos="ResultatValCos.txt";
      WriteTxtFile.CreateWriteTxtFile(FileDist, "");
      WriteTxtFile.CreateWriteTxtFile(FileCos, "");
	  int num_classifier=3;
	  ClassificationAutresClassifieurs(FileTrainEtiq,FileTrainNonEtiqSmote,FileTest,num_classifier);
	  EvaluateCrossValidationTrainingClassifier(FileTrainEtiq,num_classifier);
	  EvaluateTestOnTrainingClassifier(FileTrainEtiq,FileTest,num_classifier);
  }
	 
  
  
  public static void ClassificationAutresClassifieurs(String FileTrain,String FileTrainNonEtiq, String FileTest,int num_classifier) throws FileNotFoundException, IOException{
	  int iteration=1;
     
    //String TextesNonEtiq=LectureFichierTexte.LectureParametres("Parametres0.txt").get(6);
    //String[] dataNonEtiq = TextesNonEtiq.split(",");    
       
    //Classification selftrain 1: KNN	  
	
	String FileArff=ClassificationSelfTrainOtherClassifier_final.SelfTrainingVariousClassifier(FileTrain, FileTrainNonEtiq, FileTest, iteration,num_classifier);
	//String FileArff=ClassificationSelfTrainOtherClassifier.SelfTrainingVariousClassifier(FileTrain, FileTrainNonEtiq, FileTest, iteration,num_classifier);
	System.out.println("classification termin�! fichier final "+FileArff);
	System.out.println(MethodeUtile.currentTime());
  }
  
  
  
  
  public static void EvaluateTestOnTrainingClassifier(String FileLabled,String FileTestCorpus, int num_classifier){
	  try{
	  
	  BufferedReader BrTain=new BufferedReader(new FileReader(FileLabled));  
	  Instances train = new Instances(BrTain);	//Donn�es �tiquet�es
      System.out.println("instance file label "+FileLabled+":"+train.numInstances());
      
      BufferedReader BrUnlabeled=new BufferedReader(new FileReader(FileTestCorpus));  
      Instances test = new Instances(BrUnlabeled);	//Donn�es non �tiquet�es
      System.out.println("instance file unlabel "+FileTestCorpus+":"+test.numInstances());
      
      train.setClassIndex(train.numAttributes()-1);
      test.setClassIndex(test.numAttributes()-1);
      /*
       * Construction du classifieur svm
       */
 
      WekaPackageManager.loadPackages( false, true, false );
      Classifier classifier=null;
      switch(num_classifier) {
        case 1:
        	IBk knn = new IBk();
        	String[] options = new String[2];
        	options[0]= "-E";
        	options[1]= "-I";
        	knn.setOptions(options);
        	knn.setKNN(1);
        	knn.setCrossValidate(true);
        	classifier=knn;
        case 2:
        	NaiveBayes NB= new NaiveBayes();		        	
        	NB.setOptions(weka.core.Utils.splitOptions(""));
        	//NB.setCrossValidate(true);
        	classifier=NB;
        case 3:
        	Logistic lg = new Logistic();
        	lg.setOptions(Utils.splitOptions("-R 1.0E-8 -M -1"));
        	classifier=lg;
        case 4:
        	J48 j48 = new J48();
        	classifier=j48;
    }
      
      classifier.buildClassifier(train);System.out.println("entrainement du classifieur choisi");
            
	  Evaluation evaltest = new Evaluation(train);
      evaltest.evaluateModel(classifier,  test);
      IncorrectInstances(evaltest,test);
      
      System.out.println("evaluation test set");
      System.out.println(evaltest);
      System.out.println(evaltest.toSummaryString());
      System.out.println(evaltest.toClassDetailsString());
      System.out.println(evaltest.toMatrixString());
      double WeightPrecisionTest=evaltest.weightedPrecision();
      System.out.println("Precision classification corpus de test:"+WeightPrecisionTest);
 	}
 	catch(Exception e){System.out.println(e);}
  }
  
  public static void EvaluateCrossValidationTrainingClassifier(String FileLabled,int num_classifier){
	  try{
	  
		  Random rand = new Random(1); // using seed = 1
	      int folds = 10;
		  BufferedReader BrTain=new BufferedReader(new FileReader(FileLabled));  
		  Instances train = new Instances(BrTain);	//Donn�es �tiquet�es
	      System.out.println("instance file label "+FileLabled+":"+train.numInstances());
	      
	           
	      train.setClassIndex(train.numAttributes()-1);
	     
	      /*
	       * Construction du classifieur svm
	       */
	 
	      WekaPackageManager.loadPackages( false, true, false );
	      Classifier classifier=null;
	      switch(num_classifier) {
	        case 1:
	        	IBk knn = new IBk();
	        	String[] options = new String[2];
	        	options[0]= "-E";
	        	options[1]= "-I";
	        	knn.setOptions(options);
	        	knn.setKNN(1);
	        	knn.setCrossValidate(true);
	        	classifier=knn;
	        case 2:
	        	NaiveBayes NB= new NaiveBayes();		        	
	        	NB.setOptions(weka.core.Utils.splitOptions(""));
	        	//NB.setCrossValidate(true);
	        	classifier=NB;
	        case 3:
	        	Logistic lg = new Logistic();
	        	lg.setOptions(Utils.splitOptions("-R 1.0E-8 -M -1"));
	        	classifier=lg;
	        case 4:
	        	J48 j48 = new J48();
	        	classifier=j48;
	    }
	      
	      classifier.buildClassifier(train);System.out.println("entrainement du classifieur choisi");
	      
	      Evaluation eval = new Evaluation(train);
	      eval.crossValidateModel(classifier, train, folds, rand);
	      
	      System.out.println("evaluation Cross validation");
	      System.out.println(eval);
	      System.out.println(eval.toSummaryString());
	      System.out.println(eval.toClassDetailsString());
	      System.out.println(eval.toMatrixString());
	      System.out.println("Precision classification cross validation:"+eval.weightedPrecision());   
	       
 	}
 	catch(Exception e){System.out.println(e);}
  }
  public static void IncorrectInstances(Evaluation evaltest,Instances testData) throws FileNotFoundException, IOException{
	  String NameFile="IncorrectInstances.txt";
	  WriteTxtFile.CreateWriteTxtFile(NameFile, "");
  ArrayList<Prediction> predictions = evaltest.predictions();
  for (int i = 0, testDataSize = testData.size(); i < testDataSize; i++) {
          Instance instance = testData.get(i);
          Prediction prediction = predictions.get(i);
          
          if (prediction.actual() != prediction.predicted()) {

              System.out.println(instance);
              WriteTxtFile.WriteToTxtFile(NameFile, i+" "+instance.toString());
              //double[] predictionDistribution=svm.distributionForInstance(Unlabel.instance(i));
          }

      }
  }
  public static void  AfficherNbrInstParClasse(Instances train){
	  int nbInst0=0;
	  int nbInst1=0;
	  for(int i=0;i<train.numInstances();i++){
		  if(train.instance(i).classAttribute().value(0).equals("0")){
			  nbInst0++;
		  }
		  if(train.instance(i).classIndex()==1){
			  nbInst1++;
		  }
	  }
	  System.out.println(nbInst0 +" "+nbInst1);
	  
  }
  public static String DuplicationInstNonRef(String FileTrainNonEtiq){
	  String FinalFile=new String();
	  FinalFile=FileTrainNonEtiq.substring(0, FileTrainNonEtiq.indexOf(".")).concat("Duplic").concat(".arff");
	  int NbrDuplic=20;
	  try {
		  
		  BufferedReader BrFile=new BufferedReader(new FileReader(FileTrainNonEtiq));  
	      Instances InstFile = new Instances(BrFile);
	      InstFile.setClassIndex(InstFile.numAttributes()-1);
	      System.out.println(FileTrainNonEtiq);
	      ArffSaver saver = new ArffSaver();
	      saver.setInstances(InstFile);
	      saver.setFile(new File(FinalFile));
	      saver.writeBatch();
	      
	      BufferedWriter BwNewFile=new BufferedWriter(new FileWriter(FinalFile,true));   
	      
			for(int i=0;i<InstFile.numInstances();i++){
				//System.out.println(InstFile.classAttribute().value( (int) InstFile.instance(i).classValue()));
				 
				if(InstFile.instance(i).toString(InstFile.classIndex()).equals("0")){
					
					  for(int j=0;j<NbrDuplic;j++){
						  BwNewFile.write("\n"+InstFile.instance(i).toString());	
					  }//Dupliquer l'instance choisie
				  }
			  }
			
			BwNewFile.close();
			BrFile.close();
			System.out.println(" Duplication termin�e");
			Instances insts = new Instances(new BufferedReader(new FileReader(FinalFile)));	//Donn�es �tiquet�es
		    System.out.println("instance duplicated file unlabeled"+insts.numInstances());
			
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return FinalFile;
  }
  public static void DisplayArray(String[] data){
		for(int i=0;i<data.length;i++){
			System.out.println(data[i]);
		}
	}
  }