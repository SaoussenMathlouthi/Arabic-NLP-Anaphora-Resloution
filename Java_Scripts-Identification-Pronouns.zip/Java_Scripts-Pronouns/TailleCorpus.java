package classificationSVM;

import java.util.ArrayList;
import java.util.List;

import org.jdom2.Element;

import weka.core.DenseInstance;
import weka.core.Instance;

public class TailleCorpus {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*String[] ListTextes= new String[8];
		ListTextes[0]="texteE2SegEtiqAnaphEllip.xml";
		ListTextes[1]="texteE4SegEtiqAnaphEllip.xml";
		ListTextes[2]="texteE6SegEtiqAnaphEllip.xml";
		ListTextes[3]="texteM1_1SegEtiqAnaphEllip.xml";
		ListTextes[4]="texteM1_2SegEtiqAnaphEllip.xml";
		ListTextes[5]="texteM2SegEtiqAnaphEllip.xml";
		ListTextes[6]="texteM3SegEtiqAnaphEllip.xml";
		ListTextes[7]="texteM4SegEtiqAnaphEllip.xml";
		TailleCopusEllip(ListTextes);*/
		
		/*String[] ListTextes= new String[5];
		ListTextes[0]="fichierResultat1.xml";
		ListTextes[1]="fichierResultat2.xml";
		ListTextes[2]="fichierResultat3.xml";
		ListTextes[3]="fichierResultat4.xml";
		ListTextes[4]="fichierResultat5.xml";
		TailleCopusEllip(ListTextes);*/
		
		String[] ListTextes= new String[1];
		//ListTextes[0]="textePronNonReferentiel1.xml";
		//ListTextes[1]="textePronNonReferentielP1Modif.xml";
		//ListTextes[2]="texte3PronNonRef.xml";
		ListTextes[0]="texte2PronNonRef.xml";
		TailleCopusenPron(ListTextes);
	}
	public static void TailleCopusenPron(String[] ListTextes){
		String texte=new String();	   
	    
	    String type_verb=new String();
	    Phrase ph = new Phrase();
	    Mot m=new Mot();
	    List mots=new ArrayList<Mot>();
	    int nbr_ref;
	    int nbr_non_ref;
	    int nbr_pron;
	   
	    int nbr_mots=0;
	    for(int t=0;t<ListTextes.length;t++){
	    	//texte="test2SegV4Res.xml";
	      texte=ListTextes[t];
		  Texte txt = new Texte();
		  txt.nomfichier=texte;
		  List phs = txt.ExtractPhrase();
		  if(phs.size()==0)
			  phs = txt.ExtractPhrase2();
		  System.out.println("nbr phrase:"+phs.size());
		  nbr_non_ref=0;
		  nbr_ref=0;
		  nbr_pron=0;
		  //Iterator i = phs.iterator();
		  //while(i.hasNext()){
		  String clas = new String();
		  for(int i=0;i<phs.size();i++){
		    ph = new Phrase();
		    ph.phrase=(Element)phs.get(i);
		    //System.out.println(ph.TextePhrase2());
		    mots=ph.ExtraireMots2();
		    //String[] dataWord =ph.TextePhrase2().split(" ");
	
		    //System.out.println(mots.size());
		    for(int j=0;j<mots.size();j++){
		    	nbr_mots++;
		    	m = new Mot();
				m.mot=(Element)mots.get(j);
				
				
				//System.out.println(m.ExtraireValeur());
				//if(TypeAnaphore2(m).equals("Pronom personnel attaché")){
				//if(!MethodeUtile.TypeAnaphore2(m).equals("")){
				if(!MethodeUtile.TypeAnaphore1(m).equals("")){
						String Ref=m.ExtraireRefAnaph();
						nbr_pron++;
						System.out.println("*********référentiel "+Ref);
						if(Ref.equals("non"))
							nbr_non_ref++;
						else
							nbr_ref++;
					}
				  }
			}			  
	
		  System.out.println("++++++++++++++nombre mots:"+nbr_mots);
		  System.out.println("++++++++++++++nombre inst ref:"+nbr_ref);
		  System.out.println("++++++++++++++nombre inst non ref:"+nbr_non_ref);
	    }
	}
	
}
