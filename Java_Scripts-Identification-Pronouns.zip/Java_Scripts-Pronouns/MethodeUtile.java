package classificationSVM;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import classificationSVM.Mot;

import weka.core.Instances;

public class MethodeUtile {
	public static void main(String[] args){
		int size1;
		//int size=TailleFichier("UnlabledCorpora1.arff");
		//int size=TailleFichier("CorpusNonEtiqEssai.arff");
		int sizetrain=TailleFichier("trainDataNoyau.arff");
		int sizetest=TailleFichier("testBigDataSmote4200.arff");
		int sizetestFinal=TailleFichier("TestCorpus.arff");
		System.out.println(sizetrain+" "+sizetest+" "+sizetestFinal);
		//int size3=TailleFichier("textePronNonReferentielNonEtiq.arff");
		//int size4=TailleFichier("CorpusEtiqueteEssaiSmote.arff");
		
		/*int size4=TailleFichier("testDataSmoteP100123456.arff");
		int size5=TailleFichier("testDataSmoteP1001234567.arff");
		int size6=TailleFichier("testDataSmoteP10012345678.arff");
		int size7=TailleFichier("testDataSmoteP100123456789.arff");
		int size8=TailleFichier("testDataSmoteP10012345678910.arff");*/
		
		//System.out.println(size+" "+size4+" "+size5+" "+size6+" "+size7+" "+size8);
		
		//size1=TailleFichier("CorpusNonEtiquete.arff");
		//int size2=TailleFichier("CorpusEtiquete.arff");
		//size=TailleFichier("NewFileUnlabel1.arff");
		//System.out.println(size1+" "+size2);
		//AjouterInstance("UnlabledCorpora.arff","textePronNonReferentielNonEtiq.arff",0,10);
		//AjouterInstance("LabledCorpora.arff","textePronNonReferentielEtiq.arff",10,32);
		//System.out.println(TailleFichier("FileUnlabled.arff"));
    }
	
	public static int TailleFichier(String fileName){
       System.out.println("Reading File from Java code");
       //Name of the file
       int taille=0;
       try{
          //Create object of FileReader
          FileReader inputFile = new FileReader(fileName);
          Instances fileInst = new Instances(new BufferedReader(inputFile));
          taille= fileInst.numInstances();
          
       }catch(Exception e){
          System.out.println("Error while reading file line by line:" + e.getMessage());                      
       }
       return taille;
     }
	public static void AjouterInstance(String fileName1, String fileName2, int pos1, int pos2){
	       System.out.println("Reading File from Java code");
	       //Name of the file
	       int taille=0;
	       try{
	    	   BufferedWriter BwF1=new BufferedWriter(new FileWriter(fileName1,true)); 
	    	   BufferedReader BrF2=new BufferedReader(new FileReader(fileName2)); 
	    	   	
	    	   Instances file2 = new Instances(BrF2);
	    	   if(pos2<=file2.numInstances()){
		    	   for(int i=pos1; i<pos2;i++){
		    		   BwF1.write("\n"+file2.instance(i).toString());
		    	   }
		    	   System.out.println("instances ajout�es avec succes");
	    	   }
	    	   else System.out.println("Erreur! verifier pos2");
	    	   BrF2.close();
	    	   BwF1.close();
	       }catch(Exception e){
	          System.out.println("Error while reading file line by line:" + e.getMessage());                      
	       }
	      
	     }
	
	public static String TypeAnaphore1(Mot m){
		String type=new String();
		String vgEnc;
		String vgRad;
		vgRad=m.ExtraireVGRad();
		//System.out.println("vg "+vgRad);
		if(m. ExtraireValanaphore().equals("oui")){
			/*val=m.enclitique();
			if(val.equals("hi")||val.equals("hal")||val.equals("hu")||
				val.equals("humal")||val.equals("humo")||val.equals("huna")){*/
			//System.out.println(m.ExtraireValanaphore());
			vgEnc=m.ExtraireVGEnc();
			if(vgEnc.equals("38")||vgEnc.equals("39")||vgEnc.equals("40")||vgEnc.equals("45")
					||vgEnc.equals("46")||vgEnc.equals("47"))
						type="Pronom personnel attach�";	
		}
		
		else if(m.ExtraireValanaphore1().equals("oui") && !m.ExtraireLem().equals("Mal")&& !m.ExtraireLem().equals("MaN"))
			type="Pronom relatif";
		else if (vgRad.equals("94") && (!m.ExtraireLem().equals("�aNal")) && (!m.ExtraireLem().equals("�aNoT")))
			type="pronom personnel isol� nominatif";
		else if (vgRad.equals("95"))
		type="pronom personnel isol� accusatif";
		else if (vgRad.equals("10"))
			type="pronom d�monstratif";
		
		return type;
	}
	public static String TypeAnaphore2(Mot m){
		String type=new String();
		String vgEnc;
		String vgRad;
		vgRad=m.ExtraireVGRad2();
		System.out.println("vg "+vgRad);
		if(m. ExtraireValanaphore2().equals("oui")){
			/*val=m.enclitique();
			if(val.equals("hi")||val.equals("hal")||val.equals("hu")||
				val.equals("humal")||val.equals("humo")||val.equals("huna")){*/
			System.out.println(m.ExtraireValanaphore2());
			vgEnc=m.ExtraireVGEnc2();
			if(vgEnc.equals("38")||vgEnc.equals("39")||vgEnc.equals("40")||vgEnc.equals("45")
					||vgEnc.equals("46")||vgEnc.equals("47"))
						type="Pronom personnel attach�";	
		}
		
		else if(m.ExtraireValanaphore3().equals("oui") && !m.ExtraireLem2().equals("Mal")&& !m.ExtraireLem2().equals("MaN"))
			type="Pronom relatif";
		else if (vgRad.equals("94") && (!m.ExtraireLem2().equals("�aNal")) && (!m.ExtraireLem2().equals("�aNoT")))
			type="pronom personnel isol� nominatif";
		else if (vgRad.equals("95"))
		type="pronom personnel isol� accusatif";
		else if (vgRad.equals("10"))
			type="pronom d�monstratif";
		
		return type;
	}
	 
		
		 public static String currentTime() {

		     Calendar cal = Calendar.getInstance();
		     SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		     String Time=sdf.format(cal.getTime()) ;
		     return Time;

		 }
	 
}
