package classificationSVM;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class LectureFichierTexte {
	public static void main(String[] args) throws IOException{
		List<String> chaines=new ArrayList<String>();
		//String fileName="AdjDefini.txt";
		//chaines=LectureChaines(fileName);
		String fileName="Delimiteur1.txt";
		 List<List<String>> Data=ReadFile(fileName);
		 //String[][] Params=ReadFile2(Data);
		 //System.out.println("Affichage");
		 //System.out.println(Data.size()+" "+Data.get(0).size());
		    /*for(int i=0; i<Data.size(); i++){
				for(int j=0;j<Data.get(i).size();j++){
					System.out.print(Data.get(i).get(j)+" ");
				}
				System.out.println();
			}*/
		 //System.out.println("Affichage des premi�res param�tres:");
		 //System.out.println(Data.size()+" "+Data.get(0).size());
		    /*for(int p=0; p<Parametre(Data,0).size(); p++){
					System.out.print(Parametre(Data,0).get(p)+" ");
				System.out.println();
			}*/
    }
	public static List<String> LecturePhrasesProverb(String fileName){
	       System.out.println("Reading File from Java code");
	       //Name of the file
	       List<String> phrases=new ArrayList<String>();
	       //String fileName="AdjDefini.txt";
	       try{

	          //Create object of FileReader
	          FileReader inputFile = new FileReader(fileName);

	          //Instantiate the BufferedReader Class
	          BufferedReader bufferReader = new BufferedReader(inputFile);

	          //Variable to hold the one line data
	          String line;

	          // Read file line by line and print on the console
	          
	          while ((line = bufferReader.readLine()) != null)   { 
	        	  phrases.add(line);
	          }
	          //Close the buffer reader
	          bufferReader.close();
	       }catch(Exception e){
	          System.out.println("Error while reading file line by line:" + e.getMessage());                      
	       }
	       return phrases;
	     }
	public static List<String> LectureParametres( String fileName){
	       System.out.println("Reading File from Java code");
	       //Name of the file
	       List<String> Constantes=new ArrayList<String>();
	       //String fileName="Parametres.txt";
	       try{

	          //Create object of FileReader
	          FileReader inputFile = new FileReader(fileName);

	          //Instantiate the BufferedReader Class
	          BufferedReader bufferReader = new BufferedReader(inputFile);

	          //Variable to hold the one line data
	          String line;

	          // Read file line by line and print on the console
	          
	          while ((line = bufferReader.readLine()) != null)   {
	            String val=line.substring(line.indexOf(":")+1);
	            Constantes.add(val);
	          }
	          //Close the buffer reader
	          bufferReader.close();
	       }catch(Exception e){
	          System.out.println("Error while reading file line by line:" + e.getMessage());                      
	       }
	       return Constantes;
	     }
	public static int NumberofSpace(String str){
		int spaceCount = 0;
		for (char c : str.toCharArray()) {
		    if (c == ' ') {
		         spaceCount++;
		    }
		}
		return spaceCount;
	}
	public static List<String> Parametre(List<List<String>> Data, int Num){
		List<String> ListParam=new ArrayList<String>();
		for(int i=0; i<Data.get(Num).size(); i++){
			//System.out.print("nbr d'espace:"+NumberofSpace(Data.get(Num).get(i)));
			//ListParam.add(Data.get(Num).get(i).replaceAll("\\s",""));
			ListParam.add(Data.get(Num).get(i));
		}
		return ListParam;
	}
	public static List<List<String>> ReadFile(String fileName){
	BufferedReader input = null;
	List<List<String>> txtData = new ArrayList<List<String>>();
	try 
	{
		input = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), "UTF-16"));
	    //input =  new BufferedReader(new FileReader(fileName));
	    String line = null;
	    while (( line = input.readLine()) != null)
	    {
	    	//System.out.println(line);
	    	line=line.substring(line.indexOf(":")+1,line.length());
	    	//System.out.println(line);
	        String[] data = line.split(",");
	        //System.out.println(data.length);
	        //System.out.printf(line);
	        txtData.add(Arrays.asList(data));
	    }
	   
	}
	
	catch (Exception ex)
	{
	      ex.printStackTrace();
	}
	finally 
	{
	    if(input != null)
	    {
	        try {
				input.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	}
	return txtData;
	}
	
	public static String [][] ReadFile2(List<List<String>> Data){
		BufferedReader input = null;
		String [][] txtData = new String[6][15];
		try 
		{
			 for(int i=0; i<Data.size(); i++){
					for(int j=0;j<Data.get(i).size();j++){
						txtData[i][j]=Data.get(i).get(j);
					}
					System.out.println();
				}
		   
		}
		
		catch (Exception ex)
		{
		      ex.printStackTrace();
		}
		finally 
		{
		    if(input != null)
		    {
		        try {
					input.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    }
		}
		return txtData;
		}
	
	static void lineCounter (String path) throws IOException {

        int lineCount = 0, commentsCount = 0;
        List<List<String>> txtData = new ArrayList<List<String>>();
        Scanner input = new Scanner(new File(path));
        int i=-1;
        int j=-1;
        while (input.hasNextLine()) {
            String data = input.nextLine();
            System.out.println(data);
            //if (data.startsWith("Param")) commentsCount++;
            if (data.contains("%")) {
        		  i=i+1;
        		  System.out.println("Nouveau parametre");
        		  j=0;
        		  commentsCount++;
	        }
    	  else{
    		  String val=data.substring(data.indexOf(":")+1);
    		  System.out.println(val);
    		  //MatrixParam[i][j]=val; 
    	  }
            lineCount++;
        }

        System.out.println("Line Count: " + lineCount + "\t Comments Count: " + commentsCount);
        
    }
	public static List<String> LectureChaines(String fileName){
       System.out.println("Reading File from Java code");
       //Name of the file
       List<String> chaines=new ArrayList<String>();
       //String fileName="AdjDefini.txt";
       try{

          //Create object of FileReader
          FileReader inputFile = new FileReader(fileName);

          //Instantiate the BufferedReader Class
          BufferedReader bufferReader = new BufferedReader(inputFile);

          //Variable to hold the one line data
          String line;

          // Read file line by line and print on the console
          
          while ((line = bufferReader.readLine()) != null)   {
        	  String val=line.substring(line.indexOf(":")+1);
            chaines.add(val);
          }
          //Close the buffer reader
          bufferReader.close();
       }catch(Exception e){
          System.out.println("Error while reading file line by line:" + e.getMessage());                      
       }
       return chaines;
     }
	public static String [][] LectureParam(String fileName){
	       System.out.println("Reading File from Java code");
	       //Name of the file
	       String [][] MatrixParam=new String [6][15] ;
	       //String fileName="AdjDefini.txt";
	       try{

	          //Create object of FileReader
	          FileReader inputFile = new FileReader(fileName);

	          //Instantiate the BufferedReader Class
	          BufferedReader bufferReader = new BufferedReader(inputFile);

	          //Variable to hold the one line data
	          String line;
	          
	          // Read file line by line and print on the console
	          int i=-1;
	          int j=-1;
	          while ((line = bufferReader.readLine()) != null)   {
	        	  j=j+1;
	        	  System.out.println(line);
	        	  if(line.indexOf("%")>0){
	        		  i=i+1;
	        		  System.out.println("Nouveau parametre");
	        		  j=0;
	        		  //line = bufferReader.readLine();
	        	  }
	        	  else{
	        		  String val=line.substring(line.indexOf(":")+1);
	        		  System.out.println(val);
	        		  MatrixParam[i][j]=val; 
	        	  }
	          }
	          
	          //Close the buffer reader
	          bufferReader.close();
	       }catch(Exception e){
	          System.out.println("Error while reading file line by line:" + e.getMessage());                      
	       }
	       return MatrixParam;
	     }
	public static int countLines(String filename) throws IOException {
	    LineNumberReader reader  = new LineNumberReader(new FileReader(filename));
	int cnt = 0;
	String lineRead = "";
	while ((lineRead = reader.readLine()) != null) {}

	cnt = reader.getLineNumber(); 
	reader.close();
	return cnt;
	}
	
}
