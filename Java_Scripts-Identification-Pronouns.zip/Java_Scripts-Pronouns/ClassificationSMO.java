package classificationSVM;

//package Main;

import weka.classifiers.meta.FilteredClassifier;
import weka.classifiers.AbstractClassifier;
import weka.classifiers.Evaluation;
import libsvm.*;
import weka.classifiers.trees.J48;
import weka.classifiers.trees.DecisionStump;
//import weka.classifiers.trees.Id3;
//import weka.classifiers.trees.Id3;
import weka.classifiers.bayes.NaiveBayes;
import weka.filters.unsupervised.attribute.Remove;
import java.io.*;
import java.util.*;
import weka.core.*;
import weka.classifiers.functions.SMO;
//import wlsvm.WLSVM;
//import org.jdom.*;
//import libsvm.*;
//import weka.classifiers.bayes.AODE;
import weka.classifiers.bayes.BayesNet;
//import weka.classifiers.bayes.ComplementNaiveBayes;
import weka.classifiers.bayes.NaiveBayesMultinomial;
//import weka.classifiers.bayes.NaiveBayesSimple;
import weka.classifiers.bayes.NaiveBayesUpdateable;
import weka.classifiers.functions.Logistic;
import weka.classifiers.functions.LibSVM;
//import weka.classifiers.functions.LeastMedSq;
import weka.classifiers.functions.SMO;
import weka.classifiers.functions.VotedPerceptron;
//import weka.classifiers.functions.Winnow;
//import weka.classifiers.lazy.IB1;
import weka.classifiers.lazy.IBk;
import weka.classifiers.lazy.KStar;
//import weka.classifiers.lazy.LBR;
import weka.classifiers.lazy.LWL;
//import weka.classifiers.misc.HyperPipes;
//import weka.classifiers.misc.VFI;
import weka.classifiers.rules.OneR;
import weka.classifiers.rules.M5Rules;
import weka.classifiers.rules.DecisionTable;
import weka.classifiers.rules.ZeroR;
//import weka.classifiers.trees.ADTree;
import weka.classifiers.trees.DecisionStump;
import weka.classifiers.trees.J48;
import weka.classifiers.trees.LMT;
import weka.classifiers.trees.M5P;
import weka.classifiers.trees.RandomTree;
//import weka.classifiers.functions.RBFNetwork;
import weka.classifiers.functions.MultilayerPerceptron;


public class ClassificationSMO {
  public ClassificationSMO() {
  }

  public static void main(String[] argv) throws Exception
  {
	  //ClassificationSMO("CorpusEtiquete.arff","CorpusNonEtiquete.arff");
	  ClassificationSMO("FileLabled.arff","FileUnlabled.arff");
  }
public static void ClassificationSMO(String FileTrain, String FileTest){
	  
	  
	  try {
		  Instances train = new Instances(new BufferedReader(new FileReader(FileTrain)));	//Donn�es �tiquet�es
	      System.out.println("instance file label");
	      Instances Unlabel = new Instances(new BufferedReader(new FileReader(FileTest)));	//Donn�es non �tiquet�es
	      System.out.println("instance file unlabel");
	      WekaPackageManager.loadPackages( false, true, false );
	      
		  SMO svm = new SMO(); 
		  svm.setBuildCalibrationModels(true);
		  //svm.setBuildLogisticModels(true); 
		svm.buildClassifier(train);
		for(int i =0; i<Unlabel.numInstances();i++){
			  double[] proba=svm.distributionForInstance(Unlabel.instance(i)); 
			  System.out.println("probabilit� classe 0"+proba[0]);
			  System.out.println("probabilit� classe 1"+proba[1]);
		}
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	  
	  
  }

}