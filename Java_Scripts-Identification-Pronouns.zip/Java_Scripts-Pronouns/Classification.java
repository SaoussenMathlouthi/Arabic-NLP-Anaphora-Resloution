package classificationSVM;

//package Main;

import weka.classifiers.meta.FilteredClassifier;
import weka.classifiers.Evaluation;
import libsvm.*;
import weka.classifiers.trees.J48;
import weka.classifiers.trees.DecisionStump;
//import weka.classifiers.trees.Id3;
//import weka.classifiers.trees.Id3;
import weka.classifiers.bayes.NaiveBayes;
import weka.filters.unsupervised.attribute.Remove;
import java.io.*;
import java.util.*;
import weka.core.*;
import weka.classifiers.functions.SMO;
//import wlsvm.WLSVM;
//import org.jdom.*;
//import libsvm.*;
//import weka.classifiers.bayes.AODE;
import weka.classifiers.bayes.BayesNet;
//import weka.classifiers.bayes.ComplementNaiveBayes;
import weka.classifiers.bayes.NaiveBayesMultinomial;
//import weka.classifiers.bayes.NaiveBayesSimple;
import weka.classifiers.bayes.NaiveBayesUpdateable;
import weka.classifiers.functions.Logistic;
//import weka.classifiers.functions.LeastMedSq;
import weka.classifiers.functions.SMO;
import weka.classifiers.functions.VotedPerceptron;
//import weka.classifiers.functions.Winnow;
//import weka.classifiers.lazy.IB1;
import weka.classifiers.lazy.IBk;
import weka.classifiers.lazy.KStar;
//import weka.classifiers.lazy.LBR;
import weka.classifiers.lazy.LWL;
//import weka.classifiers.misc.HyperPipes;
//import weka.classifiers.misc.VFI;
import weka.classifiers.rules.OneR;
import weka.classifiers.rules.M5Rules;
import weka.classifiers.rules.DecisionTable;
import weka.classifiers.rules.ZeroR;
//import weka.classifiers.trees.ADTree;
import weka.classifiers.trees.DecisionStump;
import weka.classifiers.trees.J48;
import weka.classifiers.trees.LMT;
import weka.classifiers.trees.M5P;
import weka.classifiers.trees.RandomTree;
//import weka.classifiers.functions.RBFNetwork;
import weka.classifiers.functions.MultilayerPerceptron;


public class Classification {
  public Classification() {
  }

  public static void main(String[] argv) throws Exception
  {
/*construction des classifieurs*/
    M5Rules m5 = new M5Rules();

  FilteredClassifier classifier = new FilteredClassifier();
    Remove rm = new Remove();
    rm.setAttributeIndices("1"); // remove 1st attribute
    J48 j48 = new J48();
    DecisionStump lmt = new DecisionStump();
    MultilayerPerceptron mp = new MultilayerPerceptron();
    NaiveBayes nb = new NaiveBayes();

    Logistic l = new Logistic();
    SMO smo = new SMO();
    libsvm.svm_model svm = new libsvm.svm_model();
    VotedPerceptron vp = new VotedPerceptron();

    IBk ibk = new IBk();
    KStar kstar = new KStar();
    M5P mp5 = new M5P();
    OneR one = new OneR();
    
    SMO sm = new SMO();
    
    j48.setUnpruned(true); // using an unpruned J48

    // meta-classifier

    FilteredClassifier fc1 = new FilteredClassifier();
    fc1.setFilter(rm);
//    fc1.setClassifier(vfi);
    FilteredClassifier fc2 = new FilteredClassifier();
    fc2.setFilter(rm);
//    fc2.setClassifier(ib1);

    FilteredClassifier fc3 = new FilteredClassifier();
    fc3.setFilter(rm);
    fc3.setClassifier(sm);

    FilteredClassifier fc4 = new FilteredClassifier();
    fc4.setFilter(rm);
    fc4.setClassifier(lmt);


    try{
    	/*
    	 * Cr�ation des donn�es d'apprentissage et des donn�es de test
    	 */
      Instances train = new Instances(
          new BufferedReader(new FileReader("train1.arff")));
      Instances test = new Instances(new BufferedReader(new FileReader(
          "texte1Seg.arff")));
      train.setClassIndex(train.numAttributes()-1);
      test.setClassIndex(test.numAttributes()-1);
          System.out.println(test.instance(0).toString());
          
          /*
           * L� on a choisi un seul classifieur de ceux construits ci-dessus,
           * c'est le classifieur IBK, pour travailler avec.
           * Il apprend alors des donn�es d'apprentissage
           */
          
      fc3.buildClassifier(train);

      double nbvrai=0;
      /*
       * Parcours du fichier de test (en format ARFF), instance par instance 
       * 
       */
      for(int i =0; i<test.numInstances();i++){
    	  /*
    	   * classification de l'instance i du fichier de test: le r�sultat est de type double
    	   */
        double pred = fc3.classifyInstance(test.instance(i));
        
        	/*
        	 * transformation du r�sultat pr�dit en chaine de caract�res
        	 */
        String arbrepred = test.classAttribute().value( (int) pred);

        System.out.println("le mot que je viens de traiter "+i);
        	/*
        	 * indentification de la classe r�elle vu que le fichier de test est �tiquet� correctement 
        	 * par les bonnes classes
        	 */
        String actuel = test.classAttribute().value( (int) test.instance(i).classValue());
        System.out.println(", actual: " + actuel );
        System.out.println("la classe pr�dite : "+arbrepred);
        
        /*
         * Comptage du nombre des instances bien class�es
         */

        if(arbrepred.equals(actuel))
        {
          nbvrai++;
        }
      }
      System.out.println(nbvrai);
      System.out.println(nbvrai/test.numInstances());

    }
    catch(Exception e){System.out.println(e);}

/*
 * Lancement d'un ensemble de classifieurs sous forme de threads
 */


  /*  FilteredClassifier fc2 = new FilteredClassifier();
    fc2.setFilter(rm);
    fc2.setClassifier(nb);

    FilteredClassifier fc3 = new FilteredClassifier();
    fc3.setFilter(rm);
    fc3.setClassifier(j48);

    FilteredClassifier fc4 = new FilteredClassifier();
    fc4.setFilter(rm);
    fc4.setClassifier(lbr);

    ThreadClassifier cp1 = new ThreadClassifier();
    ThreadClassifier cp2 = new ThreadClassifier();
    ThreadClassifier cp3 = new ThreadClassifier();
    ThreadClassifier cp4 = new ThreadClassifier();
    cp1.classifier = fc1;
    cp2.classifier = fc2;
    cp3.classifier = fc3;
    cp4.classifier = fc4;
    cp1.r = 1;
    cp2.r = 1;
    cp3.r = 1;
    cp4.r = 1;*/
   // cp1.start();

  //  cp1.start();
   // cp3.start();
  //  cp4.start();
  }

}