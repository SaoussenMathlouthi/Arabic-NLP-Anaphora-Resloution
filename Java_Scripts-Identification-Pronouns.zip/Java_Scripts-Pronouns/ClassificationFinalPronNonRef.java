package classificationSVM;

//package Main;


import weka.classifiers.AbstractClassifier;
import weka.classifiers.Evaluation;
import libsvm.*;

import java.io.*;
import java.util.*;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;
import org.xml.sax.SAXException;



import weka.core.*;
import weka.classifiers.Evaluation;
import weka.classifiers.evaluation.Prediction;
import weka.classifiers.functions.LibSVM;
import weka.classifiers.lazy.IBk;
import weka.classifiers.meta.FilteredClassifier;
import weka.core.Instances;
import weka.core.converters.ArffSaver;
import weka.core.converters.ConverterUtils.DataSource;
import weka.filters.supervised.instance.SMOTE;



public class ClassificationFinalPronNonRef {
	static Instances FileUnlabelTemp = null;
    static Instance inst1 = new DenseInstance(10);
  public ClassificationFinalPronNonRef() {
  }

  public static void main(String[] argv) throws Exception
  {
	  
	  //String FileLabled="LabledCorpora.arff";
	  //String FileUnlabled="UnlabledCorpora.arff";
	  //String FileTemp="FileUnlabelTemp.arff";
	  
	  /*String FileTrainNonEtiq="TestBigData.arff";
	  String FileTrainNonEtiqSmote="TestBigDataSmote4200.arff";
	  String FileTrainEtiq="TrainDataNoyau.arff";
	  String FileTest="TestCorpus.arff";*/
	  //String FileTest="TestBigDataAncien.arff";
	  
	  //String FileTrainNonEtiq="TestBigData.arff";
	  //String FileTrainNonEtiqSmote="TestBigDataSmote4200.arff";
	  //String FileTrainEtiq="TrainDataNoyauSmote300.arff";
	  //String FileTest="TestCorpusSmote300.arff";
	  
	  String FileTrainNonEtiq="TrainNonEtiq_2emeExpr.arff";
	  String FileTrainNonEtiqSmote="TrainNonEtiq_2emeExprSmote7000.arff";
	  String FileTrainNonEtiqDuplic="TrainNonEtiq_2emeExprDuplic.arff";
	  
	  String FileTrainEtiq="TrainEtiq_2emeExpr.arff";
	  //String FileTrainEtiq="TrainEtiq_2emeExprDuplic.arff";
	  //String FileTrainEtiqInitial="TrainEtiq_2emeExpr_Noyau.arff";
	  
	  //String FileTest="Test_2emeExpr.arff";
	  String FileTest="Test_2emeExpr_Duplic.arff";
	  
	  //ConstructionCorpusEtiq(FileTrainEtiq);
	  //ConstructionCorpusNonEtiq(FileTrainNonEtiq);
	  				//DuplicationInstNonRef(FileTrainNonEtiq);
	  //ConstructionARFF.ConstructionCorpusTest(FileTest);
	  
	  WriteTxtFile.CreateWriteTxtFile("ListeProbabilit�s.txt", "");
	  WriteTxtFile.CreateWriteTxtFile("EvaluationTest.txt", "");
	  
	  //26/07/2020
	  String FileDist="ResultatValDist.txt";
	  String FileCos="ResultatValCos.txt";
      WriteTxtFile.CreateWriteTxtFile(FileDist, "");
      WriteTxtFile.CreateWriteTxtFile(FileCos, "");
	  
      ClassificationFinal1(FileTrainEtiq,FileTrainNonEtiqSmote,FileTest);
	  //ClassificationFinal1(FileTrainEtiq,FileTrainNonEtiq,FileTest);
	  //ClassificationFinal1(FileTrainEtiq,FileTrainNonEtiqDuplic,FileTest);
	  //EvaluateInitialTrainOnTrainingSVM(FileTrainEtiq,FileTrainEtiqInitial);
	  EvaluateCrossValidationTrainingSVM(FileTrainEtiq);
	  EvaluateTestOnTrainingSVM(FileTrainEtiq,FileTest);
	  
	  //ClassificationAutresClassifieurs(FileTrainEtiq,FileTrainNonEtiqSmote);
	 // EvaluateTestOnTrainingKNN(FileTrainEtiq,FileTest);
  }
	 
  
  public static void ClassificationFinal1(String FileTrain,String FileTrainNonEtiq, String FileTest) throws FileNotFoundException, IOException{
	  int iteration=1;
     
    //String TextesNonEtiq=LectureFichierTexte.LectureParametres("Parametres0.txt").get(6);
    //String[] dataNonEtiq = TextesNonEtiq.split(",");
    
       
    //Classification selftrain SVM
	  System.out.println("Classification selftrain SVM");
	String FileArff=ClassificationSelfTrainSvmNew_final.SelfTrainingSVM(FileTrain, FileTrainNonEtiq, iteration,FileTest);	
	//String FileArff=ClassificationSelfTrainSvmNew2.SelfTrainingSVM(FileTrain, FileTrainNonEtiq, iteration);	
	System.out.println("classification termin�! fichier final "+FileArff);
	System.out.println(MethodeUtile.currentTime());
  }
  /*public static void ClassificationAutresClassifieurs(String FileTrain,String FileTest) throws FileNotFoundException, IOException{
	  int iteration=1;
     
    //String TextesNonEtiq=LectureFichierTexte.LectureParametres("Parametres0.txt").get(6);
    //String[] dataNonEtiq = TextesNonEtiq.split(",");    
       
    //Classification selftrain 1: KNN	  
	
	//String FileArff=ClassificationSelfTrainOtherClassifier.SelfTrainingVariousClassifier(FileTrain, FileTest, iteration,4);
	System.out.println("classification termin�! fichier final "+FileArff);
	System.out.println(MethodeUtile.currentTime());
  }*/
  
  public static void EvaluateTestOnTrainingSVM(String FileLabled,String FileTestCorpus){
	  try{
	  
	  BufferedReader BrTain=new BufferedReader(new FileReader(FileLabled));  
	  Instances train = new Instances(BrTain);	//Donn�es �tiquet�es
      System.out.println("instance file label "+FileLabled+":"+train.numInstances());
      
      BufferedReader BrUnlabeled=new BufferedReader(new FileReader(FileTestCorpus));  
      Instances test = new Instances(BrUnlabeled);	//Donn�es non �tiquet�es
      System.out.println("instance file unlabel "+FileTestCorpus+":"+test.numInstances());
      
      train.setClassIndex(train.numAttributes()-1);
      test.setClassIndex(test.numAttributes()-1);
      /*
       * Construction du classifieur svm
       */
 
      WekaPackageManager.loadPackages( false, true, false );
      AbstractClassifier classifier = ( AbstractClassifier ) Class.forName(
                  "weka.classifiers.functions.LibSVM" ).newInstance();
      System.out.println("construction du classifieur svm");
      LibSVM svm = (LibSVM) classifier;
      System.out.println("Setprobability");
      svm.setProbabilityEstimates(true);
      System.out.println("construction du classifieur svm termin�");
      
      //If you prefer to give options set the options like this

      //String options = ("-S 0 -K 0 -D 3 -G 0.0 -R 0.0 -N 0.5 -M 40.0 -C 1.0 -E 0.001 -P 0.1 -b 1" );
      String options = ("-S 0 -K 0 -D 3 -G 0.5 -M 40.0 -C 1.0 -E 0.001 -B 1");
      String[] optionsArray = options.split(" ");
          svm.setOptions( optionsArray );  
      //classifier.setOptions( optionsArray );
      System.out.println("Set options");
      svm.buildClassifier(train);
      //classifier.buildClassifier(train);
      System.out.println("entrainement du classifieur svm entrain� avec self training");
      
	  Evaluation evaltest = new Evaluation(train);
      //evaltest.evaluateModel(classifier,  test);
      evaltest.evaluateModel(svm,  test);
      IncorrectInstances(evaltest,test);
      
      System.out.println("evaluation test set");
      System.out.println(evaltest);
      System.out.println(evaltest.toSummaryString());
      System.out.println(evaltest.toClassDetailsString());
      System.out.println(evaltest.toMatrixString());
      double WeightPrecisionTest=evaltest.weightedPrecision();
      System.out.println("Precision classification corpus de test:"+WeightPrecisionTest);
 	}
 	catch(Exception e){System.out.println(e);}
  }
  public static void EvaluateInitialTrainOnTrainingSVM(String FileLabled, String FileTrainEtiqInitial){
	  try{
	  
	  BufferedReader BrTain=new BufferedReader(new FileReader(FileLabled));  
	  Instances train = new Instances(BrTain);	//Donn�es �tiquet�es
      System.out.println("instance file label "+FileLabled+":"+train.numInstances());
      
      BufferedReader BrlabeledInitial=new BufferedReader(new FileReader(FileTrainEtiqInitial));  
      Instances train_Init = new Instances(BrlabeledInitial);	//Donn�es non �tiquet�es
      System.out.println("instance file unlabel "+FileTrainEtiqInitial+":"+train_Init.numInstances());
      
      train.setClassIndex(train.numAttributes()-1);
      train_Init.setClassIndex(train_Init.numAttributes()-1);
      /*
       * Construction du classifieur svm
       */
 
      WekaPackageManager.loadPackages( false, true, false );
      AbstractClassifier classifier = ( AbstractClassifier ) Class.forName(
                  "weka.classifiers.functions.LibSVM" ).newInstance();
      System.out.println("construction du classifieur svm");
      LibSVM svm = (LibSVM) classifier;
      System.out.println("Setprobability");
      svm.setProbabilityEstimates(true);
      System.out.println("construction du classifieur svm termin�");
      
      //If you prefer to give options set the options like this

      //String options = ("-S 0 -K 0 -D 3 -G 0.0 -R 0.0 -N 0.5 -M 40.0 -C 1.0 -E 0.001 -P 0.1 -b 1" );
      String options = ("-S 0 -K 0 -D 3 -G 0.5 -M 40.0 -C 1.0 -E 0.001 -B 1");
      String[] optionsArray = options.split(" ");
          svm.setOptions( optionsArray );  
      //classifier.setOptions( optionsArray );
      System.out.println("Set options");
      svm.buildClassifier(train);
      //classifier.buildClassifier(train);
      System.out.println("entrainement du classifieur svm entrain� avec self training");
      
	  Evaluation evaltest = new Evaluation(train);
      //evaltest.evaluateModel(classifier,  train_Init);
      evaltest.evaluateModel(svm,  train_Init);
      IncorrectInstances(evaltest,train_Init);
      
      System.out.println("evaluation train initial");
      System.out.println(evaltest);
      System.out.println(evaltest.toSummaryString());
      System.out.println(evaltest.toClassDetailsString());
      System.out.println(evaltest.toMatrixString());
      double WeightPrecisionTest=evaltest.weightedPrecision();
      System.out.println("Precision classification corpus train initial:"+WeightPrecisionTest);
 	}
 	catch(Exception e){System.out.println(e);}
  }
  
  public static void EvaluateCrossValidationTrainingSVM(String FileLabled){
	  try{
	  
		  Random rand = new Random(1); // using seed = 1
	      int folds = 10;
		  BufferedReader BrTain=new BufferedReader(new FileReader(FileLabled));  
		  Instances train = new Instances(BrTain);	//Donn�es �tiquet�es
	      System.out.println("instance file label "+FileLabled+":"+train.numInstances());
	      
	           
	      train.setClassIndex(train.numAttributes()-1);
	     
	      /*
	       * Construction du classifieur svm
	       */
	 
	      WekaPackageManager.loadPackages( false, true, false );
	      AbstractClassifier classifier = ( AbstractClassifier ) Class.forName(
	                  "weka.classifiers.functions.LibSVM" ).newInstance();
	      System.out.println("construction du classifieur svm");
	      LibSVM svm = (LibSVM) classifier;
	      System.out.println("Setprobability");
	      svm.setProbabilityEstimates(true);
	      System.out.println("construction du classifieur svm termin�");
	      
	      //If you prefer to give options set the options like this
	
	      //String options = ("-S 0 -K 0 -D 3 -G 0.0 -R 0.0 -N 0.5 -M 40.0 -C 1.0 -E 0.001 -P 0.1 -b 1" );
	      String options = ("-S 0 -K 0 -D 3 -G 0.5 -M 40.0 -C 1.0 -E 0.001 -B 1");
	      String[] optionsArray = options.split(" ");
          svm.setOptions( optionsArray );  
	      //classifier.setOptions( optionsArray );
	      System.out.println("Set options");
	      svm.buildClassifier(train);
	      //classifier.buildClassifier(train);
	      System.out.println("entrainement du classifieur svm entrain� avec self training");
	      
	      Evaluation eval = new Evaluation(train);
	      eval.crossValidateModel(svm, train, folds, rand);
	      
	      System.out.println("evaluation Cross validation");
	      System.out.println(eval);
	      System.out.println(eval.toSummaryString());
	      System.out.println(eval.toClassDetailsString());
	      System.out.println(eval.toMatrixString());
	      System.out.println("Precision classification cross validation:"+eval.weightedPrecision());   
	       
 	}
 	catch(Exception e){System.out.println(e);}
  }
  public static void EvaluateTestOnTrainingKNN(String FileLabled,String FileTestCorpus){
	  try{
	  
	  BufferedReader BrTain=new BufferedReader(new FileReader(FileLabled));  
	  Instances train = new Instances(BrTain);	//Donn�es �tiquet�es
      System.out.println("instance file label "+FileLabled+":"+train.numInstances());
      
      BufferedReader BrUnlabeled=new BufferedReader(new FileReader(FileTestCorpus));  
      Instances test = new Instances(BrUnlabeled);	//Donn�es non �tiquet�es
      System.out.println("instance file unlabel "+FileTestCorpus+":"+test.numInstances());
      
      train.setClassIndex(train.numAttributes()-1);
      test.setClassIndex(test.numAttributes()-1);
      /*
       * Construction du classifieur svm
       */
 
      WekaPackageManager.loadPackages( false, true, false );
      IBk knn = new IBk();
      String[] options = new String[2];
      options[0]= "-E";
      options[1]= "-I";
      knn.setOptions(options);
      knn.setKNN(1);
      knn.setCrossValidate(true);
	  knn.buildClassifier(train);System.out.println("entrainement du classifieur IBK(KNN)");
            
	  Evaluation evaltest = new Evaluation(train);
      evaltest.evaluateModel(knn,  test);
      IncorrectInstances(evaltest,test);
      
      System.out.println("evaluation test set");
      System.out.println(evaltest);
      System.out.println(evaltest.toSummaryString());
      System.out.println(evaltest.toClassDetailsString());
      System.out.println(evaltest.toMatrixString());
      double WeightPrecisionTest=evaltest.weightedPrecision();
      System.out.println("Precision classification corpus de test:"+WeightPrecisionTest);
 	}
 	catch(Exception e){System.out.println(e);}
  }
  public static void IncorrectInstances(Evaluation evaltest,Instances testData) throws FileNotFoundException, IOException{
	  String NameFile="IncorrectInstances.txt";
	  WriteTxtFile.CreateWriteTxtFile(NameFile, "");
  ArrayList<Prediction> predictions = evaltest.predictions();
  for (int i = 0, testDataSize = testData.size(); i < testDataSize; i++) {
          Instance instance = testData.get(i);
          Prediction prediction = predictions.get(i);
          
          if (prediction.actual() != prediction.predicted()) {

              System.out.println(instance);
              WriteTxtFile.WriteToTxtFile(NameFile, i+" "+instance.toString());
              //double[] predictionDistribution=svm.distributionForInstance(Unlabel.instance(i));
          }

      }
  }
  public static void  AfficherNbrInstParClasse(Instances train){
	  int nbInst0=0;
	  int nbInst1=0;
	  for(int i=0;i<train.numInstances();i++){
		  if(train.instance(i).classAttribute().value(0).equals("0")){
			  nbInst0++;
		  }
		  if(train.instance(i).classIndex()==1){
			  nbInst1++;
		  }
	  }
	  System.out.println(nbInst0 +" "+nbInst1);
	  
  }
  public static String DuplicationInstNonRef(String FileTrainNonEtiq){
	  String FinalFile=new String();
	  FinalFile=FileTrainNonEtiq.substring(0, FileTrainNonEtiq.indexOf(".")).concat("Duplic").concat(".arff");
	  int NbrDuplic=20;
	  try {
		  
		  BufferedReader BrFile=new BufferedReader(new FileReader(FileTrainNonEtiq));  
	      Instances InstFile = new Instances(BrFile);
	      InstFile.setClassIndex(InstFile.numAttributes()-1);
	      System.out.println(FileTrainNonEtiq);
	      ArffSaver saver = new ArffSaver();
	      saver.setInstances(InstFile);
	      saver.setFile(new File(FinalFile));
	      saver.writeBatch();
	      
	      BufferedWriter BwNewFile=new BufferedWriter(new FileWriter(FinalFile,true));   
	      
			for(int i=0;i<InstFile.numInstances();i++){
				//System.out.println(InstFile.classAttribute().value( (int) InstFile.instance(i).classValue()));
				 
				if(InstFile.instance(i).toString(InstFile.classIndex()).equals("0")){
					
					  for(int j=0;j<NbrDuplic;j++){
						  BwNewFile.write("\n"+InstFile.instance(i).toString());	
					  }//Dupliquer l'instance choisie
				  }
			  }
			
			BwNewFile.close();
			BrFile.close();
			System.out.println(" Duplication termin�e");
			Instances insts = new Instances(new BufferedReader(new FileReader(FinalFile)));	//Donn�es �tiquet�es
		    System.out.println("instance duplicated file unlabeled"+insts.numInstances());
			
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return FinalFile;
  }
  public static void ClassificationFinal0(Boolean smoteEnable) throws FileNotFoundException, IOException{
	  int iteration=1;
      
	String FileUnlabled="CorpusNonEtiq.arff";	
	String corpusEtiq="CorpusEtiqueteFinal.arff";
	
    String TextesNonEtiq=LectureFichierTexte.LectureParametres("Parametres0.txt").get(6);
    String[] dataNonEtiq = TextesNonEtiq.split(",");
    
    
  //Construction du fichier arff �tiquet�s
   ConstructionARFF.ArffFile(true,corpusEtiq);
    System.out.println("fichier �tiquet� cr�er avec succ�s! "+corpusEtiq);
    Instances train = new Instances(new BufferedReader(new FileReader(corpusEtiq)));	//Donn�es �tiquet�es
    System.out.println("instance file label"+train.numInstances());
    
    //Construction du fichier arff Non �tiquet�s
	ConstructionARFF.ConstructArffUnlabeldFile(dataNonEtiq,FileUnlabled);
	Instances Unlabel = new Instances(new BufferedReader(new FileReader(FileUnlabled)));	//Donn�es non �tiquet�es
	System.out.println("instances file unlabel:"+Unlabel.numInstances());
    
    //Classification selftrain SVM
	/*String FileArff=ClassificationSelfTrainSvm.SelfTrainingSVM(FileLabled, FileUnlabledFiltred, iteration,smoteEnable);*/
	String FileArff=ClassificationSelfTrainSvm.SelfTrainingSVM(corpusEtiq, FileUnlabled, iteration);
	System.out.println("classification termin�! fichier final "+FileArff);
	
	//Etiquetage Ref ou NonRef des pronoms au niveau des fichiers mxl
	/*EtiquetageReferentiel(FileArff,FileUnlabledFiltred,ListInstPron);*/
	//EtiquetageReferentiel(FileArff,FileUnlabled,ListInstPron);
  }
  
  public static void ClassificationFinal(String FileLabled,String FileUnlabled,Boolean smoteEnable) throws FileNotFoundException, IOException{
	  int iteration=1;
 	  
	  Instances train = new Instances(new BufferedReader(new FileReader(FileLabled)));	//Donn�es �tiquet�es
      System.out.println("instance file label"+train.numInstances());
      
	String FileUnlabledFiltred="CorpusNonEtiqFiltre.arff";					
    String TextesNonEtiq=LectureFichierTexte.LectureParametres("Parametres.txt").get(5);
    String[] data = TextesNonEtiq.split(",");
    String[] TextesNonEtiqFiltre=new String[data.length];
    
    //Filtrage des Pronoms Non Ref de tous les fichiers xml non �tiquet�s
    System.out.println("Filtrage des Pronoms Non Ref de tous les fichiers xml non �tiquet�s");
    for(int i=0;i<data.length;i++){
      String FileUnlabledFiltre=FiltragePronNonRef.SauvegardeFiltrage1(data[i]);
      TextesNonEtiqFiltre[i]=FileUnlabledFiltre;
    }
    DisplayArray(TextesNonEtiqFiltre);
    //Construction du fichier arff Non �tiquet�s
    /*List<InstancePronom> ListInstPron=ConstructionARFF.ConstructArffUnlabeldFile(TextesNonEtiqFiltre,FileUnlabledFiltred);
    Instances Unlabel = new Instances(new BufferedReader(new FileReader(FileUnlabledFiltred)));	//Donn�es non �tiquet�es
    System.out.println("instances file unlabel:"+Unlabel.numInstances());*/
	  //List<InstancePronom> ListInstPron=ConstructionARFF.ConstructArffUnlabeldFile(TextesNonEtiqFiltre,FileUnlabledFiltred);
	  Instances Unlabel = new Instances(new BufferedReader(new FileReader(FileUnlabledFiltred)));	//Donn�es non �tiquet�es
	  System.out.println("instances file unlabel:"+Unlabel.numInstances());
    
    //Classification selftrain SVM
	/*String FileArff=ClassificationSelfTrainSvm.SelfTrainingSVM(FileLabled, FileUnlabledFiltred, iteration,smoteEnable);*/
	String FileArff=ClassificationSelfTrainSvm.SelfTrainingSVM(FileLabled, FileUnlabled, iteration);
	System.out.println("classification termin�! fichier final "+FileArff);
	
	//Etiquetage Ref ou NonRef des pronoms au niveau des fichiers mxl
	/*EtiquetageReferentiel(FileArff,FileUnlabledFiltred,ListInstPron);*/
	//EtiquetageReferentiel(FileArff,FileUnlabled,ListInstPron);
  }
  
  public static String EtiquetageReferentiel(String FileArff,String FileUnlabledFiltre,List<InstancePronom> ListInstPron){
  	String message=new String();
  	
  	try {
		Instances InstLabeled = new Instances(new BufferedReader(new FileReader(FileArff)));
		for(int i=0;i<InstLabeled.numInstances();i++){
			String Id=InstLabeled.instance(i).attribute(0).toString();
			System.out.println("ident:"+Id);
			double classe=InstLabeled.instance(i).classValue();
			System.out.println("classe:"+classe);
			if(classe==0){
			int num=Integer.parseInt(Id.substring(2, Id.length()));
			String NomTexte=ListInstPron.get(num).getTexte();
			int NumParag=ListInstPron.get(num).getNumParag();
			int NumPhr=ListInstPron.get(num).getNumPhrase();
			int NumMot=ListInstPron.get(num).getNumMot();
			
			SAXBuilder builder = new SAXBuilder();
			File xmlFile = new File(FileUnlabledFiltre);
			Document doc;
			try {
				doc = (Document) builder.build(NomTexte);
				Element rootNode = doc.getRootElement();
				Texte txt=new Texte();
				List parags=rootNode.getChildren("Paragraphe"); 
				//System.out.println("taillparag "+parags.size());
				Element parag=(Element)parags.get(NumParag);
				List phrs=parag.getChildren("Phrase");
				//System.out.println("taillphr "+phrs.size());
				//System.out.println("num phrase "+ph);
				Element phr=(Element)phrs.get(NumPhr);
				List syntags=phr.getChildren();
				List mots=new ArrayList();
				for(int s=0;s<syntags.size();s++){
					Element syntag=(Element)syntags.get(s);
					mots.addAll(syntag.getChildren());
				}
				System.out.println("taillmot "+mots.size());
				Element mot=(Element)mots.get(NumMot);
				Element candidats = new Element("ListCandidats");
				mot.addContent(candidats);
				candidats.setAttribute("Referentiel", "non");
				
				
				Format format = Format.getPrettyFormat();
				format.setEncoding("UTF-8");
			    //format.setEncoding("ISO-8859-1");
			    XMLOutputter xmlOutput = new XMLOutputter(format);
				
				// display nice nice
				//xmlOutput.setFormat(Format.getPrettyFormat());
				
				xmlOutput.output(doc, new FileWriter(NomTexte));
				// xmlOutput.output(doc, System.out);
				//update="update";
				System.out.println("File updated! instance de pronom non r�f�rentiel �tiquet�");
				
				
				//System.out.println("taillsyntag "+syntags.size());
				/*int s=0;
				int m=0;
				List mots=new ArrayList();
				while(s<syntags.size() && num!=NumMot){
					Element syntag=(Element)syntags.get(s);
					mots=syntag.getChildren();
					m=0;
					while(m<mots.size() && num!=NumMot){
						m++;
						num++;
					}
					s++;
				}
				if (num==NumMot){
					Element mot=(Element)mots.get(m);
					//System.out.println("taillmot "+mots.size());
					Element candidats = new Element("ListCandidats");
					mot.addContent(candidats);
					candidats.setAttribute("Referentiel", "non");
				}*/
				
			} catch (JDOMException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	 
			}
			
		}
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  	return message;
  	}
  
  public static void DisplayArray(String[] data){
		for(int i=0;i<data.length;i++){
			System.out.println(data[i]);
		}
	}
  }