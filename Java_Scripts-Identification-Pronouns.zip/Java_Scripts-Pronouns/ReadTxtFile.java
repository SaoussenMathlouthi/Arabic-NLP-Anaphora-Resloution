package classificationSVM;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class ReadTxtFile {
	public static void main(String[] args){
		List<String> Constantes=new ArrayList<String>();
		Constantes=LectureParametres();
    }
	
	public static List<String> LectureParametres(){
       System.out.println("Reading File from Java code");
       //Name of the file
       List<String> Constantes=new ArrayList<String>();
       String fileName="Parametres.txt";
       try{

          //Create object of FileReader
          FileReader inputFile = new FileReader(fileName);

          //Instantiate the BufferedReader Class
          BufferedReader bufferReader = new BufferedReader(inputFile);

          //Variable to hold the one line data
          String line;

          // Read file line by line and print on the console
          
          while ((line = bufferReader.readLine()) != null)   {
            String val=line.substring(line.indexOf(":")+1);
            Constantes.add(val);
          }
          //Close the buffer reader
          bufferReader.close();
       }catch(Exception e){
          System.out.println("Error while reading file line by line:" + e.getMessage());                      
       }
       return Constantes;
     }
	public static List<String> LectureParametres1(String fileName){
	       System.out.println("Reading File from Java code");
	       //Name of the file
	       List<String> Constantes=new ArrayList<String>();
	       //String fileName="Parametres.txt";
	       try{

	          //Create object of FileReader
	          FileReader inputFile = new FileReader(fileName);

	          //Instantiate the BufferedReader Class
	          BufferedReader bufferReader = new BufferedReader(inputFile);

	          //Variable to hold the one line data
	          String line;

	          // Read file line by line and print on the console
	          
	          while ((line = bufferReader.readLine()) != null)   {
	            String val=line.substring(line.indexOf(":")+1);
	            Constantes.add(val);
	          }
	          //Close the buffer reader
	          bufferReader.close();
	       }catch(Exception e){
	          System.out.println("Error while reading file line by line:" + e.getMessage());                      
	       }
	       return Constantes;
	     }
}
