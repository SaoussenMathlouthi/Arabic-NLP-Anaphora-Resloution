package classificationSVM;

//package Main;


import weka.classifiers.AbstractClassifier;
import weka.classifiers.Evaluation;
import libsvm.*;

import java.io.*;
import java.util.*;

import org.xml.sax.SAXException;

import weka.core.*;
import weka.classifiers.Evaluation;
import weka.classifiers.evaluation.Prediction;
import weka.classifiers.functions.LibSVM;
import weka.classifiers.meta.FilteredClassifier;
import weka.core.Instances;
import weka.core.converters.ArffSaver;
import weka.core.converters.ConverterUtils.DataSource;
import weka.core.pmml.Function;
import weka.filters.Filter;
import weka.filters.supervised.instance.SMOTE;
import weka.filters.unsupervised.attribute.Remove;
import weka.filters.unsupervised.attribute.ReplaceMissingValues;



public class ClassificationSelfTrainSvmNew_final {
	static Instances FileUnlabelTemp = null;
    static Instance inst1 = new DenseInstance(10);
    static String FileTestCorpus="TestCorps.arff";
  public ClassificationSelfTrainSvmNew_final() {
  }

  public static void main(String[] argv) throws Exception
  {
	  //String FileLabled="FileLabled.arff";
	  //String FileUnlabled="FileUnlabled.arff";
	  //String FileLabled="CorpusEtiquete.arff";
	  //String FileUnlabled="CorpusNonEtiquete.arff";
	  String FileLabled="LabledCorpora.arff";
	  String FileUnlabled="UnlabledCorpora.arff";
	  //String FileTemp="FileUnlabelTemp.arff";
	 	  
	  Instances train = new Instances(new BufferedReader(new FileReader(FileLabled)));	//Donn�es �tiquet�es
      System.out.println("instance file label"+train.numInstances());
      Instances Unlabel = new Instances(new BufferedReader(new FileReader(FileUnlabled)));	//Donn�es non �tiquet�es
      System.out.println("instances file unlabel:"+Unlabel.numInstances());
	  
      int iteration=1;  
      boolean smoteEnable=true;
	 /*	Instances Unlabeltemp = new Instances(new BufferedReader(new FileReader(FileTemp)));	//Donn�es non �tiquet�es
	    System.out.println("instances file unlabeltemp:"+Unlabeltemp.numInstances());
		System.out.println("fichier non �tiquet� temporaire cr�e avec succ�s");
		System.out.println("new unlabeled file:"+NewFileUnlabeled);
		Instances NewUnlabled = new Instances(new BufferedReader(new FileReader(NewFileUnlabeled)));
		System.out.println("instances new file unlabled:"+NewUnlabled.numInstances());*/
		  
	  //SelfTrainingSVM2(FileLabled, NewFileUnlabeled, FileTemp, iteration);
      //Filtrage(FileLabled, FileUnlabled);
	  //SelfTrainingSVM(FileLabled, FileUnlabled, iteration);
	  
	  
  }
  
  public static String SelfTrainingSVM(String FileLabled, String FileUnlabled, int iteration,String FileTest){
	  /*construction du classifieur*/
	  String NewFileUnlabled=new String();
	  List<InstanceProba> listProba=new ArrayList<InstanceProba>();
	  int CritJugement=Integer.parseInt(ReadTxtFile.LectureParametres1("Parametres0.txt").get(1));
	  double seuilCos=Double.parseDouble(ReadTxtFile.LectureParametres1("Parametres0.txt").get(2));
	  double seuilDist=Double.parseDouble(ReadTxtFile.LectureParametres1("Parametres0.txt").get(3));
	  int inst_max=Integer.parseInt(ReadTxtFile.LectureParametres1("Parametres0.txt").get(13));
	  int nbr_inter=Integer.parseInt(ReadTxtFile.LectureParametres1("Parametres0.txt").get(14));
	  System.out.println("Seuilcos="+seuilCos);
	  
	  String NameFile="ResultatPrecisionCrossValidation.txt";
	  String NameFile1="ResultatPrecisionTrainNonEtiq.txt";
	  String NameFileTest="ResultatPrecisionTest.txt";
	  
	  int NbInstMax0=0;
	  int NbInstMax1=0;
	  //libsvm.svm_model svm = new libsvm.svm_model();
	try{
		System.out.println("Ouverture fichiers en mode ecriture");
		  BufferedWriter BwTrain=new BufferedWriter(new FileWriter(FileLabled,true));  //Ouverture des fichiers en mode �criture
	      BufferedWriter BwUnlabled=new BufferedWriter(new FileWriter(FileUnlabled,true));
	  try{
    	/*
    	 * Cr�ation des donn�es d'apprentissage et des donn�es de test
    	 */
		  System.out.println("Ouverture fichiers en mode lecture");
    	  
		  BufferedReader BrTain=new BufferedReader(new FileReader(FileLabled));  
    	  Instances train = new Instances(BrTain);	//Donn�es �tiquet�es
	      System.out.println("instance file label "+FileLabled+":"+train.numInstances());
	      
	      BufferedReader BrUnlabeled=new BufferedReader(new FileReader(FileUnlabled));  
	      Instances Unlabel = new Instances(BrUnlabeled);	//Donn�es non �tiquet�es
	      System.out.println("instance file unlabel "+FileUnlabled+":"+Unlabel.numInstances());  
	      //filter l'attribut exclue au niveau du Unlabel
	     // Instances UnlabelFiltred=ExculdeAttribute(Unlabel);
	      BufferedReader BrTest=new BufferedReader(new FileReader(FileTest));  
	      Instances Test = new Instances(BrTest);	//Donn�es non �tiquet�es
	      System.out.println("instance file test "+FileTest+":"+Test.numInstances());  
	      
	      //26/07/2020
		  String FileDist="ResultatValDist.txt";
		  String FileCos="ResultatValCos.txt";
	      
	     if(Unlabel.numInstances()>0){
	    	 NbInstMax0=0;
		  	  //Instances UnlabelTemp = new Instances(new BufferedReader(new FileReader(FileTemp)));
		  	  //System.out.println("fichier non �tiquet� temporaire cr�e avec succ�s");
		      
		  	  //pr�parer fichier train et fichier test
		      train.setClassIndex(train.numAttributes()-1);
		      Unlabel.setClassIndex(Unlabel.numAttributes()-1);
		      Test.setClassIndex(Test.numAttributes()-1);
		      System.out.println("la 1ere instance du fichier non �tiquet�"+Unlabel.instance(0).toString());
	          
	          /*
	           * Construction du classifieur svm
	           */
	     
		      WekaPackageManager.loadPackages( false, true, false );
		      AbstractClassifier classifier = ( AbstractClassifier ) Class.forName(
		                  "weka.classifiers.functions.LibSVM" ).newInstance();
		      System.out.println("construction du classifieur svm");
		      LibSVM svm = (LibSVM) classifier;
		      System.out.println("Setprobability");
		      svm.setProbabilityEstimates(true);
		      System.out.println("construction du classifieur svm termin�");
		      
		      //If you prefer to give options set the options like this
		
		      //String options = ("-S 0 -K 0 -D 3 -G 0.0 -R 0.0 -N 0.5 -M 40.0 -C 1.0 -E 0.001 -P 0.1 -b 1" );
		      String options = ("-S 0 -K 0 -D 3 -G 0.5 -M 40.0 -C 1.0 -E 0.001 -B 1");
		      String[] optionsArray = options.split(" ");
		          svm.setOptions( optionsArray );
		      
		      //filter l'attribut exclue au niveau du train
		      //Instances trainFiltred=ExculdeAttribute(train);
		       // first attribute reflects instance id, delete it when building the classifier
		          //boolean id=true;
		          //FilteredClassifier fc = new FilteredClassifier();
		      	/*if (id)
		      	{	
		      		//filter
		      		Remove rm = new Remove();
		      		rm.setAttributeIndices("1");  // remove 1st attribute
		      		// meta-classifier
		      		
		      		fc.setFilter(rm);
		      		System.out.println("filtre 1er attribut");
		      		fc.setClassifier(svm); System.out.println("entrainement du classifieur svm");
		      		Filter impute = new ReplaceMissingValues();
		        	impute.setInputFormat(train);
		    		train = Filter.useFilter(train, impute);
		      		fc.buildClassifier(train);System.out.println("construction classifieur svm filtr�");
		      	}*/
		      	
		     svm.buildClassifier(train);System.out.println("entrainement du classifieur svm");
		      	
		          
		      //Finally train the classifier
		      //svm.buildClassifier(trainFiltred);System.out.println("entrainement du classifieur svm");
		      
		      //FilteredClassifier fc1 = new FilteredClassifier();
		      /*if (smoteEnable) {						// apply SMOTE only on training set in every iteration of cross validation
		    	  
		          SMOTE smote = new SMOTE();
		          System.out.println("1");
		          smote.setOptions(weka.core.Utils.splitOptions("-C 0 -K 5 -P 200.0 -S 1"));
		          System.out.println("2");
		          smote.setInputFormat(train);
		          System.out.println("3:"+train.numInstances());
		          fc1.setFilter(smote);
		          System.out.println("4");
		          fc1.setClassifier(svm);
		          System.out.println("5");
			      fc1.buildClassifier(train);
			      System.out.println("train apr�s smote:"+train.numInstances());
		      }*/
	          
		      Evaluation evaltest = new Evaluation(train);
		      evaltest.evaluateModel(svm,  Unlabel);
		      //evaltest.evaluateModel(classifier,  Unlabel);
		      System.out.println("evaluation train non etiq");
		      System.out.println(evaltest);
		      System.out.println(evaltest.toSummaryString());
		      System.out.println(evaltest.toClassDetailsString());
		      System.out.println(evaltest.toMatrixString());
		      double WeightPrecisionTest=evaltest.weightedPrecision();
		      //String Datatest=" Iter:"+iteration+" Preci="+WeightPrecisionTest;
		      //String Datatest=""+WeightPrecisionTest;
		      String Datatest=""+WeightPrecisionTest+" "+evaltest.weightedRecall()+" "+evaltest.weightedFMeasure();//+
		    		  //" "+evaltest.precision(0)+" "+evaltest.recall(0)+" "+evaltest.fMeasure(0)+
		    		 // " "+evaltest.precision(1)+" "+evaltest.recall(1)+" "+evaltest.fMeasure(1);
		      if(iteration==1)
		    	  {WriteTxtFile.CreateWriteTxtFile(NameFile1, Datatest);
		    	  WriteTxtFile.CreateWriteTxtFile("taille.txt", Integer.toString(train.numInstances()));}
		      else
		    	  {WriteTxtFile.WriteToTxtFile(NameFile1, Datatest);
		    	  WriteTxtFile.WriteToTxtFile("taille.txt", Integer.toString(train.numInstances()));
		    	  }
		      
		      //eval.evaluateModel(fc, test);

		      //printResults(eval);
		      //svm.buildClassifier(train);System.out.println("entrainement du classifieur svm");
		      //printResults(eval);
		      //Evaluation Test
		      System.out.println("evaluation test");
		      Evaluation evaltest_fin = new Evaluation(train);
		      //System.out.println("evaluation test set");
		      evaltest_fin.evaluateModel(svm, Test);
		      //evaltest_fin.evaluateModel(classifier, Test);
		      //IncorrectInstances(evaltest_fin,Test);
		      //System.out.println("evaluation test set");
		      System.out.println(evaltest_fin);
		      System.out.println(evaltest_fin.toSummaryString());
		      System.out.println(evaltest_fin.toClassDetailsString());
		      System.out.println(evaltest_fin.toMatrixString());		 
		      //String Datatest=" Iter:"+iteration+" Preci="+WeightPrecisionTest;
		      //String Datatest=""+WeightPrecisionTest;
		      String Datatest_fin=""+evaltest_fin.weightedPrecision()+" "+evaltest_fin.weightedRecall()+" "+evaltest_fin.weightedFMeasure(); //+
		    		 // " "+evaltest.precision(0)+" "+evaltest.recall(0)+" "+evaltest.fMeasure(0)+
		    		 // " "+evaltest.precision(1)+" "+evaltest.recall(1)+" "+evaltest.fMeasure(1);
		      if(iteration==1)
		    	  WriteTxtFile.CreateWriteTxtFile(NameFileTest, Datatest_fin);		
		      else
		    	  WriteTxtFile.WriteToTxtFile(NameFileTest, Datatest_fin);	
		      
		      //Evaluation cross validation
		      //Evaluation eval = new Evaluation(train);
		      Random rand = new Random(1); // using seed = 1
		      int folds = 10;
		      /*if(smoteEnable){
		    	  eval.crossValidateModel(fc, train, folds, rand);
		      }*/
		      System.out.println("evaluation Cross validation");
		      Evaluation eval = new Evaluation(train);
		      eval.crossValidateModel(svm, train, folds, rand);
		      //eval.crossValidateModel(classifier, train, folds, rand);
		      
		      System.out.println(eval);
		      System.out.println(eval.toSummaryString());
		      System.out.println(eval.toClassDetailsString());
		      System.out.println(eval.toMatrixString());
		      
		      double Precision0=eval.precision(0);
		      //double Precision0=0.5; //29/07/2020
		      double Precision1=eval.precision(1);
		      //double Precision1=0.5;	//29/07/2020
		      double AvgCost=eval.avgCost();
		      double WeightPrecision=eval.weightedPrecision();
		      boolean InstChoisie=false;
		      String ClassChoisie=new String();
		      double cos=1;
		      System.out.println("Valeur Pr�cision 0 et 1:"+Precision0+" "+Precision1+" Precision:"+WeightPrecision);
		      //String Data=" It�r:"+iteration+" "+WeightPrecision;
		      String Data=""+WeightPrecision+" "+eval.weightedRecall()+" "+eval.weightedFMeasure();
		      if(iteration==1)
		    	  WriteTxtFile.CreateWriteTxtFile(NameFile, Data);
		      else
		    	  WriteTxtFile.WriteToTxtFile(NameFile, Data);
	
			  /*
			   * Parcours du fichier de test (en format ARFF), instance par instance 
			   * 
			   */
		      //Premi�re m�thode calcul Centroid
		      Instances InstCentroid=SimpleKmeans.CalculCentroid(FileLabled);
		      Instance Centroid0=InstCentroid.instance(0);
		      Instance Centroid1=InstCentroid.instance(1);
		      
		      //Deuxi�me m�thode calcul Centroid
		      double[][] TwoCentroid=CalculCentroids(train);
		      double[] Centr0=TwoCentroid[0];
		      double[] Centr1=TwoCentroid[1];
		      
		      //Display_Vector(Centroid0.toDoubleArray());
		      //Display_Vector(Centr0);
		      
		      //double[] VectorCentroid01=VectorTwoPoints(Centr0,Centr1);  //Le vecteur des deux centroid
		      //double[] VectorCentroid10=VectorTwoPoints(Centr1,Centr0);  //Le vecteur des deux centroid
		      double[] VectorCentroid01=VectorTwoPoints(Centroid0.toDoubleArray(),Centroid1.toDoubleArray());  //Le vecteur des deux centroid
		      double[] VectorCentroid10=VectorTwoPoints(Centroid1.toDoubleArray(),Centroid0.toDoubleArray());  //Le vecteur des deux centroid
		      //System.out.print("VectorCentroid01:");Display_Vector(VectorCentroid01);
		      //System.out.print("VectorCentroid10:");Display_Vector(VectorCentroid10);
		      //EuclideanDistance Dist = weka.core.EuclideanDistance();
		  	  //Double distance = Dist.distance(clusterCentroid.instance(clusterNumber), Data.instance(instaceIndex));
			  //for(int i =0; i<Unlabel.numInstances();i++){
		      
		      //List<InstanceSortedByProba> ListSortedInstProba0=new ArrayList<InstanceSortedByProba>();
		      //List<InstanceSortedByProba> ListSortedInstProba1=new ArrayList<InstanceSortedByProba>();
		      List<String> ListSortedInstProba0=new ArrayList<String>();
		      List<String> ListSortedInstProba1=new ArrayList<String>();
		      double predict;
		      Prediction prediction;
		      ArrayList<Prediction> predictions;
		      double[] predictionDistribut;
		      double predictionProbability;
		      String predictionDistribution;
		      String InstSorted;
		      for(int u=0;u<Unlabel.numInstances();u++){
		    	  
		    	  predictions = evaltest.predictions();
		    	  prediction = predictions.get(u);
		    	  System.out.print("la classe pr�dite="+prediction.predicted());
		    	  
		    	  
		    	  predict = svm.classifyInstance(Unlabel.instance(u));
		    	  String predictedClass = Unlabel.classAttribute().value( (int) predict);
		    	  System.out.print(" la classe pr�dite:"+predictedClass);
		    	  
		    	  
				  predictionDistribut = svm.distributionForInstance(Unlabel.instance(u));
				  predictionProbability=0;
				  System.out.print(" P0: "+predictionDistribut[0]); System.out.println(" P1: "+predictionDistribut[1]);
				  predictionDistribution=Unlabel.classAttribute().value((int) predict);
				  if(prediction.predicted()==0){
					  predictionProbability=predictionDistribut[0];
					  if(predictionProbability>Precision0){
						  //System.out.println("Ajout instance!");
						  //InstanceSortedByProba InstP=new InstanceSortedByProba(u,predictionProbability);
						  //listProba.add(InstP);
						  //AddSortedList(ListSortedInstProba0,InstP);
						  InstSorted=String.valueOf(predictionProbability)+"/"+Integer.toString(u);
						  System.out.println(String.valueOf(predictionProbability));
						  System.out.println(Integer.toString(u));
						  System.out.println(InstSorted);
						  AddSortedList(ListSortedInstProba0,InstSorted);
					  }
				  }
				  else if (prediction.predicted()==1){
					  predictionProbability=predictionDistribut[1];
					  if(predictionProbability>Precision1){
						  //System.out.println("Ajout instance!");
						  //InstanceSortedByProba InstP=new InstanceSortedByProba(u,predictionProbability);
						  //listProba.add(InstP);
						  InstSorted=String.valueOf(predictionProbability)+"/"+Integer.toString(u);
						  System.out.println(String.valueOf(predictionProbability));
						  System.out.println(Integer.toString(u));
						  System.out.println(InstSorted);
						  AddSortedList(ListSortedInstProba1,InstSorted);
					  }
				  }
				  
				  
		      }
		      /*List<InstanceProba> ListSortedInstProba=new ArrayList<InstanceProba>();
		      ListSortedInstProba.addAll(ListSortedInstProba0);
		      ListSortedInstProba.addAll(ListSortedInstProba1);*/
		      System.out.println("taille de la liste tri�e de la classe 0:"+ListSortedInstProba0.size());//AfficherListInstProb(ListSortedInstProba0);
		      AfficherListString(ListSortedInstProba0);
		      System.out.println("********************************");
		      System.out.println("taille de la liste tri�e de la classe 1:"+ListSortedInstProba1.size());//AfficherListInstProb(ListSortedInstProba1);
		      AfficherListString(ListSortedInstProba1);
		      int x=0;
		      //int i;
		      double predictclass;
		      double predictionProba;
		      double dist1;
		      double dist2;
		      double[] Vector;
		      //String inst;
		      //double probabilite;
		      System.out.println("*************Deuxi�me �tape********************");
		      while(x<ListSortedInstProba0.size() && (NbInstMax0<inst_max)){
		    	  InstChoisie=false;
				  //String actuel = test.classAttribute().value( (int) test.instance(i).classValue());
				  //String actuel = Unlabel.instance(i).toString(Unlabel.classIndex());
		    	  String inst=ListSortedInstProba0.get(x);
		    	  //System.out.println(inst);
		    	  double probabilite=Double.valueOf(inst.substring(0,inst.indexOf("/")));
		    	  //System.out.println(probabilite);
		    	  int i=Integer.valueOf(inst.substring(inst.indexOf("/")+1,inst.length()));
		    	  System.out.println(inst+":"+probabilite+" "+i);
		    	  //predictclass=ListSortedInstProba0.get(x).getPredictClass();
		    	  //predictionProba=ListSortedInstProba0.get(x).getProbaDistrib();
				  //System.out.println("classe actuel:"+Unlabel.instance(i).classValue());
			      
				    //System.out.println("l'instance courante du fichier non �tiquet�"+Unlabel.instance(i).toString());
				    //System.out.print("Vecteur instance courante:");Display_Vector(Unlabel.instance(i).toDoubleArray());
				    dist1 = distance(Centroid0.toDoubleArray(), Unlabel.instance(i).toDoubleArray());
				    dist2 = distance(Centroid1.toDoubleArray(), Unlabel.instance(i).toDoubleArray()); 
				    System.out.println("distance instance au deux centroides:"+dist1+" "+dist2+"dist1-dist2="+Double.toString(dist1-dist2));				      
				   	WriteTxtFile.WriteToTxtFile(FileDist, Double.toString(dist1-dist2));
				    	if(CritJugement==1){
					    	//Vector=VectorTwoPoints(Centroid0.toDoubleArray(),Unlabel.instance(i).toDoubleArray());
					    	Vector=VectorTwoPoints(Centr0,Unlabel.instance(i).toDoubleArray());
					    	System.out.print("vecteur du centroid0 a l'instance courante:");Display_Vector(Vector);
					    	cos=cosineSimilarity(VectorCentroid01,Vector);
					    	WriteTxtFile.WriteToTxtFile(FileCos, Double.toString(cos)+" classe 0");
					    	System.out.println("valeur cosinus:"+cos);
					    	//System.out.println("+++");
					    	if(cos<seuilCos){	//if(cos<seuilCos|| Double.isNaN(cos)){ //28/07/2020
					    		Unlabel.instance(i).setClassValue("0");
						    	BwTrain.write("\n"+Unlabel.instance(i).toString());
						    	NbInstMax0++;
						    	//UnlabelTemp.instance(i).setDataset(train);
						    	ClassChoisie="0";
						    	InstChoisie=true;
						    	System.out.println("classe 0 choisie");
					    	}
					    	else InstChoisie=false;
				    	}
					    else if(CritJugement==2){
					    	if(dist1<dist2 && (dist2-dist1)>seuilDist){
					    		Unlabel.instance(i).setClassValue("0");
					    		BwTrain.write("\n"+Unlabel.instance(i).toString());
					    		NbInstMax0++;
						    	//UnlabelTemp.instance(i).setDataset(train);
						    	ClassChoisie="0";
						    	InstChoisie=true;
						    	System.out.println("classe 0 choisie");
					    	}
					    	else InstChoisie=false;
					    	
					    }
					    else if(CritJugement==0){
				    		Unlabel.instance(i).setClassValue("0");
					    	BwTrain.write("\n"+Unlabel.instance(i).toString());
					    	NbInstMax0++;
					    	//UnlabelTemp.instance(i).setDataset(train);
					    	ClassChoisie="0";
					    	InstChoisie=true;
					    	//System.out.println("classe 0 choisie sans aspect informative");
				    	}
				    
				    InstanceProba IP=new InstanceProba(i,0,0,InstChoisie,ClassChoisie,cos,dist1,dist2,0.0,0);
				    listProba.add(IP);
				    x++;
		      
			  }
		      System.out.println("traitement classe 1");
		      int y=0;
		      NbInstMax1=0;
		      while(y<ListSortedInstProba1.size() && (NbInstMax1<NbInstMax0)){
		    	  InstChoisie=false;
				  //String actuel = test.classAttribute().value( (int) test.instance(i).classValue());
				  //String actuel = Unlabel.instance(i).toString(Unlabel.classIndex());
		    	  //i=ListSortedInstProba1.get(y).getNumInstance();
		    	  //predictclass=ListSortedInstProba1.get(y).getPredictClass();
		    	  //predictionProba=ListSortedInstProba1.get(y).getProbaDistrib();
				  //System.out.println("classe actuel:"+Unlabel.instance(i).classValue());
		    	  String inst=ListSortedInstProba1.get(y);
		    	  //System.out.println(inst);
		    	  double probabilite=Double.valueOf(inst.substring(0,inst.indexOf("/")));
		    	  //System.out.println(probabilite);
		    	  int i=Integer.valueOf(inst.substring(inst.indexOf("/")+1,inst.length()));
		    	  System.out.println(inst+":"+probabilite+" "+i);
				    //System.out.println("l'instance courante du fichier non �tiquet�"+Unlabel.instance(i).toString());
				    //System.out.print("Vecteur instance courante:");Display_Vector(Unlabel.instance(i).toDoubleArray());
				    dist1 = distance(Centroid0.toDoubleArray(), Unlabel.instance(i).toDoubleArray());
				    dist2 = distance(Centroid1.toDoubleArray(), Unlabel.instance(i).toDoubleArray()); 
				    System.out.println("distance instance au deux centroides:"+dist1+" "+dist2);
				    System.out.println("distance instance au deux centroides:"+dist1+" "+dist2+"dist1-dist2="+Double.toString(dist1-dist2));
				   	WriteTxtFile.WriteToTxtFile(FileDist, Double.toString(dist1-dist2));
				    	if(CritJugement==1){
					    	Vector=VectorTwoPoints(Centr1,Unlabel.instance(i).toDoubleArray());
					    	//Vector=VectorTwoPoints(Centroid1.toDoubleArray(),Unlabel.instance(i).toDoubleArray());
					    	System.out.print("vecteur du centroid1 a l'instance courante:");Display_Vector(Vector);
					    	cos=cosineSimilarity(VectorCentroid10,Vector);
					    	WriteTxtFile.WriteToTxtFile(FileCos, Double.toString(cos)+" classe 1");
					    	System.out.println("valeur cosinus:"+cos);
					    	//System.out.println("+++");
					    	if(cos<seuilCos){	//if(cos<seuilCos || Double.isNaN(cos)){	//28/07/2020
					    		Unlabel.instance(i).setClassValue("1");
						    	BwTrain.write("\n"+Unlabel.instance(i).toString());
						    	NbInstMax1++;
						    	//UnlabelTemp.instance(i).setDataset(train);
						    	ClassChoisie="1";
						    	InstChoisie=true;
						    	System.out.println("classe 1 choisie");
					    	}
					    	else InstChoisie=false;
				    	}
					    else if(CritJugement==2){
					    	if(dist2<dist1 && (dist1-dist2)>seuilDist){
					    		Unlabel.instance(i).setClassValue("1");
					    		BwTrain.write("\n"+Unlabel.instance(i).toString());
					    		NbInstMax1++;
						    	//UnlabelTemp.instance(i).setDataset(train);
						    	ClassChoisie="1";
						    	InstChoisie=true;
						    	System.out.println("classe 1 choisie");
					    	}
					    	else InstChoisie=false;
					    }
					    else if(CritJugement==0){
				    		Unlabel.instance(i).setClassValue("1");
					    	BwTrain.write("\n"+Unlabel.instance(i).toString());
					    	NbInstMax1++;
					    	//UnlabelTemp.instance(i).setDataset(train);
					    	ClassChoisie="1";
					    	InstChoisie=true;
					    	System.out.println("classe 1 choisie sans aspect informative");
				    	}
				    
				    
				    InstanceProba IP=new InstanceProba(i,0,0,InstChoisie,ClassChoisie,cos,dist1,dist2,0.0,0);
				    listProba.add(IP);
				    y++;
		      
			  }
			  //AfficherListProb(listProba);
			  //WriteListProb(listProba,"ListeProbabilit�s.txt");
			  //System.out.println("Seuilcos="+seuilCos);
			  //System.out.println("Seuildist="+seuilDist);
			  BrTain.close();
			  BrUnlabeled.close();
			  NewFileUnlabled=UpdateNewFileUnlabled(FileUnlabled,listProba, iteration);
			  System.out.println(NewFileUnlabled);
			  BwTrain.close();
			  BwUnlabled.close();
			  
			  //it�ration suivante
			  iteration=iteration+1;
			  Unlabel = new Instances(new BufferedReader(new FileReader(NewFileUnlabled)));	//Donn�es non �tiquet�es
		      System.out.println("instances file unlabel:"+Unlabel.numInstances()); 
		      if(Unlabel.numInstances()>0 && iteration<=nbr_inter){
		    	  System.out.println("it�ration:"+iteration);
				  SelfTrainingSVM(FileLabled, NewFileUnlabled, iteration,FileTest);
		      }
		      else if(Unlabel.numInstances()==0) System.out.println("fichier non etiquete �puis�");
		      else System.out.println("nbr it�ration termin�");
	     }
	     else
	    	 System.out.println("fichier non etiquete �puis�");
	     
	     //Evaluation du classifieur entrain� sur TestCorpus
	     //System.out.println("Evaluation du classifieur entrain� sur TestCorpus");
	     	 
		 
	  }
	  catch(Exception e){System.out.println(e);}
	  
	 
	}
    catch(Exception e){System.out.println(e);}
	return NewFileUnlabled;
  }
  
  
  public static Instances ExculdeAttribute(Instances data){
	  Instances filtered=null;
	  try {
		  int[] attrs=new int[1];
		  attrs[0]=0;				//Exclure de la classification l'attribut identifiant de chaque instance
		  Remove remove = new Remove();
		  remove.setAttributeIndicesArray(attrs);
		  remove.setInvertSelection(false);
		  remove.setInputFormat(data);
		  filtered = Filter.useFilter(data, remove);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} // init filter
	  return filtered;
  }
 public static void AddSortedList0(List<InstanceSortedByProba> list,InstanceSortedByProba InstP){
	 /*int i=0;
	 while(i<ListSortedProba.size() && ListSortedProba.get(i).ProbaDistrib0>=InstP.ProbaDistrib0){
		 i++;
	 }
	 if(i==ListSortedProba.size() || ListSortedProba.get(i).ProbaDistrib0<InstP.ProbaDistrib0)
		 ListSortedProba.add(i,InstP);*/
	 //System.out.println("taille de la liste:"+list.size());
	 boolean insert=false;
	 if(list.size()==0){
		 list.add(InstP);
	 }
	 else
	 {
		 Double number=InstP.getProbaDistrib();
		 int i=0;
		 while (!insert && i < list.size()) {
			 if(number <= list.get(i).getProbaDistrib())
			    i++;
			 else{
				 list.add(i, InstP);
				 insert=true;
			 }
			
		 }
		 if(i >= list.size())
			 list.add(InstP);
	 }
 }
 public static void AddSortedList(List<String> list,String InstP){
	 
	 //System.out.println("taille de la liste:"+list.size());
	 boolean insert=false;
	 double proba=Double.valueOf(InstP.substring(0,InstP.indexOf("/")));
	 System.out.println("proba="+proba);
	 int index=Integer.valueOf(InstP.substring(InstP.indexOf("/")+1,InstP.length()));
	 System.out.println(InstP+":"+proba+" "+index);
	 double nc;
	 int ic;
	 String ele;
	 if(list.size()==0){
		 list.add(InstP);
	 }
	 else
	 {
		 //Double number=InstP.getProbaDistrib();
		 int i=0;
		 while (!insert && i < list.size()) {
			 ele=list.get(i);
			 nc=Double.valueOf(ele.substring(0,ele.indexOf("/")));
			 ic=Integer.valueOf(ele.substring(ele.indexOf("/")+1,ele.length()));
			 if(proba <= nc)
			    i++;
			 else{
				 list.add(i, InstP);
				 insert=true;
			 }
			
		 }
		 if(i >= list.size())
			 list.add(InstP);
	 }
 }
  /*public static void ExcludeAttr(){
	  BufferedReader datafile = new BufferedReader(new FileReader("bbcsport.arff")); 
	  BufferedReader attrfile = new BufferedReader(new FileReader("attributes.txt"));

	  Instances data = new Instances(datafile); 
	  List<Integer> myList = new ArrayList<Integer>();
	  String line;

	  while ((line = attrfile.readLine()) != null) {
	    for (int n = 0; n < data.numAttributes(); n++) {
	      if (data.attribute(n).name().equalsIgnoreCase(line)) {
	        if(!myList.contains(n)) 
	          myList.add(n); 
	      } 
	    }
	  }

	  int[] attrs = myList.stream().mapToInt(i -> i).toArray();
	  Remove remove = new Remove();
	  remove.setAttributeIndicesArray(attrs);
	  remove.setInvertSelection(false);
	  remove.setInputFormat(data); // init filter

	  Instances filtered = Filter.useFilter(data, remove);
  }*/
  public static void Distribution(){
	  /*else{
  	//UnlabelTemp.instance(i).setDataset(FileUnlabled);
  	BwUnlabled.write("\n"+Unlabel.instance(i).toString());
  	System.out.println("aucune classe choisie");
  }*/
      // Print out the true label, predicted label, and the distribution.
    //System.out.printf("%5d: true=%-10s, predicted=%-10s, distribution=", 
                    //i, actuel, prediction); 
   // Loop over all the prediction labels in the distribution.
      /*for (int predictionDistributionIndex = 0; 
           predictionDistributionIndex < predictionDistribution.length; 
           predictionDistributionIndex++)
      {
          // Get this distribution index's class label.
          String predictionDistributionIndexAsClassLabel = 
          		UnlabelTemp.classAttribute().value(
                  predictionDistributionIndex);

          // Get the probability.
          double predictionProbability = 
              predictionDistribution[predictionDistributionIndex];

          System.out.printf("[%10s : %6.3f]", 
                            predictionDistributionIndexAsClassLabel, 
                            predictionProbability );
      }
      System.out.println();*/
  /*
   * Comptage du nombre des instances bien class�es
   */
  }
  public static double[] VectorTwoInstance(Instance Inst1, Instance Inst2){
	  double[] vector=new double[37];
	  
	  return vector;
  }
  public static double cosineSimilarity(double[] vectorA, double[] vectorB) {
	    double dotProduct = 0.0;
	    double normA = 0.0;
	    double normB = 0.0;
	    for (int i = 0; i < vectorA.length; i++) {
	    	//System.out.println(vectorA[i]+" * "+vectorB[i]);
	    	if(!Double.isNaN(vectorA[i]) && !Double.isNaN(vectorB[i])){
		        dotProduct += vectorA[i] * vectorB[i];
		        normA += Math.pow(vectorA[i], 2);
		        normB += Math.pow(vectorB[i], 2);
	    	}
	    }   
	    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
	}
  
  public static void Filtrage(String FileLabled, String FileUnlabled){
	  try {
		BufferedWriter BwLabeled=new BufferedWriter(new FileWriter(FileLabled,true));		//Donn�es �tiquet�es
		BufferedReader BrUnlabeled=new BufferedReader(new FileReader(FileUnlabled));  
	    Instances Unlabel = new Instances(BrUnlabeled);	//Donn�es non �tiquet�es
	    System.out.println("instance file unlabel"); 
	    
	    for(int i =0; i<Unlabel.numInstances();i++){			//Parcourt file unlabeled
	    	
	    	
	    }
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	  
  }
  public static double distance(double[] instance1, double[] instance2) {
	    double dist = 0.0;

	    for (int i = 0; i < instance1.length; i++) {
	        double x = instance1[i];
	        double y = instance2[i];

	        if (Double.isNaN(x) || Double.isNaN(y)) {
	            continue; // Mark missing attributes ('?') as NaN.
	        }

	        dist += (x-y)*(x-y);
	    }

	    return Math.sqrt(dist);
	}
  
   public static double[][] CalculCentroids(Instances Train){
	   double [][] Centroids=new double[2][37];
	   double x0=0;
	   double x1=0;
	   int nb0=0;
	   int nb1=0;
	   for(int j=0;j<Train.numAttributes();j++){
		   for(int i =0; i<Train.numInstances();i++){
			   if(Train.instance(i).classValue()==0){
				   x0=x0+Train.instance(i).value(j);
				   nb0++;
			   }
			   else if(Train.instance(i).classValue()==1){
				   x1=x1+Train.instance(i).value(j);
				   nb1++;
			   }
		   }
		   Centroids[0][j]=x0/nb0;
		   Centroids[1][j]=x1=nb1;
	   }
	   return Centroids;
	 
 }
   public static double[] VectorTwoPoints(double[] Point0, double[] Point1){
	   double[] Vector=new double[37];
	   for(int i=0; i<Point0.length;i++){
		   Vector[i]=Point1[i]-Point0[i];
	   }
	   return Vector;
   }
  public static String UpdateNewFileUnlabled(String FileUnlabled,List<InstanceProba> listProba,int iteration){
	  String NewFileUnlabled=FileUnlabled.substring(0, FileUnlabled.indexOf("."))+Integer.toString(iteration).concat(".arff");
	  try {
		  System.out.println(NewFileUnlabled);
		  BufferedReader BrUnlabeled=new BufferedReader(new FileReader(FileUnlabled));  
	      Instances Unlabel = new Instances(BrUnlabeled);
	      int nbrInstSupp=0;
	      
			for(int i=0;i<listProba.size();i++){
				  if(listProba.get(i).InstChoisie==true){
					  Unlabel.delete(i-nbrInstSupp);				//Supprimer l'instance choisi 
					  nbrInstSupp=nbrInstSupp+1;
				      //System.out.println("Suppression; nouveau nbr d'instance"+Unlabel.numInstances());
				  }
			  }
			System.out.println("nbr inst suppr:"+nbrInstSupp);
			ArffSaver saver = new ArffSaver();
			 saver.setInstances(Unlabel);
			saver.setFile(new File(NewFileUnlabled));
			saver.writeBatch();
			System.out.println(" mis � jour termin�e");
			
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  return NewFileUnlabled; 
  }
  public static void AfficherListProb(List<InstanceProba> ListIP){
	  double DistMoy=0;
	  System.out.println ("taille de la liste des inst "+ListIP.size());
	  for(int i=0;i<ListIP.size();i++){
		  System.out.println(ListIP.get(i).NumInstance+" "+ListIP.get(i).ProbaDistrib0+" "+ListIP.get(i).ProbaDistrib1
				  +" "+ListIP.get(i).InstChoisie+" "+ListIP.get(i).getCosinus()+" "+ListIP.get(i).getDist1()+" "+ListIP.get(i).getDist2()
				  +" Difference Dist="+(ListIP.get(i).getDist1()-ListIP.get(i).getDist2()));
		  DistMoy=DistMoy+Math.abs((ListIP.get(i).getDist1()-ListIP.get(i).getDist2()));
	  }
	  System.out.println ("Dist Moyenne="+DistMoy/ListIP.size());
  }
  public static void AfficherListInstProb(List<InstanceProba> ListIP){
	  double DistMoy=0;
	  System.out.println ("taille de la liste des inst "+ListIP.size());
	  for(int i=0;i<ListIP.size();i++){
		  System.out.println(ListIP.get(i).NumInstance+" "+ListIP.get(i).ProbaDistrib0+" "+ListIP.get(i).ProbaDistrib1
				  +" "+ListIP.get(i).PredictClass+" "+ListIP.get(i).ProbaDistrib);
		  DistMoy=DistMoy+Math.abs((ListIP.get(i).getDist1()-ListIP.get(i).getDist2()));
	  }
	  System.out.println ("Dist Moyenne="+DistMoy/ListIP.size());
  }
  public static void AfficherListString(List<String> ListIP){
	  
	  System.out.println ("taille de la liste des inst "+ListIP.size());
	  for(int i=0;i<ListIP.size();i++){
		  System.out.println(ListIP.get(i));
	  }
	  
  }
  public static void WriteListProb(List<InstanceProba> ListIP,String NameFile){
	  
	  System.out.println ("taille de la liste des inst "+ListIP.size());
	  for(int i=0;i<ListIP.size();i++){
		  String data=ListIP.get(i).NumInstance+" "+ListIP.get(i).ProbaDistrib0+" "+ListIP.get(i).ProbaDistrib1
				  +" "+ListIP.get(i).InstChoisie+" "+ListIP.get(i).getCosinus()+" "+ListIP.get(i).getDist1()+" "+ListIP.get(i).getDist2()
				  +" Difference Dist="+(ListIP.get(i).getDist1()-ListIP.get(i).getDist2());
		  WriteTxtFile.WriteToTxtFile(NameFile,data);
	  }
	  
	  
  }
  public static void CreateFileLabeled(String FileLabel1, String FileLabel2){ //Ajouter des instances du FileLabel2 dans FileLabel1
 
	  try{
		  
		  //Instances F1Write = new Instances(new BufferedWriter(new FileWriter(FileLabel1)));
		  //BufferedWriter writer = new BufferedWriter(new FileWriter(FileLabel1)); 
		  FileWriter fwriter = new FileWriter(FileLabel1,true); //true will append the new instance
	      Instances F2 = new Instances(new BufferedReader(new FileReader(FileLabel2)));	
	      Instances F1 = new Instances(new BufferedReader(new FileReader(FileLabel1)));
	      int NbrInstInit=F1.numInstances();
	      int NbrInstMax=Integer.parseInt(ReadTxtFile.LectureParametres().get(0));
	      System.out.println("nbr inst max:"+NbrInstMax);
	      int i =0;
	      
	      while(i<F2.numInstances() && (NbrInstInit+i)<NbrInstMax){
	    	  //F1.add(F2.instance(i));
	    	  fwriter.write(F2.instance(i).toString()); //appends the string to the file
	    	  System.out.println("Ajout instance");
	    	  i++;
	      }
	      //writer.flush(); 
		  fwriter.close(); 
	      System.out.println("Ajout termin�");
	  }
	  catch(Exception e){System.out.println(e);}

  }
  public static void CreateFileUnLabeled(String FileUnLabel1, String FileUnLabel2){ //Ajouter des instances du FileLabel2 dans FileLabel1
	  
	  try{
		  System.out.println("Debut");
		  //Instances F1Write = new Instances(new BufferedWriter(new FileWriter(FileLabel1)));
		  //BufferedWriter writer = new BufferedWriter(new FileWriter(FileLabel1)); 
		  FileWriter fwriter = new FileWriter(FileUnLabel1,true); //true will append the new instance
		  System.out.println("commencer Ajout instance");
	      Instances F2 = new Instances(new BufferedReader(new FileReader(FileUnLabel2)));	
	      //Instances F1 = new Instances(new BufferedReader(new FileReader(FileUnLabel1)));
	      //int NbrInstInit=F1.numInstances();
	      //System.out.println("nbr instance init"+NbrInstInit);
	      int i =68;
	      while(i<F2.numInstances()){
	    	  //F1.add(F2.instance(i));
	    	  fwriter.write(F2.instance(i).toString()); //appends the string to the file
	    	  System.out.println("Ajout instance");
	    	  i++;
	      }
	      //writer.flush(); 
		  fwriter.close(); 
	      System.out.println("Ajout termin�");
	  }
	  catch(Exception e){System.out.println(e);}

  }
	   
  public static void Display_Vector(double[] Vector){
	  for(int i=0;i<Vector.length;i++){
		  System.out.print(Vector[i]+";");
	  }
	  System.out.println();
  }

}