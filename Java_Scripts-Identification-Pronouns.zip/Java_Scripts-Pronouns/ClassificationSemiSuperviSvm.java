package classificationSVM;

//package Main;


import weka.classifiers.AbstractClassifier;
import weka.classifiers.Evaluation;
import libsvm.*;

import java.io.*;
import java.util.*;
import weka.core.*;
import weka.classifiers.Evaluation;
import weka.classifiers.functions.LibSVM;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;



public class ClassificationSemiSuperviSvm {
  public ClassificationSemiSuperviSvm() {
  }

  public static void main(String[] argv) throws Exception
  {
	  /*construction du classifieur*/
    
	  libsvm.svm_model svm = new libsvm.svm_model();


    try{
    	/*
    	 * Cr�ation des donn�es d'apprentissage et des donn�es de test
    	 */
      /*Instances train = new Instances(
          new BufferedReader(new FileReader("iris.arff"))); //test2SegV4ResTrain
      Instances test = new Instances(new BufferedReader(new FileReader(
          "iris-Test.arff"))); //test1SegV3Res24Test*/
      Instances train = new Instances(
              new BufferedReader(new FileReader("FileLabled.arff"))); //
          Instances test = new Instances(new BufferedReader(new FileReader(
              "test3SegV3Resunlabel.arff"))); //
      train.setClassIndex(train.numAttributes()-1);
      test.setClassIndex(test.numAttributes()-1);
          System.out.println(test.instance(0).toString());
          
          /*
           * L� on a choisi un seul classifieur de ceux construits ci-dessus,
           * c'est le classifieur IBK, pour travailler avec.
           * Il apprend alors des donn�es d'apprentissage
           */
          WekaPackageManager.loadPackages( false, true, false );
          AbstractClassifier classifier = ( AbstractClassifier ) Class.forName(
                      "weka.classifiers.functions.LibSVM" ).newInstance();
          LibSVM s = (LibSVM) classifier;
          s.setProbabilityEstimates(true);
          
          
          //If you prefer to give options set the options like this

          //String options = ( "-S 0 -K 0 -D 3 -G 0.0 -R 0.0 -N 0.5 -M 40.0 -C 1.0 -E 0.001 -P 0.1 -b 1" );
          String options = ( "-S 0 -K 0 -D 3 -G 0.5 -M 40.0 -C 1.0 -E 0.001 -B 1" );
          String[] optionsArray = options.split( " " );
              s.setOptions( optionsArray );
          //Finally train the classifier

          s.buildClassifier(train);

      double nbvrai=0;
      /*
       * Parcours du fichier de test (en format ARFF), instance par instance 
       * 
       */
      for(int i =0; i<test.numInstances();i++){
    	  //String actuel = test.classAttribute().value( (int) test.instance(i).classValue());
    	  String actuel = 
    			  test.instance(i).toString(test.classIndex());
          System.out.println(", actual: " + actuel );
    	  /*
    	   * classification de l'instance i du fichier de test: le r�sultat est de type double
    	   */
        double pred = s.classifyInstance(test.instance(i));
        //System.out.println("classe actuel:"+test.instance(i).classValue());
        
        	/*
        	 * transformation du r�sultat pr�dit en chaine de caract�res
        	 */
        String arbrepred = test.classAttribute().value( (int) pred);

        System.out.println("le mot que je viens de traiter "+i);
        	/*
        	 * indentification de la classe r�elle vu que le fichier de test est �tiquet� correctement 
        	 * par les bonnes classes
        	 */
        //String actuel = test.classAttribute().value( (int) test.instance(i).classValue());
        //System.out.println(", actual: " + actuel );
        System.out.println("la classe pr�dite : "+arbrepred);
        System.out.println("\n");
        
        double[] predictionDistribution = 
                s.distributionForInstance(test.instance(i)); 

            // Print out the true label, predicted label, and the distribution.
            System.out.printf("%5d: true=%-10s, predicted=%-10s, distribution=", 
                              i, actuel, arbrepred); 
         // Loop over all the prediction labels in the distribution.
            for (int predictionDistributionIndex = 0; 
                 predictionDistributionIndex < predictionDistribution.length; 
                 predictionDistributionIndex++)
            {
                // Get this distribution index's class label.
                String predictionDistributionIndexAsClassLabel = 
                		test.classAttribute().value(
                        predictionDistributionIndex);

                // Get the probability.
                double predictionProbability = 
                    predictionDistribution[predictionDistributionIndex];

                System.out.printf("[%10s : %6.3f]", 
                                  predictionDistributionIndexAsClassLabel, 
                                  predictionProbability );
            }
            System.out.println();
        /*
         * Comptage du nombre des instances bien class�es
         */

        if(arbrepred.equals(actuel))
        {
          nbvrai++;
        }
      }
      System.out.println(nbvrai);
      System.out.println(nbvrai/test.numInstances());

    }
    catch(Exception e){System.out.println(e);}

/*
 * Lancement d'un ensemble de classifieurs sous forme de threads
 */


  /*  FilteredClassifier fc2 = new FilteredClassifier();
    fc2.setFilter(rm);
    fc2.setClassifier(nb);

    FilteredClassifier fc3 = new FilteredClassifier();
    fc3.setFilter(rm);
    fc3.setClassifier(j48);

    FilteredClassifier fc4 = new FilteredClassifier();
    fc4.setFilter(rm);
    fc4.setClassifier(lbr);

    ThreadClassifier cp1 = new ThreadClassifier();
    ThreadClassifier cp2 = new ThreadClassifier();
    ThreadClassifier cp3 = new ThreadClassifier();
    ThreadClassifier cp4 = new ThreadClassifier();
    cp1.classifier = fc1;
    cp2.classifier = fc2;
    cp3.classifier = fc3;
    cp4.classifier = fc4;
    cp1.r = 1;
    cp2.r = 1;
    cp3.r = 1;
    cp4.r = 1;*/
   // cp1.start();

  //  cp1.start();
   // cp3.start();
  //  cp4.start();
  }

}