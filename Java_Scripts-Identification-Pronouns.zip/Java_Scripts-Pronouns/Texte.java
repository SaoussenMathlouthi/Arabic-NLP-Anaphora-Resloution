package classificationSVM;
import java.io.*;
import java.util.*;

import org.jdom2.*;
import org.jdom2.input.*;

import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import javax.swing.*;
   
/**
 * <p>Titre : </p>
 * <p>Description : </p>
 * <p>Copyright : Copyright (c) 2010</p>
 * <p>Soci�t� : </p>
 * @author non attribuable
 * @version 1.0
 */

public class Texte {
  static public String nomfichier = "train2modifier.xml";
  
  public Texte() {
  }

  
public static Element OuvrirFichier(){
    org.jdom2.Document document;
    Element racine= new Element("Texte");

    
    
    
    SAXBuilder sxb = new SAXBuilder();

  try {
    document = sxb.build(new File(nomfichier));
    racine = document.getRootElement();
    
  

  }
  catch (Exception e) {System.out.println(e.getMessage());}

  return racine;

}
public static List ExtractParagraphe(){
    List paragraphes = new ArrayList();
    Element racine = OuvrirFichier();
    
    paragraphes = racine.getChildren("Paragraphe");
   
    return paragraphes;
  }

  public static List ExtractPhrase2(){
    List phrases = new ArrayList();
	  List parag = ExtractParagraphe();
	  Iterator i = parag.iterator();
	  while(i.hasNext()){
	    Element p = (Element) i.next();
	    List phrase = p.getChildren("Phrase");
	    for(int j=0;j<phrase.size();j++)
	    {
	      phrases.add((Element)phrase.get(j));
	    }
	  }
	  return phrases;
  }	
  
public static List ExtractPhrase(){
    List phrases = new ArrayList();
    Element racine = OuvrirFichier();
    phrases = racine.getChildren("Phrase");
	return phrases;
  }

  public static void main(String[] args) {
    // Create the empty dataset "race" with above attributes

    Texte txt = new Texte();
   // txt.nomfichier= "train2modifier.xml";
    String texte1 = txt.nomfichier.substring(0,txt.nomfichier.indexOf("."));
   
    List phs = txt.ExtractPhrase();
    List parags=txt.ExtractParagraphe();
    System.out.println(phs.size());
    for(int i=0;i<phs.size();i++){
    	Phrase ph=new Phrase();
    	ph.phrase=(Element)phs.get(i);
    	System.out.println(ph.TextePhrase());
    }
    System.out.println(parags.size());

    System.out.println("corpus cr�� avec succ�s");
    
    


  }

}

