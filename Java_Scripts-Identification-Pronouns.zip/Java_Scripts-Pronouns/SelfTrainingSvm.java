package classificationSVM;

//package Main;


import weka.classifiers.AbstractClassifier;
import weka.classifiers.Evaluation;
import libsvm.*;

import java.io.*;
import java.util.*;

import org.xml.sax.SAXException;

import weka.core.*;
import weka.classifiers.Evaluation;
import weka.classifiers.functions.LibSVM;
import weka.classifiers.meta.FilteredClassifier;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;



public class SelfTrainingSvm {
	static Instances FileUnlabelTemp = null;
    static Instance inst1 = new DenseInstance(10);
  public SelfTrainingSvm() {
  }

  public static void main(String[] argv) throws Exception
  {
	  String FileLabled="FileLabled.arff";
	  String FileUnlabled="FileUnlabled.arff";
	  //String FileLabled="CorpusEtiquete.arff";
	  //String FileUnlabled="CorpusNonEtiquete.arff";
	  String FileTemp="FileUnlabelTemp.arff";
	  //String FileTemp="test3SegV3Resunlabel.arff";
	  
	  //CreateFileLabeled(FileLabled, "test1SEgV3Res24label.arff");
	  
	  //Instances F = new Instances(new BufferedReader(new FileReader(FileLabled)));
	  //System.out.println("nbr inst finale:"+F.numInstances());
	  //Instances F = new Instances(new BufferedReader(new FileReader(FileUnlabled)));
	  //System.out.println("nbr inst init:"+Integer.toString(F.numInstances()));
	  
	  //CreateFileUnLabeled(FileUnlabled, "test1SEgV3Res24unlabel.arff");
	  
	  //Instances Fa = new Instances(new BufferedReader(new FileReader(FileUnlabled)));
	  //System.out.println("nbr inst finale:"+Integer.toString(Fa.numInstances()));
	  
	  Instances train = new Instances(new BufferedReader(new FileReader(FileLabled)));	//Donn�es �tiquet�es
      System.out.println("instance file label"+train.numInstances());
      Instances Unlabel = new Instances(new BufferedReader(new FileReader(FileUnlabled)));	//Donn�es non �tiquet�es
      System.out.println("instances file unlabel:"+Unlabel.numInstances());
	  
      int iteration=1;  
	  CreateCorpus cc = new CreateCorpus();
	  String NewFileUnlabeled=cc.CreationCorpusTemp(Unlabel,iteration); //cr�er le fichiers des donn�es non �tiquet�es temporaire
		cc.CreerFichier(FileTemp);
		System.out.println(FileTemp);
		Instances Unlabeltemp = new Instances(new BufferedReader(new FileReader(FileTemp)));	//Donn�es non �tiquet�es
	    System.out.println("instances file unlabeltemp:"+Unlabeltemp.numInstances());
		System.out.println("fichier non �tiquet� temporaire cr�e avec succ�s");
		System.out.println("new unlabeled file:"+NewFileUnlabeled);
		Instances NewUnlabled = new Instances(new BufferedReader(new FileReader(NewFileUnlabeled)));
		System.out.println("instances new file unlabled:"+NewUnlabled.numInstances());
		  
	  //SelfTrainingSVM2(FileLabled, NewFileUnlabeled, FileTemp, iteration);
	  SelfTrainingSVM3(FileLabled, NewFileUnlabeled, FileTemp, iteration);
	  
	  /*System.out.println("iteration Self training termin�e");
	  Instances train2 = new Instances(new BufferedReader(new FileReader(FileLabled)));	//Donn�es �tiquet�es
      System.out.println("instance file label final"+train2.numInstances());
      Instances Unlabel2 = new Instances(new BufferedReader(new FileReader(NewFileUnlabeled)));	//Donn�es non �tiquet�es
      System.out.println("instances file unlabel final:"+Unlabel2.numInstances());
      Instances Unlabeltemp2 = new Instances(new BufferedReader(new FileReader(FileTemp)));	//Donn�es non �tiquet�es
	  System.out.println("instances file unlabeltemp:"+Unlabeltemp2.numInstances());*/
  }
  
  public static void SelfTrainingSVM3(String FileLabled, String FileUnlabled, String FileTemp, int iteration){
	  /*construction du classifieur*/
    	 
	  //libsvm.svm_model svm = new libsvm.svm_model();
	try{
		System.out.println("Ouverture fichier en mode ecriture");
		  BufferedWriter BwTrain=new BufferedWriter(new FileWriter(FileLabled,true));  //Ouverture des fichiers en mode �criture
	      BufferedWriter BwUnlabled=new BufferedWriter(new FileWriter(FileUnlabled,true));
	  try{
    	/*
    	 * Cr�ation des donn�es d'apprentissage et des donn�es de test
    	 */
		  System.out.println("Ouverture fichier en mode lecture");
    	  BufferedReader BrTain=new BufferedReader(new FileReader(FileLabled));  
    	  Instances train = new Instances(BrTain);	//Donn�es �tiquet�es
	      System.out.println("instance file label");
	      BufferedReader BrUnlabeled=new BufferedReader(new FileReader(FileUnlabled));  
	      Instances Unlabel = new Instances(BrUnlabeled);	//Donn�es non �tiquet�es
	      System.out.println("instance file unlabel");  
	      
	     if(Unlabel.numInstances()>0){
	  	  Instances UnlabelTemp = new Instances(new BufferedReader(new FileReader(FileTemp)));
	  	  System.out.println("fichier non �tiquet� temporaire cr�e avec succ�s");
	      
	  	  //pr�parer fichier train et fichier test
	      train.setClassIndex(train.numAttributes()-1);
	      UnlabelTemp.setClassIndex(UnlabelTemp.numAttributes()-1);
	      System.out.println("la 1ere instance du fichier temporaire"+UnlabelTemp.instance(0).toString());
          
          /*
           * Construction du classifieur svm
           */
     
	      WekaPackageManager.loadPackages( false, true, false );
	      AbstractClassifier classifier = ( AbstractClassifier ) Class.forName(
	                  "weka.classifiers.functions.LibSVM" ).newInstance();
	      System.out.println("construction du classifieur svm");
	      LibSVM svm = (LibSVM) classifier;
	      System.out.println("Setprobabilit�");
	      svm.setProbabilityEstimates(true);
	      System.out.println("construction du classifieur svm termin�");
	      
	      //If you prefer to give options set the options like this
	
	      //String options = ( "-S 0 -K 0 -D 3 -G 0.0 -R 0.0 -N 0.5 -M 40.0 -C 1.0 -E 0.001 -P 0.1 -b 1" );
	      String options = ( "-S 0 -K 0 -D 3 -G 0.5 -M 40.0 -C 1.0 -E 0.001 -B 1" );
	      String[] optionsArray = options.split( " " );
	          svm.setOptions( optionsArray );
	      //Finally train the classifier
	
	      svm.buildClassifier(train);System.out.println("entrainement du classifieur svm");

		  /*
		   * Parcours du fichier de test (en format ARFF), instance par instance 
		   * 
		   */
		  for(int i =0; i<UnlabelTemp.numInstances();i++){
			  //String actuel = test.classAttribute().value( (int) test.instance(i).classValue());
			  String actuel = UnlabelTemp.instance(i).toString(UnlabelTemp.classIndex());
			  System.out.println("classe actuel:"+UnlabelTemp.instance(i).classValue());
		      
			  /*
			   * classification de l'instance i du fichier de test: le r�sultat est de type double
			   */
		    double pred = svm.classifyInstance(UnlabelTemp.instance(i));	    
		    	/*
		    	 * transformation du r�sultat pr�dit en chaine de caract�res
		    	 */
		    String prediction = UnlabelTemp.classAttribute().value( (int) pred);
		    System.out.println("classe prediction:"+prediction);
		
		    System.out.println("le mot que je viens de traiter "+i);
		    	/*
		    	 * indentification de la classe  vu que le fichier de test est non �tiquet� 
		    	 */
		    double seuil=0.6;
		    double[] predictionDistribution = 
		            svm.distributionForInstance(UnlabelTemp.instance(i)); 
		    String predictionDistribution0=UnlabelTemp.classAttribute().value(0);
		    double predictionProbability0=predictionDistribution[0];
		    System.out.println("prediction classe "+predictionDistribution0 +":"+predictionProbability0);
		    String predictionDistribution1=UnlabelTemp.classAttribute().value(1);
		    double predictionProbability1=predictionDistribution[1];
		    System.out.println("prediction classe "+predictionDistribution1 +":"+predictionProbability1);
		    if((predictionProbability0>predictionProbability1) && (predictionProbability0>seuil)){
		    	UnlabelTemp.instance(i).setClassValue("0");
		    	System.out.println("+++");
		    	BwTrain.write("\n"+UnlabelTemp.instance(i).toString());
		    	//UnlabelTemp.instance(i).setDataset(train);
		    	System.out.println("classe 0 choisie");
		    }
		    else if((predictionProbability1>predictionProbability0) && (predictionProbability1>seuil)){
		    	UnlabelTemp.instance(i).setClassValue("1");
		    	//UnlabelTemp.instance(i).setDataset(train);
		    	BwTrain.write("\n"+UnlabelTemp.instance(i).toString());
		    	System.out.println("classe 1 choisie");
		    }
		    else{
		    	//UnlabelTemp.instance(i).setDataset(FileUnlabled);
		    	BwUnlabled.write("\n"+UnlabelTemp.instance(i).toString());
		    	System.out.println("aucune classe choisie");
		    }
		        // Print out the true label, predicted label, and the distribution.
		      //System.out.printf("%5d: true=%-10s, predicted=%-10s, distribution=", 
	                          //i, actuel, prediction); 
		     // Loop over all the prediction labels in the distribution.
		        /*for (int predictionDistributionIndex = 0; 
		             predictionDistributionIndex < predictionDistribution.length; 
		             predictionDistributionIndex++)
		        {
		            // Get this distribution index's class label.
		            String predictionDistributionIndexAsClassLabel = 
		            		UnlabelTemp.classAttribute().value(
		                    predictionDistributionIndex);
		
		            // Get the probability.
		            double predictionProbability = 
		                predictionDistribution[predictionDistributionIndex];
		
		            System.out.printf("[%10s : %6.3f]", 
		                              predictionDistributionIndexAsClassLabel, 
		                              predictionProbability );
		        }
		        System.out.println();*/
		    /*
		     * Comptage du nombre des instances bien class�es
		     */
		    
		  }
		  BrTain.close();
		  BrUnlabeled.close();
		  
		  //2�me it�ration
		  iteration=iteration+1;
		  Unlabel = new Instances(new BufferedReader(new FileReader(FileUnlabled)));	//Donn�es non �tiquet�es
	      System.out.println("instances file unlabel:"+Unlabel.numInstances()); 
	      if(Unlabel.numInstances()>0){
			  CreateCorpus cc = new CreateCorpus();
			  String NewFileUnlabeled=cc.CreationCorpusTemp(Unlabel,iteration); //cr�er le fichiers des donn�es non �tiquet�es temporaire
				cc.CreerFichier(FileTemp);
				System.out.println(FileTemp);
			  SelfTrainingSVM3(FileLabled, NewFileUnlabeled, FileTemp, iteration);
	      }
	      else System.out.println("fichier non etiquete �puis�");
	     }
	     else
	    	 System.out.println("fichier non etiquete �puis�");
		 
		  //creer un fichier non �tiquet� temporaire
	      /*String NewFileUnlabeled=new String();
	      CreateCorpus cc = new CreateCorpus();
	      NewFileUnlabeled=cc.CreationCorpusTemp(Unlabel, iteration); 	//Donner le nouveau fichier unlabel apr�s suppression des instances choisis
	  	  cc.CreerFichier(FileTemp);									//cr�er le fichiers des donn�es non �tiquet�es temporaire
	      System.out.println(FileTemp);*/
	  }
	  catch(Exception e){System.out.println(e);}
	  
	  BwTrain.close();
	  BwUnlabled.close();
	}
    catch(Exception e){System.out.println(e);}


  }
  public static void SelfTrainingSVM2(String FileLabled, String FileUnlabled, String FileTemp, int iteration){
	  /*construction du classifieur*/
    	 
	  //libsvm.svm_model svm = new libsvm.svm_model();
	try{
		System.out.println("Ouverture fichier en mode ecriture");
		  BufferedWriter BwTrain=new BufferedWriter(new FileWriter(FileLabled,true));  //Ouverture des fichiers en mode �criture
	      BufferedWriter BwUnlabled=new BufferedWriter(new FileWriter(FileUnlabled,true));
	  try{
    	/*
    	 * Cr�ation des donn�es d'apprentissage et des donn�es de test
    	 */
		  System.out.println("Ouverture fichier en mode lecture");
    	  BufferedReader BrTain=new BufferedReader(new FileReader(FileLabled));  
    	  Instances train = new Instances(BrTain);	//Donn�es �tiquet�es
	      System.out.println("instance file label");
	      BufferedReader BrUnlabeled=new BufferedReader(new FileReader(FileUnlabled));  
	      Instances Unlabel = new Instances(BrUnlabeled);	//Donn�es non �tiquet�es
	      System.out.println("instance file unlabel");  
	      
	     
	  	  Instances UnlabelTemp = new Instances(new BufferedReader(new FileReader(FileTemp)));
	  	  System.out.println("fichier non �tiquet� temporaire cr�e avec succ�s");
	      
	  	  //pr�parer fichier train et fichier test
	      train.setClassIndex(train.numAttributes()-1);
	      UnlabelTemp.setClassIndex(UnlabelTemp.numAttributes()-1);
	      System.out.println("la 1ere instance du fichier temporaire"+UnlabelTemp.instance(0).toString());
          
          /*
           * Construction du classifieur svm
           */
     
	      WekaPackageManager.loadPackages( false, true, false );
	      AbstractClassifier classifier = ( AbstractClassifier ) Class.forName(
	                  "weka.classifiers.functions.LibSVM" ).newInstance();
	      System.out.println("construction du classifieur svm");
	      LibSVM svm = (LibSVM) classifier;
	      System.out.println("Setprobabilit�");
	      svm.setProbabilityEstimates(true);
	      System.out.println("construction du classifieur svm termin�");
	      
	      //If you prefer to give options set the options like this
	
	      //String options = ( "-S 0 -K 0 -D 3 -G 0.0 -R 0.0 -N 0.5 -M 40.0 -C 1.0 -E 0.001 -P 0.1 -b 1" );
	      String options = ( "-S 0 -K 0 -D 3 -G 0.5 -M 40.0 -C 1.0 -E 0.001 -B 1" );
	      String[] optionsArray = options.split( " " );
	          svm.setOptions( optionsArray );
	      //Finally train the classifier
	
	      svm.buildClassifier(train);System.out.println("entrainement du classifieur svm");

		  /*
		   * Parcours du fichier de test (en format ARFF), instance par instance 
		   * 
		   */
		  for(int i =0; i<UnlabelTemp.numInstances();i++){
			  //String actuel = test.classAttribute().value( (int) test.instance(i).classValue());
			  String actuel = UnlabelTemp.instance(i).toString(UnlabelTemp.classIndex());
			  System.out.println("classe actuel:"+UnlabelTemp.instance(i).classValue());
		      
			  /*
			   * classification de l'instance i du fichier de test: le r�sultat est de type double
			   */
		    double pred = svm.classifyInstance(UnlabelTemp.instance(i));	    
		    	/*
		    	 * transformation du r�sultat pr�dit en chaine de caract�res
		    	 */
		    String prediction = UnlabelTemp.classAttribute().value( (int) pred);
		    System.out.println("classe prediction:"+prediction);
		
		    System.out.println("le mot que je viens de traiter "+i);
		    	/*
		    	 * indentification de la classe  vu que le fichier de test est non �tiquet� 
		    	 */
		    double seuil=0.6;
		    double[] predictionDistribution = 
		            svm.distributionForInstance(UnlabelTemp.instance(i)); 
		    String predictionDistribution0=UnlabelTemp.classAttribute().value(0);
		    double predictionProbability0=predictionDistribution[0];
		    System.out.println("prediction classe "+predictionDistribution0 +":"+predictionProbability0);
		    String predictionDistribution1=UnlabelTemp.classAttribute().value(1);
		    double predictionProbability1=predictionDistribution[1];
		    System.out.println("prediction classe "+predictionDistribution1 +":"+predictionProbability1);
		    if((predictionProbability0>predictionProbability1) && (predictionProbability0>seuil)){
		    	UnlabelTemp.instance(i).setClassValue("NonRef");
		    	System.out.println("+++");
		    	BwTrain.write("\n"+UnlabelTemp.instance(i).toString());
		    	//UnlabelTemp.instance(i).setDataset(train);
		    	System.out.println("classe 0 choisie");
		    }
		    else if((predictionProbability1>predictionProbability0) && (predictionProbability1>seuil)){
		    	UnlabelTemp.instance(i).setClassValue("Ref");
		    	//UnlabelTemp.instance(i).setDataset(train);
		    	BwTrain.write("\n"+UnlabelTemp.instance(i).toString());
		    	System.out.println("classe 1 choisie");
		    }
		    else{
		    	//UnlabelTemp.instance(i).setDataset(FileUnlabled);
		    	BwUnlabled.write("\n"+UnlabelTemp.instance(i).toString());
		    	System.out.println("aucune classe choisie");
		    }
		        // Print out the true label, predicted label, and the distribution.
		      //System.out.printf("%5d: true=%-10s, predicted=%-10s, distribution=", 
	                          //i, actuel, prediction); 
		     // Loop over all the prediction labels in the distribution.
		        /*for (int predictionDistributionIndex = 0; 
		             predictionDistributionIndex < predictionDistribution.length; 
		             predictionDistributionIndex++)
		        {
		            // Get this distribution index's class label.
		            String predictionDistributionIndexAsClassLabel = 
		            		UnlabelTemp.classAttribute().value(
		                    predictionDistributionIndex);
		
		            // Get the probability.
		            double predictionProbability = 
		                predictionDistribution[predictionDistributionIndex];
		
		            System.out.printf("[%10s : %6.3f]", 
		                              predictionDistributionIndexAsClassLabel, 
		                              predictionProbability );
		        }
		        System.out.println();*/
		    /*
		     * Comptage du nombre des instances bien class�es
		     */
		    
		  }
		  BrTain.close();
		  BrUnlabeled.close();
		  //creer un fichier non �tiquet� temporaire
	      /*String NewFileUnlabeled=new String();
	      CreateCorpus cc = new CreateCorpus();
	      NewFileUnlabeled=cc.CreationCorpusTemp(Unlabel, iteration); 	//Donner le nouveau fichier unlabel apr�s suppression des instances choisis
	  	  cc.CreerFichier(FileTemp);									//cr�er le fichiers des donn�es non �tiquet�es temporaire
	      System.out.println(FileTemp);*/
	  }
	  catch(Exception e){System.out.println(e);}
	  
	  BwTrain.close();
	  BwUnlabled.close();
	}
    catch(Exception e){System.out.println(e);}


  }
  
  public static void SelfTrainingSVM(String FileLabled, String FileUnlabled, String FileTemp){
	  /*construction du classifieur*/
    	 
	  libsvm.svm_model svm = new libsvm.svm_model();
    try{
    	/*
    	 * Cr�ation des donn�es d'apprentissage et des donn�es de test
    	 */
    	
      Instances train = new Instances(new BufferedReader(new FileReader(FileLabled)));	//Donn�es �tiquet�es
      System.out.println("instance file label");
      Instances Unlabel = new Instances(new BufferedReader(new FileReader(FileUnlabled)));	//Donn�es non �tiquet�es
      System.out.println("instance file unlabel");
      int iteration=1;
      String NewFileUnlabel=new String();
      //CreateCorpus cc = new CreateCorpus();
      //NewFileUnlabel=cc.CreationCorpusTemp(Unlabel, iteration); 	//Donner le nouveau fichier unlabel apr�s suppression des instances choisis
  		//cc.CreerFichier(FileTemp);									//cr�er le fichiers des donn�es non �tiquet�es temporaire
  		System.out.println(FileTemp);
  		Instances UnlabelTemp = new Instances(new BufferedReader(new FileReader(FileTemp)));
  		System.out.println("fichier non �tiquet� temporaire cr�e avec succ�s");
      
      train.setClassIndex(train.numAttributes()-1);
      UnlabelTemp.setClassIndex(UnlabelTemp.numAttributes()-1);
      System.out.println("la 1ere instance du fichier temporaire"+UnlabelTemp.instance(0).toString());
          
          /*
           * L� on a choisi un seul classifieur de ceux construits ci-dessus,
           * c'est le classifieur SVM, pour travailler avec.
           * Il apprend alors des donn�es d'apprentissage
           */
          WekaPackageManager.loadPackages( false, true, false );
          AbstractClassifier classifier = ( AbstractClassifier ) Class.forName(
                      "weka.classifiers.functions.LibSVM" ).newInstance();
          
          //If you prefer to give options set the options like this

          String options = ( "-S 0 -K 0 -D 3 -G 0.0 -R 0.0 -N 0.5 -M 40.0 -C 1.0 -E 0.001 -P 0.1" );
          String[] optionsArray = options.split( " " );
          classifier.setOptions( optionsArray );
          //Finally train the classifier

          classifier.buildClassifier(train);

      double nbvrai=0;
      /*
       * Parcours du fichier de test (en format ARFF), instance par instance 
       * 
       */
      for(int i =0; i<UnlabelTemp.numInstances();i++){
    	 /// String actuel = test.classAttribute().value( (int) test.instance(i).classValue());
          ///System.out.println(", actual: " + actuel );
    	  /*
    	   * classification de l'instance i du fichier de test: le r�sultat est de type double
    	   */
        double pred = classifier.classifyInstance(UnlabelTemp.instance(i));
        System.out.println("classe actuel:"+UnlabelTemp.instance(i).classValue());
        
        	/*
        	 * transformation du r�sultat pr�dit en chaine de caract�res
        	 */
        String arbrepred = UnlabelTemp.classAttribute().value( (int) pred);

        System.out.println("le mot que je viens de traiter "+i);
        	/*
        	 * indentification de la classe r�elle vu que le fichier de test est �tiquet� correctement 
        	 * par les bonnes classes
        	 */
        String actuel = UnlabelTemp.classAttribute().value( (int) UnlabelTemp.instance(i).classValue());
        System.out.println(", actual: " + actuel );
        System.out.println("la classe pr�dite : "+arbrepred);
        //classifier.setBuildLogisticModels(true); 
        double[] predictionDistribution =classifier.distributionForInstance(UnlabelTemp.instance(i));
        
        /*
         * Comptage du nombre des instances bien class�es
        */
        
        if(arbrepred.equals(actuel))
        {
          nbvrai++;
        }
      }
      System.out.println(nbvrai);
      System.out.println(nbvrai/UnlabelTemp.numInstances()); 
      
      //
      Evaluation eval = new Evaluation(train);
      Random rand = new Random(1); // using seed = 1
      int folds = 10;
      eval.crossValidateModel(classifier, train, folds, rand);
      //eval.crossValidateModel(classifier, UnlabelTemp, folds, rand);
      /*eval.evaluateModel(classifier,UnlabelTemp); 
      System.out.println(eval);
      System.out.println(eval.toSummaryString());
      System.out.println(eval.toClassDetailsString());
      System.out.println(eval.toMatrixString());

      ArrayList confidence = eval.predictions();

      System.out.println(confidence.size());

      for(Object c: confidence)
        System.out.println(c);*/
      

    }
    catch(Exception e){System.out.println(e);}


  }
  public static void SelfTrainingSVM1(String FileLabled, String FileUnlabled, String FileTemp){
	  /*construction du classifieur*/
    	 
	  libsvm.svm_model svm = new libsvm.svm_model();
    try{
    	/*
    	 * Cr�ation des donn�es d'apprentissage et des donn�es de test
    	 */
    	
      Instances train = new Instances(new BufferedReader(new FileReader(FileLabled)));	//Donn�es �tiquet�es
      System.out.println("instance file label");
      Instances Unlabel = new Instances(new BufferedReader(new FileReader(FileUnlabled)));	//Donn�es non �tiquet�es
      System.out.println("instance file unlabel");
      int iteration=1;
      String NewFileUnlabel=new String();
      /*CreateCorpus cc = new CreateCorpus();
      NewFileUnlabel=cc.CreationCorpusTemp(Unlabel, iteration); 	//Donner le nouveau fichier unlabel apr�s suppression des instances choisis
  		cc.CreerFichier(FileTemp);									//cr�er le fichiers des donn�es non �tiquet�es temporaire
  		System.out.println(FileTemp);*/
  		Instances UnlabelTemp = new Instances(new BufferedReader(new FileReader(FileTemp)));
  		System.out.println("fichier non �tiquet� temporaire cr�e avec succ�s");
      
      train.setClassIndex(train.numAttributes()-1);
      UnlabelTemp.setClassIndex(UnlabelTemp.numAttributes()-1);
      System.out.println("la 1ere instance du fichier temporaire"+UnlabelTemp.instance(0).toString());
          
          /*
           * L� on a choisi un seul classifieur de ceux construits ci-dessus,
           * c'est le classifieur SVM, pour travailler avec.
           * Il apprend alors des donn�es d'apprentissage
           */
          WekaPackageManager.loadPackages( false, true, false );
          AbstractClassifier classifier = ( AbstractClassifier ) Class.forName(
                      "weka.classifiers.functions.LibSVM" ).newInstance();
          LibSVM s = (LibSVM) classifier;
          s.setProbabilityEstimates(true);
          
          //If you prefer to give options set the options like this
          
          String options = ( "-S 0 -K 0 -D 3 -G 0.0 -R 0.0 -N 0.5 -M 40.0 -C 1.0 -E 0.001 -P 0.1 -b 1" );
          String[] optionsArray = options.split( " " );
          classifier.setOptions( optionsArray );
          //Finally train the classifier
          System.out.printf("give options");
          
          s.buildClassifier(train);
          //classifier.setProbabilityEstimates(true);
        int numTestInstances = UnlabelTemp.numInstances();
        System.out.printf("There are %d test instances\n", numTestInstances);

        // Loop over each test instance.
        for (int i = 0; i < numTestInstances; i++)
        {
            // Get the true class label from the instance's own classIndex.
            String trueClassLabel = 
            		UnlabelTemp.instance(i).toString(UnlabelTemp.classIndex());

            // Make the prediction here.
            double predictionIndex = 
                s.classifyInstance(UnlabelTemp.instance(i)); 

            // Get the predicted class label from the predictionIndex.
            String predictedClassLabel =
            		UnlabelTemp.classAttribute().value((int) predictionIndex);

            // Get the prediction probability distribution.
            double[] predictionDistribution = 
                s.distributionForInstance(UnlabelTemp.instance(i)); 

            // Print out the true label, predicted label, and the distribution.
            System.out.printf("%5d: true=%-10s, predicted=%-10s, distribution=", 
                              i, trueClassLabel, predictedClassLabel); 
         // Loop over all the prediction labels in the distribution.
            for (int predictionDistributionIndex = 0; 
                 predictionDistributionIndex < predictionDistribution.length; 
                 predictionDistributionIndex++)
            {
                // Get this distribution index's class label.
                String predictionDistributionIndexAsClassLabel = 
                		UnlabelTemp.classAttribute().value(
                        predictionDistributionIndex);

                // Get the probability.
                double predictionProbability = 
                    predictionDistribution[predictionDistributionIndex];

                System.out.printf("[%10s : %6.3f]", 
                                  predictionDistributionIndexAsClassLabel, 
                                  predictionProbability );
            }

            System.out.printf("\n");
        }
      
      //
      /*Evaluation eval = new Evaluation(train);
      Random rand = new Random(1); // using seed = 1
      int folds = 10;
      eval.crossValidateModel(classifier, train, folds, rand);*/
      //eval.crossValidateModel(classifier, UnlabelTemp, folds, rand);
      /*eval.evaluateModel(classifier,UnlabelTemp); 
      System.out.println(eval);
      System.out.println(eval.toSummaryString());
      System.out.println(eval.toClassDetailsString());
      System.out.println(eval.toMatrixString());

      ArrayList confidence = eval.predictions();

      System.out.println(confidence.size());

      for(Object c: confidence)
        System.out.println(c);*/
      

    }
    catch(Exception e){System.out.println(e);}


  }
  
  public static void CreateFileLabeled(String FileLabel1, String FileLabel2){ //Ajouter des instances du FileLabel2 dans FileLabel1
 
	  try{
		  
		  //Instances F1Write = new Instances(new BufferedWriter(new FileWriter(FileLabel1)));
		  //BufferedWriter writer = new BufferedWriter(new FileWriter(FileLabel1)); 
		  FileWriter fwriter = new FileWriter(FileLabel1,true); //true will append the new instance
	      Instances F2 = new Instances(new BufferedReader(new FileReader(FileLabel2)));	
	      Instances F1 = new Instances(new BufferedReader(new FileReader(FileLabel1)));
	      int NbrInstInit=F1.numInstances();
	      int NbrInstMax=Integer.parseInt(ReadTxtFile.LectureParametres().get(0));
	      System.out.println("nbr inst max:"+NbrInstMax);
	      int i =0;
	      
	      while(i<F2.numInstances() && (NbrInstInit+i)<NbrInstMax){
	    	  //F1.add(F2.instance(i));
	    	  fwriter.write(F2.instance(i).toString()); //appends the string to the file
	    	  System.out.println("Ajout instance");
	    	  i++;
	      }
	      //writer.flush(); 
		  fwriter.close(); 
	      System.out.println("Ajout termin�");
	  }
	  catch(Exception e){System.out.println(e);}

  }
  public static void CreateFileUnLabeled(String FileUnLabel1, String FileUnLabel2){ //Ajouter des instances du FileLabel2 dans FileLabel1
	  
	  try{
		  System.out.println("Debut");
		  //Instances F1Write = new Instances(new BufferedWriter(new FileWriter(FileLabel1)));
		  //BufferedWriter writer = new BufferedWriter(new FileWriter(FileLabel1)); 
		  FileWriter fwriter = new FileWriter(FileUnLabel1,true); //true will append the new instance
		  System.out.println("commencer Ajout instance");
	      Instances F2 = new Instances(new BufferedReader(new FileReader(FileUnLabel2)));	
	      //Instances F1 = new Instances(new BufferedReader(new FileReader(FileUnLabel1)));
	      //int NbrInstInit=F1.numInstances();
	      //System.out.println("nbr instance init"+NbrInstInit);
	      int i =68;
	      while(i<F2.numInstances()){
	    	  //F1.add(F2.instance(i));
	    	  fwriter.write(F2.instance(i).toString()); //appends the string to the file
	    	  System.out.println("Ajout instance");
	    	  i++;
	      }
	      //writer.flush(); 
		  fwriter.close(); 
	      System.out.println("Ajout termin�");
	  }
	  catch(Exception e){System.out.println(e);}

  }
	      

}