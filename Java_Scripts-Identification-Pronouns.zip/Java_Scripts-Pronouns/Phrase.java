package classificationSVM;



import java.io.StringWriter;
import java.util.*;

import org.jdom2.*;


import java.util.Iterator;


public class Phrase {

  static public Element phrase = new Element("Phrase");
  public Phrase() {
  }

public static String TextePhrase(){
  String ph = new String();
  ph = phrase.getAttributeValue("contenu");
  

  return ph;
}
public static String TextePhrase2(){
	  String ph = new String();
	  ph = phrase.getAttributeValue("cont");
	  if(ph.equals(""))
		  ph = phrase.getAttributeValue("contenu");

	  return ph;
	}

public static String NumeroPhrase(){
  String num = new String();
  
  return num;
}

public static List ExtraireMots(){
	  List mots = new ArrayList();
	  List syn = ExtraireSyntagmes();
	  Iterator i = syn.iterator();
	  while(i.hasNext()){
	    Element s = (Element) i.next();
	    List mot = s.getChildren("Mot");
	    for(int j=0;j<mot.size();j++)
	    {
	      mots.add((Element)mot.get(j));
	    }
	  }
	  return mots;
	}
public static List ExtraireToutMots(){
	  List mots = new ArrayList();
	  List syn = ExtraireSyntagmes();
	  Iterator i = syn.iterator();
	  while(i.hasNext()){
	    Element s = (Element) i.next();
	    List mot = s.getChildren("");
	    for(int j=0;j<mot.size();j++)
	    {
	      mots.add((Element)mot.get(j));
	    }
	  }
	  return mots;
	}
public static List ExtraireMots2(){
	  List mots=phrase.getChildren("Mot");
	  return mots;
	}
public static List ExtraireToutMot2(){
	List mots=phrase.getChildren("");
	 return mots;
	
	}
  public static List ExtraireSyntagmes(){
    List syntags = new ArrayList();
    List syntagmes = new ArrayList();
    syntags = phrase.getChildren();
    Iterator i = syntags.iterator();
    int nb=-1;
    while(i.hasNext()){
      Element syntag = (Element) i.next();
      nb++;
      List sousSyntag=syntag.getChildren();
      if(syntag.getName().startsWith("S")){
        syntagmes.add(syntag);
      }
      else if(syntag.getName().startsWith("s")){
    	  syntagmes.add(syntag);
      }
      for(int j=0;j<sousSyntag.size();j++){
    	  Element ssyntag=(Element)sousSyntag.get(j);
    	  if(ssyntag.getName().startsWith("S")){
    	  	syntagmes.add(ssyntag);
    	  }
      }
    }
    return syntagmes;
  }
  
  
  
  public static List ExtraireSN(){
	    List syntags = new ArrayList();
	    List syntagmes = new ArrayList();
	    syntags = phrase.getChildren();
	    Iterator i = syntags.iterator();
	    int nb=-1;
	    while(i.hasNext()){
	      Element syntag = (Element) i.next();
	      nb++;
	      if(syntag.getName().startsWith("SN")){
	        syntagmes.add(syntag); 
	      }
	      else if(syntag.getAttributeValue("Type")!=null){
	    	  if(syntag.getAttributeValue("Type").equals("SN")){
	    	  syntagmes.add(syntag);
	      }
	    }}
	    return syntagmes;
	  }
  public static List ExtraireSNApp(){
	  List syntags = new ArrayList();
	  List syntagmes = new ArrayList();
	    syntags = phrase.getChildren();
	    //System.out.println("extr syn"+syntags.size());
	    Iterator i = syntags.iterator();
	    int nb=-1;
	    while(i.hasNext()){
	      Element syntag = (Element) i.next();
	      nb++;
	      if(syntag.getName().equals("SN-App")){
	        syntagmes.add(syntag); 
	      }
	      else if(syntag.getAttributeValue("Type")!=null){
	    	  if(syntag.getAttributeValue("Type").equals("SN-App")){
	    	  syntagmes.add(syntag);
	      }
	      }
	      //System.out.println(syntagmes.size());
	      List sousSyntag=syntag.getChildren();
	      //System.out.println(sousSyntag.size());
	      for(int j=0;j<sousSyntag.size();j++){
	    	  Element ssyntag=(Element)sousSyntag.get(j);
	    	  if(ssyntag.getName().equals("SN-App"))
	    	  	syntagmes.add(ssyntag);
	      }
	     }
	   // System.out.println(syntagmes.size());
	    return syntagmes;
  }
  public static List ExtraireSNConj(){
	    List syntags = new ArrayList();
	    List syntagmes = new ArrayList();
	    syntags = phrase.getChildren();
	    //System.out.println("extr syn"+syntags.size());
	    Iterator i = syntags.iterator();
	    int nb=-1;
	    while(i.hasNext()){
	      Element syntag = (Element) i.next();
	      nb++;
	      if(syntag.getName().equals("SN-Conj")||syntag.getName().equals("SP-Conj")){
	        syntagmes.add(syntag); 
	      }
	      else if(syntag.getAttributeValue("Type")!=null){
	    	  if(syntag.getAttributeValue("Type").equals("SN-Conj")||syntag.getAttributeValue("Type").equals("SP-Conj")){
	    	  syntagmes.add(syntag);
	      }
	      }
	      //System.out.println(syntagmes.size());
	      List sousSyntag=syntag.getChildren();
	      //System.out.println(sousSyntag.size());
	      for(int j=0;j<sousSyntag.size();j++){
	    	  Element ssyntag=(Element)sousSyntag.get(j);
	    	  if(ssyntag.getName().equals("SN-Conj")||ssyntag.getName().equals("SP-Conj"))
	    	  	syntagmes.add(ssyntag);
	      }
	     }
	   // System.out.println(syntagmes.size());
	    return syntagmes;
	  }
 
  
  public static List ExtraireSNAn(){
	    List syntags = new ArrayList();
	    List syntagmes = new ArrayList();
	    syntags = phrase.getChildren();
	    Iterator i = syntags.iterator();
	    int nb=-1;
	    while(i.hasNext()){
	      Element syntag = (Element) i.next();
	      nb++;
	      if(syntag.getName().equals("SN-An")){
	        syntagmes.add(syntag); 
	      }
	      else if(syntag.getAttributeValue("Type")!=null){
	    	  if(syntag.getAttributeValue("Type").equals("SN-An")){
	    	  syntagmes.add(syntag);
	      }
	      }
	      List sousSyntag=syntag.getChildren();
	      for(int j=0;j<sousSyntag.size();j++){
	    	  Element ssyntag=(Element)sousSyntag.get(j);
	    	  if(ssyntag.getName().equals("SN-An"))
	    	  	syntagmes.add(ssyntag);
	      }
	     }
	    return syntagmes;
	  }
  
  public static List ExtraireSV(){
	    List syntags = new ArrayList();
	    List syntagmes = new ArrayList();
	    syntags = phrase.getChildren();
	    Iterator i = syntags.iterator();
	    int nb=-1;
	    while(i.hasNext()){
	      Element syntag = (Element) i.next();
	      nb++;
	      if(syntag.getName().startsWith("SV")){
	        syntagmes.add(syntag);
	        
	      }
	      else if(syntag.getAttributeValue("Type")!=null){
	    	  if(syntag.getAttributeValue("Type").equals("SV")){
	    	  syntagmes.add(syntag);
	      }
	    }
	    }
	    return syntagmes;
	  }
  public static List ExtraireSP(){
	    List syntags = new ArrayList();
	    List syntagmes = new ArrayList();
	    syntags = phrase.getChildren();
	    Iterator i = syntags.iterator();
	    int nb=-1;
	    while(i.hasNext()){
	      Element syntag = (Element) i.next();
	      nb++;
	      if(syntag.getName().startsWith("SP")){
	        syntagmes.add(syntag);
	        
	      }
	      else if(syntag.getAttributeValue("Type")!=null){
	    	  if(syntag.getAttributeValue("Type").equals("SP")){
	    	  syntagmes.add(syntag);
	      }
	    }
	    }
	    return syntagmes;
	  }
 

  public static void main(String[] args) {
  // Create the empty dataset "race" with above attributes

  Texte txt = new Texte();
  //txt.nomfichier= "train2.xml";
  String texte1 = txt.nomfichier.substring(0,txt.nomfichier.indexOf("."));
  System.out.println(texte1);
  /*List phs = txt.ExtractPhrase();
  System.out.println(phs.size());
  Iterator i =phs.iterator();
  while(i.hasNext()){

    Phrase ph = new Phrase();
    ph.phrase=(Element)i.next();
    System.out.println(ph.TextePhrase());
    System.out.println(ph.ExtraireSyntagmes().size());
    System.out.println("Syntagme conjonctival"+ph.ExtraireSNConj().size());
  }*/
  List parags=txt.ExtractParagraphe();
  int numParag=0;
  String SnConj;
  String SnAn;
  Iterator pa =parags.iterator();
  while(pa.hasNext()){
	  numParag++;
	  Paragraphe parag=new Paragraphe();
	  parag.paragraphe=(Element)pa.next();
	  List phs = parag.ExtrairePhrases();
	  //System.out.println(phs.size());
	  
	  int numPhrase=0;
	  Iterator i =phs.iterator();
	  while(i.hasNext()){
		  numPhrase++;
	    Phrase ph = new Phrase();
	    ph.phrase=(Element)i.next();
	    
	    //System.out.println(ph.TextePhrase());
	    //System.out.println(ph.ExtraireSyntagmes().size());
	    List mots = ph.ExtraireSyntagmes();
	    List LSnConj=ph.ExtraireSNConj();
	    List LSnAn=ph.ExtraireSNAn();
	    Iterator j = mots.iterator();
	    while(j.hasNext())
	    {
	    	Syntagme m1 = new Syntagme();
	    	 m1.syntagme=(Element)j.next();
	    	 List mots1 = m1.ExtraireMots();
	    	 Iterator k = mots1.iterator();
	    	 while(k.hasNext())
	    	    {
	    		 Mot m = new Mot();
	        	 m.mot=(Element)k.next();
	        	 //System.out.println("#######################");
	        	 //System.out.println(m.ExtraireValeur());
	    	    }
	    }
	    //System.out.println("les syntagmes de conjonction");
	    for(int r=0;r<LSnConj.size();r++){
	    	Syntagme s1 = new Syntagme();
	    	s1.syntagme=(Element) LSnConj.get(r);
	    	List mots1 = s1.ExtraireMots();
	    	SnConj="";
	    	for(int w=0;w<mots1.size();w++){
	    		Mot m = new Mot();
	        	 m.mot=(Element)mots1.get(w);
	    		SnConj=SnConj+" "+m.ExtraireValeur();
	    	}
	    	//if (!SnConj.equals(""))
	    	//System.out.println(SnConj);
	    }
	    //System.out.println("les syntagmes d'annexion");
	    for(int r=0;r<LSnAn.size();r++){
	    	Syntagme s2 = new Syntagme();
	    	s2.syntagme=(Element) LSnAn.get(r);
	    	List mots2 = s2.ExtraireMots();
	    	SnAn="";
	    	for(int w=0;w<mots2.size();w++){
	    		Mot m = new Mot();
	        	 m.mot=(Element)mots2.get(w);
	    		SnAn=SnAn+" "+m.ExtraireValeur();
	    	}
	    	//if (!SnAn.equals(""))
	    	//System.out.println(SnAn);
	    }
	    
	  }
  }
	  
  System.out.println("corpus cr�� avec succ�s");

}


}
