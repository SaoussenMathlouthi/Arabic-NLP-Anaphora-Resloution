package classificationSVM;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.StringWriter;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CharsetEncoder;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class CopyXMLFile {
	
	public static void main(String[] args) throws Exception{
		//ChangeEncoding("textetest.xml");
		//XMLFileUTF8();
		CopierFichierXML("text1Litteraire.xml");
		System.out.println("File xml UTF-8");
	}
	public static void ChangeEncoding2(String NameFile){
		String NewFile=NameFile.substring(0,NameFile.indexOf("."));
		NewFile=NewFile+"Result.xml";
		
	}
	
 public static String CopierFichierXML(String NameFile) throws IOException, FileNotFoundException, Exception, SAXException{
		 
		 BufferedReader reader = new BufferedReader(
				    new InputStreamReader(
				        new FileInputStream(NameFile),
				        "UTF-8"
				    )
				);
			String NewFile=NameFile.substring(0,NameFile.indexOf("."));
			NewFile=NewFile+"Filtr�.xml";
				BufferedWriter writer = new BufferedWriter(
				    new OutputStreamWriter(
				        new FileOutputStream(NewFile),
				        "UTF-8"
				    )
				);
				String line = null;

	            while ((line = reader.readLine()) != null)
	            {
	                writer.write(line);
	            }

	            // Close to unlock.
	            reader.close();
	            // Close to unlock and flush to disk.
	            writer.close();
	            
	           System.out.println("Fichier r�sultat copi�");
	    	   //CopyXMLFile.ChangeEncoding(NewFile); 
	           return NewFile;
		}
	      
	public static void ChangeEncoding(String NameFile) throws Exception{
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer;
		DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder;
		try {
			transformer = tf.newTransformer();
			transformer.setOutputProperty(OutputKeys.ENCODING, "ISO-8859-1");
			String NewFile=NameFile.substring(0,NameFile.indexOf("."));
			NewFile=NewFile+"Result.xml";
			File file = new File(NewFile);
			
	        documentBuilder = documentBuilderFactory.newDocumentBuilder();
	        Document doc = documentBuilder.parse(NameFile);
			transformer.transform(new DOMSource(doc), new StreamResult(file));
			System.out.println("Change encoding");
		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void CopierXMLFile(String NameFile){
		 
		DocumentBuilderFactory icFactory = DocumentBuilderFactory.newInstance();
	    DocumentBuilder icBuilder;
	    String NewFile=NameFile.substring(0,NameFile.indexOf("."));
	    NewFile=NewFile+"Result.xml";
      try {
    	  	
	          icBuilder = icFactory.newDocumentBuilder();
	          Document doc = icBuilder.newDocument();
	          Element mainRootElement = doc.createElementNS(NewFile, "Modeles");
	          doc.appendChild(mainRootElement);
	          
	          DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
	          DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
	          Document document = documentBuilder.parse(NameFile);
	          Element root = document.getDocumentElement();
	
	          mainRootElement.appendChild(root);
	          // output DOM XML to console 
	          Transformer transformer = TransformerFactory.newInstance().newTransformer();
	          transformer.setOutputProperty(OutputKeys.INDENT, "yes"); 
	          DOMSource source = new DOMSource(doc);	            
	          
	          /*if (Utilities.ExternalStorageWritable()) {
	              String root = Environment.getExternalStorageDirectory()
	                      .toString();*/
          	
              File f = new File(NewFile);
              //if (!f.getParentFile().exists())
              //    f.getParentFile().mkdirs();
              if (!f.exists())
                  f.createNewFile();

              StreamResult result = new StreamResult(f);
              transformer.transform(source, result);
              transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
              System.out.println("Export completed");
      		
      		
          
          System.out.println("\nXML DOM Created Successfully..");

      } catch (Exception e) {
          e.printStackTrace();
      }
  
	}
	// @see http://stackoverflow.com/questions/229015/encoding-conversion-in-java
	private static String changeEncoding(String input) throws Exception {
	    // Create the encoder and decoder for ISO-8859-1
	    Charset charset = Charset.forName("ISO-8859-1");
	    CharsetDecoder decoder = charset.newDecoder();
	    CharsetEncoder encoder = charset.newEncoder();

	    // Convert a string to ISO-LATIN-1 bytes in a ByteBuffer
	    // The new ByteBuffer is ready to be read.
	    ByteBuffer bbuf = encoder.encode(CharBuffer.wrap(input));

	    // Convert ISO-LATIN-1 bytes in a ByteBuffer to a character ByteBuffer and then to a string.
	    // The new ByteBuffer is ready to be read.
	    CharBuffer cbuf = decoder.decode(bbuf);
	    return cbuf.toString();
	}

	// @see http://stackoverflow.com/questions/655891/converting-utf-8-to-iso-8859-1-in-java-how-to-keep-it-as-single-byte
	private static String byteEncoding(String input) throws Exception {
	    Charset utf8charset = Charset.forName("UTF-8");
	    Charset iso88591charset = Charset.forName("ISO-8859-1");

	    ByteBuffer inputBuffer = ByteBuffer.wrap(input.getBytes());

	    // decode UTF-8
	    CharBuffer data = utf8charset.decode(inputBuffer);

	    // encode ISO-8559-1
	    ByteBuffer outputBuffer = iso88591charset.encode(data);
	    byte[] outputData = outputBuffer.array();
	    return new String(outputData, "ISO-8859-1");
	}

	public static void XMLFileUTF8(){
	 try{
		 DefaultHandler handler = new DefaultHandler() { 
	     };
		File file = new File("textetest.xml");
		InputStream inputStream= new FileInputStream(file);
		Reader reader = new InputStreamReader(inputStream,"UTF-8");
	
		InputSource is = new InputSource(reader);
		is.setEncoding("UTF-8");
	
		 SAXParserFactory factory = SAXParserFactory.newInstance();
	     SAXParser saxParser = factory.newSAXParser();
	     
	     
	     saxParser.parse(is, handler);
	 } catch (Exception e) {
     e.printStackTrace();
   }
 }
	/*public static Result home() throws Exception {
	    DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
	    DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

	    //root elements
	    Document doc = docBuilder.newDocument();
	    doc.setXmlVersion("1.0");
	    doc.setXmlStandalone(true);

	    Element rootElement = doc.createElement("test");
	    doc.appendChild(rootElement);

	    rootElement.setAttribute("original", "h�llo");

	    rootElement.setAttribute("stringToString", new String("h�llo".getBytes("UTF-8"), "ISO-8859-1"));

	    rootElement.setAttribute("stringToBytes", changeEncoding("h�llo"));

	    rootElement.setAttribute("stringToBytes2", byteEncoding("h�llo"));

	    TransformerFactory tf = TransformerFactory.newInstance();
	    Transformer transformer = tf.newTransformer();
	    transformer.setOutputProperty(OutputKeys.ENCODING, "ISO-8859-1");

	    StringWriter writer = new StringWriter();
	    transformer.transform(new DOMSource(doc), new StreamResult(writer));
	    String output = writer.getBuffer().toString().replaceAll("\n|\r", "");

	    // The following is Play!Framework specifics for rendering an url, but I believe this is not the problem (I checked in the developer console, the document is correctly in "ISO-8859-1"
	    //response().setHeader("Content-Type", "text/xml; charset=ISO-8859-1");
	    //return ok(output).as("text/xml");
	}*/
}