package classificationSVM;
 
public class InstancePronom {
	
	//private String Identifiant;
	private int Identifiant;
	private String Texte;
	private int NumParag;
	private int NumPhrase;
	private int NumMot;
	
	
	public InstancePronom(int identifiant, String texte,int numParag, int numPhrase, int numMot){
		this.Identifiant=identifiant;
		this.Texte=texte;
		this.NumParag=numParag;
		this.NumPhrase=numPhrase;
		this.NumMot=numMot;
	}


	

	public int getIdentifiant() {
		return Identifiant;
	}

	public void setIdentifiant(int identifiant) {
		Identifiant = identifiant;
	}

	public String getTexte() {
		return Texte;
	}


	public void setTexte(String texte) {
		Texte = texte;
	}


	public int getNumPhrase() {
		return NumPhrase;
	}


	public void setNumPhrase(int numPhrase) {
		NumPhrase = numPhrase;
	}


	public int getNumMot() {
		return NumMot;
	}


	public void setNumMot(int numMot) {
		NumMot = numMot;
	}


	public int getNumParag() {
		return NumParag;
	}


	public void setNumParag(int numParag) {
		NumParag = numParag;
	}

	
	
}
