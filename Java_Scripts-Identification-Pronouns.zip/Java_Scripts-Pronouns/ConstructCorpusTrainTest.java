package classificationSVM;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import weka.core.Instances;
import weka.core.converters.ArffSaver;

public class ConstructCorpusTrainTest {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args) throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub
		String FileTrainNonEtiq="TrainNonEtiq_2emeExpr.arff";
		String FileTrainEtiq="TrainEtiq_2emeExprEssai.arff";
		String FileTest="Test_2emeExpr.arff";
		
		
		ConstructionCorpusEtiq(FileTrainEtiq);
		//ConstructionCorpusNonEtiq(FileTrainNonEtiq);
		  				//DuplicationInstNonRef(FileTrainNonEtiq);
		//ConstructionARFF.ConstructionCorpusTest(FileTest);
		//int NbrDuplic=5;
		//String FileTestDuplic=DuplicationInstance(FileTest,NbrDuplic);
		//System.out.println("fichier teste dupliqué");
		//String FileTestDuplic=DuplicationMeilleuresInstances(FileTest);
		//System.out.println("fichier test; meilleures instances dupliquées");
		
		//int NbrDuplicInstNonRef=80;
		//DuplicationInstNonRef(FileTrainNonEtiq,NbrDuplicInstNonRef);
		//System.out.println("fichier train non etiq dupliqué inst non ref");
		//DuplicationInstNonRefNoyau(FileTrainEtiq);
		//System.out.println("fichier train etiq dupliqué inst non ref");
	}
	
	public static void ConstructionCorpusEtiq(String FileTrain) throws FileNotFoundException, IOException{
		//Construction du fichier arff �tiquet�s
		   ConstructionARFF.ArffFile(true,FileTrain);
		    System.out.println("fichier train noyau cr�er avec succ�s! "+FileTrain);
		    Instances train = new Instances(new BufferedReader(new FileReader(FileTrain)));	//Donn�es �tiquet�es
		    System.out.println("instance file label"+train.numInstances());
		    //AfficherNbrInstParClasse(train);
	  }
	  
	  public static void ConstructionCorpusNonEtiq(String FileTest) throws FileNotFoundException, IOException{
		  //Construction du fichier arff Non �tiquet�s
		    ConstructionARFF.ArffFile(false,FileTest);
		    System.out.println("fichier test cr�er avec succ�s! "+FileTest);
		    Instances Unlabel = new Instances(new BufferedReader(new FileReader(FileTest)));	//Donn�es �tiquet�es
		    System.out.println("instance file label"+Unlabel.numInstances());
			/*ConstructionARFF.ConstructArffTestFile(dataNonEtiq,FileUnlabled);
			Instances Unlabel = new Instances(new BufferedReader(new FileReader(FileUnlabled)));	//Donn�es non �tiquet�es
			System.out.println("instances file unlabel:"+Unlabel.numInstances());*/
			//System.out.println("instance file label"+train.numInstances());
		  }
	  public static String DuplicationInstance(String FileTrainNonEtiq,int NbrDuplic){
		  String FinalFile=new String();
		  FinalFile=FileTrainNonEtiq.substring(0, FileTrainNonEtiq.indexOf(".")).concat("_Duplic").concat(".arff");
		  
		  try {
			  
			  BufferedReader BrFile=new BufferedReader(new FileReader(FileTrainNonEtiq));  
		      Instances InstFile = new Instances(BrFile);
		      InstFile.setClassIndex(InstFile.numAttributes()-1);
		      System.out.println(FileTrainNonEtiq);
		      ArffSaver saver = new ArffSaver();
		      saver.setInstances(InstFile);
		      saver.setFile(new File(FinalFile));
		      saver.writeBatch();
		      
		      BufferedWriter BwNewFile=new BufferedWriter(new FileWriter(FinalFile,true));   
		      
				for(int i=0;i<InstFile.numInstances();i++){
					//System.out.println(InstFile.classAttribute().value( (int) InstFile.instance(i).classValue()));
					  for(int j=0;j<NbrDuplic;j++){
						  BwNewFile.write("\n"+InstFile.instance(i).toString());	
					  }//Dupliquer l'instance choisie
					  
				  }
				
				BwNewFile.close();
				BrFile.close();
				System.out.println(" Duplication termin�e");
				Instances insts = new Instances(new BufferedReader(new FileReader(FinalFile)));	//Donn�es �tiquet�es
			    System.out.println("instance duplicated file unlabeled"+insts.numInstances());
				
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return FinalFile;
	  }
	  public static String DuplicationMeilleuresInstances(String FileTrainNonEtiq){
		  String FinalFile=new String();
		  FinalFile=FileTrainNonEtiq.substring(0, FileTrainNonEtiq.indexOf(".")).concat("_Duplic").concat(".arff");
		  
		  try {
			  
			  BufferedReader BrFile=new BufferedReader(new FileReader(FileTrainNonEtiq));  
		      Instances InstFile = new Instances(BrFile);
		      InstFile.setClassIndex(InstFile.numAttributes()-1);
		      System.out.println(FileTrainNonEtiq);
		      ArffSaver saver = new ArffSaver();
		      saver.setInstances(InstFile);
		      saver.setFile(new File(FinalFile));
		      saver.writeBatch();
		      
		      BufferedWriter BwNewFile=new BufferedWriter(new FileWriter(FinalFile,true)); 	
		      //int[] ListInstNonDuplic = new int[13];
		      int[] TabInstNonDuplic = new int[] {9,12,14,24,41,42,56,61,63,65,66,68,75};
		      //ListInstNonDuplic[0]=9;		      ListInstNonDuplic[1]=12;		    ListInstNonDuplic[2]=14;
		      List<Integer> ListInstNonDuplic = new ArrayList<Integer>();
		      for(int j=0;j<TabInstNonDuplic.length;j++){
		    	  System.out.println(TabInstNonDuplic[j]+" ");
		    	  ListInstNonDuplic.add(TabInstNonDuplic[j]);
		      }		     
				for(int i=0;i<InstFile.numInstances();i++){
					System.out.println(i+" "+ListInstNonDuplic.contains(i));
					  if(!ListInstNonDuplic.contains(i)){
						  System.out.println("inst "+i);
						  BwNewFile.write("\n"+InstFile.instance(i).toString());	
					  }//Dupliquer l'instance choisie					  
				  }
				
				BwNewFile.close();
				BrFile.close();
				System.out.println(" Duplication termin�e");
				Instances insts = new Instances(new BufferedReader(new FileReader(FinalFile)));	//Donn�es �tiquet�es
			    System.out.println("instance duplicated file unlabeled"+insts.numInstances());
				
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return FinalFile;
	  }
	  public static String DuplicationInstNonRef(String FileTrainNonEtiq, int NbrDuplic){
		  String FinalFile=new String();
		  FinalFile=FileTrainNonEtiq.substring(0, FileTrainNonEtiq.indexOf(".")).concat("Duplic").concat(".arff");
		
		  try {
			  
			  BufferedReader BrFile=new BufferedReader(new FileReader(FileTrainNonEtiq));  
		      Instances InstFile = new Instances(BrFile);
		      InstFile.setClassIndex(InstFile.numAttributes()-1);
		      System.out.println(FileTrainNonEtiq);
		      ArffSaver saver = new ArffSaver();
		      saver.setInstances(InstFile);
		      saver.setFile(new File(FinalFile));
		      saver.writeBatch();
		      
		      BufferedWriter BwNewFile=new BufferedWriter(new FileWriter(FinalFile,true));   
		      
				for(int i=0;i<InstFile.numInstances();i++){
					//System.out.println(InstFile.classAttribute().value( (int) InstFile.instance(i).classValue()));
					 
					if(InstFile.instance(i).toString(InstFile.classIndex()).equals("0")){
						
						  for(int j=0;j<NbrDuplic;j++){
							  BwNewFile.write("\n"+InstFile.instance(i).toString());	
						  }//Dupliquer l'instance choisie
					  }
				  }
				
				BwNewFile.close();
				BrFile.close();
				System.out.println(" Duplication termin�e");
				Instances insts = new Instances(new BufferedReader(new FileReader(FinalFile)));	//Donn�es �tiquet�es
			    System.out.println("instance duplicated file unlabeled"+insts.numInstances());
				
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return FinalFile;
	  }
	  public static String DuplicationInstNonRefNoyau(String FileTrainEtiq){
		  String FinalFile=new String();
		  FinalFile=FileTrainEtiq.substring(0, FileTrainEtiq.indexOf(".")).concat("Duplic").concat(".arff");
		
		  try {
			  int NbrInstDuplic=0;
			  BufferedReader BrFile=new BufferedReader(new FileReader(FileTrainEtiq));  
		      Instances InstFile = new Instances(BrFile);
		      InstFile.setClassIndex(InstFile.numAttributes()-1);
		      System.out.println(FileTrainEtiq);
		      ArffSaver saver = new ArffSaver();
		      saver.setInstances(InstFile);
		      saver.setFile(new File(FinalFile));
		      saver.writeBatch();
		      
		      BufferedWriter BwNewFile=new BufferedWriter(new FileWriter(FinalFile,true));   
		      
				//for(int i=0;i<InstFile.numInstances();i++){
		      int i=0;
		      while(i<InstFile.numInstances()&&	NbrInstDuplic<10){
					//System.out.println(InstFile.classAttribute().value( (int) InstFile.instance(i).classValue()));					 
					if(InstFile.instance(i).toString(InstFile.classIndex()).equals("0")){						  
						BwNewFile.write("\n"+InstFile.instance(i).toString());	
						NbrInstDuplic++;
						System.out.println("Dupliquer l'instance choisie");
					  }
					i++;
				  }
				
				BwNewFile.close();
				BrFile.close();
				System.out.println(" Duplication termin�e");
				Instances insts = new Instances(new BufferedReader(new FileReader(FinalFile)));	//Donn�es �tiquet�es
			    System.out.println("instance duplicated file labeled"+insts.numInstances());
				
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return FinalFile;
	  }
	  
}
