package classificationSVM;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;
import org.xml.sax.SAXException;


import fichierArff.LectureFichierTexte;
import classificationSVM.Mot;
import classificationSVM.Phrase;
import classificationSVM.Texte;

public class FiltragePronNonRef {
	static List<String> ListAdjDef=LectureFichierTexte.LectureChaines("AdjDefini1.txt");
	static List<List<String>> ListParam=LectureFichierTexte.ReadFile("Delimiteur1.txt");
	static List<String> ListIndicTemps=LectureFichierTexte.Parametre(ListParam, 6);

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=0;i<ListAdjDef.size();i++){
			System.out.println(ListAdjDef.get(i));
		}
		System.out.println("Indicateur de temps");
		for(int j=0;j<ListIndicTemps.size();j++){
			System.out.println(ListIndicTemps.get(j));
		}
		//String texte="textePronNonRef.xml";
		//SauvegardeFiltrage2(texte);
		String texte="test1SegV3Res24.xml";
		SauvegardeFiltrage1(texte);
		
		

	}
	
	public static String SauvegardeFiltrage2(String texte){
		String NewTexte=new String();
		try {
			NewTexte=CopyXMLFile.CopierFichierXML(texte);
			List<Anaphore> ListPronNonRef=FiltragePreliminaire2(texte);
			System.out.println("nbr pronom non ref:"+ListPronNonRef.size());
			MiseAJour2(texte,ListPronNonRef,NewTexte);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return NewTexte;
	}
	public static String SauvegardeFiltrage1(String texte){
		String NewTexte=new String();
		try {
			NewTexte=CopyXMLFile.CopierFichierXML(texte);
			List<Anaphore> ListPronNonRef=FiltragePreliminaire1(texte);
			System.out.println("##############################nbr pronom non ref filtrés:"+ListPronNonRef.size());
			MiseAJour1(texte,ListPronNonRef,NewTexte);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return NewTexte;
	}
	public static List<Anaphore> FiltragePreliminaire1(String texte){
	
		List<Anaphore> ListAnaphNonRef=new ArrayList<Anaphore>();
		String NumMot=new String();
		String VgEnc=new String();
		String GenEnc=new String();
		String NbEnc=new String();
		String Rad1=new String();
		String Vg1=new String();
		String VgProc1=new String();
		String Val2=new String();
		String Vg2=new String();
		String Rad2=new String();
		String Val3=new String();
		String Vg3=new String();
		
		
		Mot m = new Mot();
    	Mot ms1=new Mot();
    	Mot ms2=new Mot();
    	Mot ms3=new Mot();
		int a=0;
		List phs = new ArrayList();
		List mots= new ArrayList();
	 	Texte txt = new Texte();
		  txt.nomfichier=texte;
					//Balise paragraphe existe
		  phs = txt.ExtractPhrase2();
		  
		  
		  System.out.println("nbr phrase:"+phs.size());
		  //Iterator i = phs.iterator();
		  //while(i.hasNext()){
		  //String clas = new String();
		  for(int i=0;i<phs.size();i++){
		    Phrase ph = new Phrase();
		    ph.phrase=(Element)phs.get(i);
		   	System.out.println(ph.TextePhrase());
		    mots=ph.ExtraireMots();
		    if(mots.size()==0)
		    	mots=ph.ExtraireMots2();
		    System.out.println("taille phrase:"+mots.size());
		    for(int j=0;j<mots.size();j++){
		    	//m=new Mot();
				m.mot=(Element)mots.get(j);
				System.out.println("mot courant:"+m.ExtraireValeur());
				
				//if(TypeAnaphore2(m).equals("Pronom personnel attaché")){
				if(!MethodeUtile.TypeAnaphore1(m).equals("")){
					VgEnc=m.ExtraireVGEnc();
					GenEnc=m.ExtraireGenreanaph();
					NbEnc=m.ExtraireNbranaph();
					NumMot=m.ExtraireNum();
					if(j+2<mots.size()){
						System.out.println("mot suivant 2 existe");
						//ms1=new Mot();
						ms1.mot=(Element)mots.get(j+1);
						System.out.println("mot suivant 1:"+ms1.ExtraireValeur());
						Rad1=ms1.ExtraireRad();
						Vg1=ms1.ExtraireVGRad();
						VgProc1=ms1.ExtraireVGProc();
						//ms2=new Mot();
						ms2.mot=(Element)mots.get(j+2);
						System.out.println("mot suivant 2:"+ms2.ExtraireValeur());
						Val2=ms2.ExtraireValeur();
						Vg2=ms2.ExtraireVGRad();
						Rad2=ms2.ExtraireRad();
						//if(Patron1_1(m, ms1, ms2,TypeEtiq)){
						if(Regle1_1(VgEnc,GenEnc,NbEnc,Rad1,Vg1,Val2,Vg2)){	
							a++;
							Anaphore Anaph=new Anaphore(a,j,0,i,0,false);
							ListAnaphNonRef.add(Anaph);
							System.out.println("Regle1 vérifiée");
						}
						//else if(Patron5(m, ms1, ms2,TypeEtiq)){
						//else if(Patron5(m, ms1, ms2)){
						else if(Regle2(VgEnc,GenEnc,NbEnc,Rad1,Vg1,VgProc1,Val2,Vg2)){
							a++;
							Anaphore Anaph=new Anaphore(a,j,0,i,0,false);
							ListAnaphNonRef.add(Anaph);
							System.out.println("Patron5");
						}
						else if(j+3<mots.size()){
							//ms3=new Mot();
							ms3.mot=(Element)mots.get(j+3);
							Val3=ms3.ExtraireValeur();
							Vg3=ms3.ExtraireVGRad();
							//if(Patron1_2(m, ms1, ms2, ms3,TypeEtiq)){
							if(Regle1_2(VgEnc,GenEnc,NbEnc,Rad1,Vg1,Rad2,Vg2,Val3,Vg3)){
								a++;
								Anaphore Anaph=new Anaphore(a,j,0,i,0,false);
								ListAnaphNonRef.add(Anaph);
								System.out.println("Patron1_2");
							}
						}
					}
				}
				
		    }
		  }
		  return ListAnaphNonRef;
	}
	public static List<Anaphore> FiltragePreliminaire2(String texte){
		
		List<Anaphore> ListAnaphNonRef=new ArrayList<Anaphore>();
		String NumMot=new String();
		String VgEnc=new String();
		String GenEnc=new String();
		String NbEnc=new String();
		String Rad1=new String();
		String Vg1=new String();
		String VgProc1=new String();
		String Val2=new String();
		String Vg2=new String();
		String Rad2=new String();
		String Val3=new String();
		String Vg3=new String();
		
		
		Mot m = new Mot();
    	Mot ms1=new Mot();
    	Mot ms2=new Mot();
    	Mot ms3=new Mot();
		int a=0;
		List phs = new ArrayList();
		List mots= new ArrayList();
	 	Texte txt = new Texte();
		 txt.nomfichier=texte;
		  
		 phs = txt.ExtractPhrase();		//Balise paragraphe n'existe pas
			 
		  
		  System.out.println("nbr phrase:"+phs.size());
		  //Iterator i = phs.iterator();
		  //while(i.hasNext()){
		  //String clas = new String();
		  for(int i=0;i<phs.size();i++){
		    Phrase ph = new Phrase();
		    ph.phrase=(Element)phs.get(i);
		    
		    System.out.println(ph.TextePhrase2());
		    
		    
		    mots=ph.ExtraireMots2(); 
		    System.out.println("taille phrase:"+mots.size());
		    for(int j=0;j<mots.size();j++){
		    	//m=new Mot();
				m.mot=(Element)mots.get(j);
				System.out.println("mot courant:"+m.ExtraireValeur());
				VgEnc=m.ExtraireVGEnc2();
				GenEnc=m.ExtraireGenreanaph2();
				NbEnc=m.ExtraireNbranaph2();
				NumMot=m.ExtraireNum();
				//if(TypeAnaphore2(m).equals("Pronom personnel attaché")){
				if(!MethodeUtile.TypeAnaphore2(m).equals("")){
					if(j+2<mots.size()){
						System.out.println("mot suivant 2 existe");
						//ms1=new Mot();
						ms1.mot=(Element)mots.get(j+1);
						System.out.println("mot suivant 1:"+ms1.ExtraireValeur());
						Rad1=ms1.ExtraireRad2();
						Vg1=ms1.ExtraireVGRad2();
						VgProc1=ms1.ExtraireVGProc2(); //System.out.println("Rad1"+ Rad1+" VgProc1:"+VgProc1+"Vg1:"+Vg1);
						//ms2=new Mot();
						ms2.mot=(Element)mots.get(j+2);
						System.out.println("mot suivant 2:"+ms2.ExtraireValeur());
						Val2=ms2.ExtraireValeur();
						Vg2=ms2.ExtraireVGRad2();
						Rad2=ms2.ExtraireRad2();
						System.out.println("Val2:"+ Val2);
						//if(Patron1_1(m, ms1, ms2,TypeEtiq)){
						if(Regle1_1(VgEnc,GenEnc,NbEnc,Rad1,Vg1,Val2,Vg2)){	
							a++;
							Anaphore Anaph=new Anaphore(a,j,0,i,0,false);
							ListAnaphNonRef.add(Anaph);
							System.out.println("Regle1_1 vérifiée");
						}
						//else if(Patron5(m, ms1, ms2,TypeEtiq)){
						else if(Regle2(VgEnc,GenEnc,NbEnc,Rad1,Vg1,VgProc1,Val2,Vg2)){
							a++;
							Anaphore Anaph=new Anaphore(a,j,0,i,0,false);
							ListAnaphNonRef.add(Anaph);
							System.out.println("Regle2 vérifiée");
						}
						else if(j+3<mots.size()){
							//ms3=new Mot();
							ms3.mot=(Element)mots.get(j+3);
							Val3=ms3.ExtraireValeur();
							Vg3=ms3.ExtraireVGRad2();
							System.out.println("Val3:"+ Val3);
							//if(Patron1_2(m, ms1, ms2, ms3,TypeEtiq)){
							if(Regle1_2(VgEnc,GenEnc,NbEnc,Rad1,Vg1,Rad2,Vg2,Val3,Vg3)){
								a++;
								Anaphore Anaph=new Anaphore(a,j,0,i,0,false);
								ListAnaphNonRef.add(Anaph);
								System.out.println("Regle1_2 vérifiée");
							}
						}
					}
				}
				
		    }
		  }
		  return ListAnaphNonRef;
	}
	
	public static String MiseAJour1(String texte, List<Anaphore> ListAnaphNonRef, String FileRes){
		String update=new String();
		  try { 
			SAXBuilder builder = new SAXBuilder();
			//String file = texte.substring(0,texte.indexOf("."));
			//String FileRes=file+"Filtré.xml";
			System.out.println("fichier resultat "+FileRes);
			File xmlFile = new File(FileRes);
			Document doc = (Document) builder.build(xmlFile);
			Element rootNode = doc.getRootElement();
	 
			Texte txt=new Texte();
			
			System.out.println("Résolution en cours... Veuillez attendre");
			System.out.println("Enregistrement des résultats");
			for(int i=0; i<ListAnaphNonRef.size();i++){
				System.out.println(ListAnaphNonRef.get(i).getNumParag());
				System.out.println(ListAnaphNonRef.get(i).getNumPh());
				System.out.println(ListAnaphNonRef.get(i).getNumMot());
				
				List parags=rootNode.getChildren("Paragraphe"); 
				//System.out.println("taillparag "+parags.size());
				Element parag=(Element)parags.get(ListAnaphNonRef.get(i).getNumParag());
				List phrs=parag.getChildren("Phrase");
				//System.out.println("taillphr "+phrs.size());
				//System.out.println("num phrase "+ph);
				Element phr=(Element)phrs.get(ListAnaphNonRef.get(i).getNumPh());
				List syntags=phr.getChildren();
				//System.out.println("taillsyntag "+syntags.size());
				Element syntag=(Element)syntags.get(ListAnaphNonRef.get(i).getNumSyntag());
				List mots=syntag.getChildren();
				//System.out.println("taillmot "+mots.size());
				Element mot=(Element)mots.get(ListAnaphNonRef.get(i).getNumMot());
				Element candidats = new Element("ListCandidats");
				mot.addContent(candidats);
				candidats.setAttribute("Referentiel", "non");
				/*if(mot.getName().startsWith("M")||mot.getName().startsWith("S")){
					List Autremots=mot.getChildren("Mot");
					//System.out.println("parag "+p);
					if(Autremots.size()==0){
						Mot word=new Mot();
						word.mot=mot;
						if(!MethodeUtile.TypeAnaphore1(word).equals("")){
							//System.out.println(mot.getAttributeValue("valeur")+" "+word.ExtraireValeur());
							Element candidats = new Element("ListCandidats");
							mot.addContent(candidats);
							candidats.setAttribute("Referentiel", "non");
						}
					}
				}	*/
		}
		Format format = Format.getPrettyFormat();
		format.setEncoding("UTF-8");
	    //format.setEncoding("ISO-8859-1");
	    XMLOutputter xmlOutput = new XMLOutputter(format);
		
		// display nice nice
		//xmlOutput.setFormat(Format.getPrettyFormat());
		
		xmlOutput.output(doc, new FileWriter(FileRes));
		
		
	    
		// xmlOutput.output(doc, System.out);
		update="update";
		System.out.println("File updated!");
	  } catch (IOException io) {
		io.printStackTrace();
	  } catch (JDOMException e) {
		e.printStackTrace();
	  }
	  return update;
	}
	public static String MiseAJour2(String texte, List<Anaphore> ListAnaphNonRef, String FileRes){
		String update=new String();
		  try { 
			SAXBuilder builder = new SAXBuilder();
			//String file = texte.substring(0,texte.indexOf("."));
			//String FileRes=file+"Filtré.xml";
			System.out.println("fichier resultat "+FileRes);
			File xmlFile = new File(FileRes);
			Document doc = (Document) builder.build(xmlFile);
			Element rootNode = doc.getRootElement();
	 
			Texte txt=new Texte();
			
			System.out.println("Résolution en cours... Veuillez attendre");
			System.out.println("Enregistrement des résultats");
			for(int i=0; i<ListAnaphNonRef.size();i++){
				System.out.println(ListAnaphNonRef.get(i).getNumParag());
				System.out.println(ListAnaphNonRef.get(i).getNumPh());
				System.out.println(ListAnaphNonRef.get(i).getNumMot());
			
				List phrs=rootNode.getChildren("Phrase");
				//System.out.println("taillphr "+phrs.size());
				//System.out.println("num phrase "+ph);
				Element phr=(Element)phrs.get(ListAnaphNonRef.get(i).getNumPh());
				List mots=phr.getChildren();
					//System.out.println("taillmot "+mots.size());
				Element mot=(Element)mots.get(ListAnaphNonRef.get(i).getNumMot());
				Element candidats = new Element("ListCandidats");
				mot.addContent(candidats);
				candidats.setAttribute("Referentiel", "non");
				System.out.println("Ajout ListCand");
	}
		Format format = Format.getPrettyFormat();
		format.setEncoding("UTF-8");
	    //format.setEncoding("ISO-8859-1");
	    XMLOutputter xmlOutput = new XMLOutputter(format);
		
		// display nice nice
		//xmlOutput.setFormat(Format.getPrettyFormat());
		
		xmlOutput.output(doc, new FileWriter(FileRes));
		
		
	    
		// xmlOutput.output(doc, System.out);
		update="update";
		System.out.println("File updated!");
	  } catch (IOException io) {
		io.printStackTrace();
	  } catch (JDOMException e) {
		e.printStackTrace();
	  }
	  return update;
	}
	public static boolean Regle1_1(String VgEnc,String GenEnc,String NbEnc,String Rad1,String Vg1,String Val2,String Vg2){
		boolean verif=false;
		//System.out.println(VgEnc.equals("38") +" "+ GenEnc.equals("M") + NbEnc.equals("S") + FiltreRad(Rad1).equals("MiNo") + 
				//Vg1.equals("78") + ListAdjDefini(Val2,ListAdjDef) + Vg2.equals("203"));
		if(VgEnc.equals("38") && GenEnc.equals("M") && 
				NbEnc.equals("S") && FiltreRad(Rad1).equals("MiNo") && 
				Vg1.equals("78") && ListAdjDefini(Val2,ListAdjDef) &&
				Vg2.equals("203")){
			verif=true;
			}
	
		return verif;
	}
	public static boolean Regle1_2(String VgEnc,String GenEnc,String NbEnc,String Rad1,String Vg1,String Rad2,String Vg2,
			String Val3,String Vg3){
		boolean verif=false;
		if(VgEnc.equals("38") && GenEnc.equals("M") && NbEnc.equals("S") && FiltreRad(Rad1).equals("MiNo") && 
				Vg1.equals("78") && FiltreRad(Rad2).equals("RaYor") && ListAdjDefini(Val3,ListAdjDef) && Vg3.equals("203")){
			verif=true;
			}
		
		return verif;
	}
	public static boolean Regle2(String VgEnc,String GenEnc,String NbEnc,String Rad1,String Vg1,String VgProc1,String Val2,String Vg2){					//f.	إنّها  + nombre indiquant l’heure ou le temps
		boolean verif=false;
			if(VgEnc.equals("38") && GenEnc.equals("F") && NbEnc.equals("S") 
					&& VgProc1.equals("1") && EstunNombre(Vg1)){
				verif=true;
			}
		return verif;
	}
	public static boolean Patron1_1(Mot m, Mot ms1, Mot ms2, String TypeEtiq){					//a.    (غير)إنه مِنَ + adjectif défini
		boolean verif=false;
		if(TypeEtiq.equals("1")){
			if(m.ExtraireVGEnc().equals("38") && m.ExtraireGenreanaph().equals("M") && 
					m.ExtraireNbranaph().equals("S") && FiltreRad(ms1.ExtraireRad()).equals("MiNo") && 
					ms1.ExtraireVGRad().equals("78") && ListAdjDefini(ms2.ExtraireValeur(),ListAdjDef) &&
					ms2.ExtraireVGRad().equals("203")){
				verif=true;
				
				}
		}
		else if(TypeEtiq.equals("2")){
			System.out.println(m.ExtraireValeur());
			System.out.println(ms1.ExtraireValeur());
			System.out.println(ms2.ExtraireValeur());
			//System.out.println(m.ExtraireVGEnc2() +" "+ m.ExtraireGenreanaph2()+" " + 
				//	m.ExtraireNbranaph2()+" " + FiltreRad(ms1.ExtraireRad2())+" " + 
					//" "+ms1.ExtraireVGRad2().equals("78")+" " + ms2.ExtraireValeur()+" " +
					//ms2.ExtraireVGRad2());
			if(m.ExtraireVGEnc2().equals("38") && m.ExtraireGenreanaph2().equals("M") && 
					m.ExtraireNbranaph2().equals("S") && FiltreRad(ms1.ExtraireRad2()).equals("MiNo") && 
					ms1.ExtraireVGRad2().equals("78") && ListAdjDefini(ms2.ExtraireValeur(),ListAdjDef) &&
					ms2.ExtraireVGRad2().equals("203")){
				verif=true;
				}
		}
		return verif;
	}
	public static boolean Patron1_2(Mot m, Mot ms1, Mot ms2, Mot ms3, String TypeEtiq){
		boolean verif=false;
		if(TypeEtiq.equals("1")){
			if(m.ExtraireVGEnc().equals("38") && m.ExtraireGenreanaph().equals("M") && 
					m.ExtraireNbranaph().equals("S") && FiltreRad(ms1.ExtraireRad()).equals("MiNo") && 
					ms1.ExtraireVGRad().equals("78") && FiltreRad(ms2.ExtraireRad()).equals("RaYori") && 
					ListAdjDefini(ms3.ExtraireValeur(),ListAdjDef) && ms3.ExtraireVGRad().equals("203")){
				verif=true;
				}
		}
		else if (TypeEtiq.equals("2")){
			if(m.ExtraireVGEnc2().equals("38") && m.ExtraireGenreanaph2().equals("M") && 
					m.ExtraireNbranaph2().equals("S") && FiltreRad(ms1.ExtraireRad2()).equals("MiNo") && 
					ms1.ExtraireVGRad2().equals("78") && FiltreRad(ms2.ExtraireRad2()).equals("RaYori") && 
					ListAdjDefini(ms3.ExtraireValeur(),ListAdjDef) && ms3.ExtraireVGRad2().equals("203")){
				verif=true;
				}
		}
		return verif;
	}
	public static boolean Patron5(Mot m, Mot ms1, Mot ms2, String TypeEtiq){					//f.	إنّها  + nombre indiquant l’heure ou le temps
		boolean verif=false;
		if(TypeEtiq.equals("1")){
			if(m.ExtraireVGEnc().equals("38") && m.ExtraireGenreanaph().equals("F") && m.ExtraireNbranaph().equals("S") 
					&& ms1.ExtraireVGProc().equals("1") && EstunNombre(ms1.ExtraireVGRad())){
				verif=true;
			}
		}
		else if (TypeEtiq.equals("2")){
			if(m.ExtraireVGEnc2().equals("38") && m.ExtraireGenreanaph2().equals("F") && m.ExtraireNbranaph2().equals("S") 
					&& ms1.ExtraireVGProc2().equals("1") && EstunNombre(ms1.ExtraireVGRad2())){
				verif=true;
			}
		}
		return verif;
	}
	public static boolean EstunNombre(String VG){
		boolean x=false;
		int vg=Integer.parseInt(VG);
		if ((vg>=208 && vg<=213)||(vg>=107 && vg<=112))
			x=true;
		return x;
	}
	public static String FiltreRad(String rad){
		String radical=new String();
		if(rad.contains(";"))
			radical=rad.substring(0, rad.indexOf(";"));
		else radical=rad;
		return radical;
	}
	public static boolean ListAdjDefini(String adj,List<String> ListAdj){
		boolean test=false;
		int i=0;
		while(i<ListAdj.size() && test==false){
			if(ListAdj.get(i).equals(adj))
				test=true;
			i++;
		}
		return test;
	}
}
