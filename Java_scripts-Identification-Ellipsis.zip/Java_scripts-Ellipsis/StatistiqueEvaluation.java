package Detection_Resolution_Ellipse;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.jdom2.Element;

public class StatistiqueEvaluation {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String NameFile="test1SegV3Resolu.xml";
		//String NameFile="test2SegV4Resolu.xml";
		//String NameFile="test3SegV3Resolu.xml";
		//String NameFile="test4SegV2Resolu.xml";
		//String NameFile="test5SegV3Resolu.xml";
		//String NameFile="test1SegV3EtiqAnaph.xml";
		//String NameFile="test2SegV4EtiqAnaph.xml";
		//String NameFile="test3SegV3EtiqAnaph.xml";
		//String NameFile="test4SegV2EtiqAnaph.xml";
		//String NameFile="test5SegV3EtiqAnaph.xml";
		//String NameFile="test2-3-4-5SegV3PartEtiqAnaph.xml";
		//String NameFile="testEssaiSegEtiqAnaph.xml";
		//String NameFile="texteM1_1SegEtiqAnaph.xml";
		//String NameFile="texteM1_2SegEtiqAnaph.xml";
		//String NameFile="texteM2SegEtiqAnaph.xml";
		//String NameFile="texteM3SegEtiqAnaph.xml";
		//String NameFile="texteM4SegEtiqAnaph.xml";
		//String NameFile="texteE2SegEtiqAnaph.xml";
		//String NameFile="texteE4SegEtiqAnaph.xml";
		//String NameFile="texteE6SegEtiqAnaph.xml";
		String NameFile="testEssaiSegEtiqAnaphResolu.xml";
		//StatMoyenneDistance(NameFile);
		//StatVerifCritere(NameFile);
		
		Double[] TP=ParticipationCriteres(NameFile);
		for(int i=0;i<TP.length;i++){
			System.out.println("Participation crit�re "+(i+1)+":"+TP[i]);
		}

	}
	public static double statDistAntecedEllipse(String NameFile){
		Texte txt = new Texte();
		Paragraphe parag=new Paragraphe();
		Phrase ph = new Phrase();
		Syntagme s=new Syntagme();
		Mot m=new Mot();
		Candidat ca=new Candidat();
		Mot mtAnteced=new Mot();
		Ellipse ellip=new Ellipse();
		List phs;
		List mots;
		//List ellipses;
		List ListCand=new ArrayList();
		String type_verb;
		int distance=0;
		int nbrEllip=0;
		double distanceMoy=0;
		txt.nomfichier= NameFile;
		String texte1 = txt.nomfichier.substring(0,txt.nomfichier.indexOf(".")); System.out.println("texte analys�:"+texte1);
		List parags=txt.ExtractParagraphe();
		List ListMotsPreEllipse=new ArrayList<String>();
		
		for(int pa=0;pa<parags.size();pa++){	
			 parag.paragraphe=(Element)parags.get(pa);
			 phs = parag.ExtrairePhrases();
			 for(int i=0;i<phs.size();i++){
				 ph.phrase=(Element)phs.get(i);
				 mots = ph.ExtraireMots();
				 ListMotsPreEllipse=MethodesDivers.ExtraireMotsPredEllipse(ph);
				 for(int k=0;k<mots.size();k++){
					 m.mot=(Element)mots.get(k);
					 type_verb=MethodesDivers.TypeVerbe(m.ExtraireVGRad());
						if(!MethodesDivers.TypeVerbe(m.ExtraireVGRad()).equals("")){
							System.out.println("mot courant:"+m.ExtraireValeur()+" indice mot:"+k+" vg courant:"+m.ExtraireVGRad());													
							if(MethodesDivers.AppartientListe(ListMotsPreEllipse,m.ExtraireValeur())){							
								System.out.println("******************nouvelle instance ellipse sujet");
								ellip=MethodesDivers.ExtractionEllipse(ph, m.ExtraireValeur());
								distance=distance+Integer.parseInt(ellip.ExtraireDistance());
								nbrEllip++;
					 }
				 }
				}
		   }
		}
		distanceMoy=distance/nbrEllip;
		return distanceMoy;
	}
	
	public static void StatVerifCritere(String NameFile){
		Texte txt=new Texte();
		Paragraphe parag=new Paragraphe();
		Phrase ph=new Phrase();
		Syntagme sy=new Syntagme();
		Mot mt=new Mot();
		//Candidat ca=new Candidat();
		//Candidat ant=new Candidat();
		List phs;
		List syntags;
		List mots;
		List ListCand;
		String NumPhrAnteced=new String();
		String NumMotAnteced=new String();
		String MeilleurCombin=new String();
		String type_verb=new String();
		String VerifCrit=new String();
		String Ref=new String();
		Mot MtAnteced=new Mot();
		List<String> ListVerifCr=new ArrayList<String>();
		List<String> ListBestCr=new ArrayList<String>();
		int NbrVerifAucun=0;
		int NbrVerifTous=0;
		int NbrVerif=0;
		int NbrTot=0;
		int dist=0;
		int numMot;
		List ListMotsPreEllipse=new ArrayList<String>();
		Antecedent BestAntEllipPreced=new Antecedent(0,"","","",0,0,"","","","");
		List<Ellipse_Candidat> List_Ellip_Cand=ExtractionEllipseAntecedents.Extraction(NameFile);
		List<Antecedent> ListAnteced=new ArrayList<Antecedent>();
		InstanceEllipse Ellip;
		txt.nomfichier= NameFile;
		String texte = txt.nomfichier.substring(0,txt.nomfichier.indexOf(".")); 
		System.out.println("texte analys�:"+texte);
		List parags=txt.ExtractParagraphe();
		for(int pa=0;pa<parags.size();pa++){	
			 parag.paragraphe=(Element)parags.get(pa);
			 phs = parag.ExtrairePhrases();
			 for(int i=0;i<phs.size();i++){
				 ph.phrase=(Element)phs.get(i);				 
				 mots = ph.ExtraireMots();
				 ListMotsPreEllipse=MethodesDivers.ExtraireMotsPredEllipse(ph);
				 for(int k=0;k<mots.size();k++){
					 mt.mot=(Element)mots.get(k);
					 numMot=Integer.parseInt(mt.ExtraireNum())-1;
					 type_verb=MethodesDivers.TypeVerbe(mt.ExtraireVGRad());
					 if(!MethodesDivers.TypeVerbe(mt.ExtraireVGRad()).equals("")){
						//System.out.println("mot courant:"+m.ExtraireValeur()+" indice mot:"+k+" vg courant:"+m.ExtraireVGRad());													
						if(MethodesDivers.AppartientListe(ListMotsPreEllipse,mt.ExtraireValeur())){							
							//System.out.println("******************nouvelle instance ellipse sujet");
							//if(EllipseMemeContexte(Ellip,m)){
							VerifCrit="";
							ListAnteced=MethodesDivers.RechercheListAnteced(List_Ellip_Cand,pa,i,k);
			        	    Ellip=MethodesDivers.RechercheEllipse(List_Ellip_Cand,pa,i,k);
							dist=MethodesDivers.Distance_Ellipse_VerbeGouvernant(phs,i, mt.ExtraireValeur());
			        	    Antecedent Anteced=MethodesDivers.RechercheMotAntecedent(NameFile,k, pa,i,dist);				        		
        					
	        				 //System.out.println("Anaphore de meme contexte:"+m.ExtraireValeur()+" phrase:"+(i+1));
        					//m.mot=(Element)mots.get(k);		        				 
	        				//System.out.println(Anteced.getValeur()+"///++++++"+m.ExtraireValeur());
	        				VerifCrit=Initialisation.VerifiedCriteria(mt,Anteced,ListAnteced,txt,pa,i,dist,BestAntEllipPreced);
							MeilleurCombin=mt.ExtraireMeilleurCombin();
							
							 //Le bon candidat v�rifie-t-il les meilleurs Crit�res???
							 System.out.println("Meilleur Combin:"+MeilleurCombin+" VS Verif Crit Anteced:"+VerifCrit);
							 if(MeilleurCombin.length()>0){
								 NbrTot++;
								 if(VerifCrit.length()>0){
									 ListVerifCr=Arrays.asList(VerifCrit.substring(1).split(" "));
									 ListBestCr=Arrays.asList(MeilleurCombin.split(" "));
									 if(ListVerifCr.containsAll(ListBestCr)) //&& ListBestCr.containsAll(ListVerifCr))
										 NbrVerifTous++;
									 if(!Collections.disjoint(ListVerifCr, ListBestCr))
										 NbrVerif++;
									 else if(Collections.disjoint(ListVerifCr, ListBestCr))
										 NbrVerifAucun++;
								 }
								 else if(VerifCrit.length()==0)
									 NbrVerifAucun++;
							 }
			        	 }
		        	 }
				 }				 
			 }
		}
		System.out.println("NbrVerifTous:"+NbrVerifTous);
		System.out.println("NbrVerif au moins 1:"+NbrVerif);
		System.out.println("NbrVerifAucun:"+NbrVerifAucun);
		System.out.println("NbrTotale:"+NbrTot);
	}
	
	public static Double[] ParticipationCriteres(String NameFile){
		System.out.println("Participation critere");
		int NbCrit=Integer.parseInt(LectureFichierTexte.LectureParametres("Input.txt").get(3));
		Integer[] TF= new Integer[NbCrit];
		Double[] TP= new Double[NbCrit];
		Texte txt = new Texte();
		Paragraphe parag=new Paragraphe();
		Phrase ph = new Phrase();
		Syntagme s=new Syntagme();
		Mot m=new Mot();
		Candidat ca=new Candidat();
		Mot mtAnteced=new Mot();
		List phs;
		List syntags;
		List mots;
		List ListCand=new ArrayList();
		String type_verb;
		String VerifCrit=new String();
		ArrayList<String> EnsbCombin=new ArrayList<String>();
		int IndexCrit;
		int dist=0;
		String[] EnsbVerifCrit;
		int NbrEllipBienResolu=0;
		int numMot;
		int indexEllip=-1;
		Antecedent BestAntEllipPreced=new Antecedent(0,"","","",0,0,"","","","");
		List ListMotsPreEllipse=new ArrayList<String>();
		for(int x=0;x<TF.length;x++){
			TF[x]=0;
		}
		List<Ellipse_Candidat> List_Ellip_Cand=ExtractionEllipseAntecedents.Extraction(NameFile);
		List<Antecedent> ListAnteced=new ArrayList<Antecedent>();
		InstanceEllipse Ellip;
		
		txt.nomfichier= NameFile;
		String texte1 = txt.nomfichier.substring(0,txt.nomfichier.indexOf(".")); 
		System.out.println("texte analys�:"+texte1);
		List parags=txt.ExtractParagraphe();
		for(int pa=0;pa<parags.size();pa++){	
			 parag.paragraphe=(Element)parags.get(pa);
			 phs = parag.ExtrairePhrases();
			 for(int i=0;i<phs.size();i++){
				 ph.phrase=(Element)phs.get(i);
				 mots = ph.ExtraireMots();
				 ListMotsPreEllipse=MethodesDivers.ExtraireMotsPredEllipse(ph);
				 for(int k=0;k<mots.size();k++){
					 m.mot=(Element)mots.get(k);
					 type_verb=MethodesDivers.TypeVerbe(m.ExtraireVGRad());
					 if(!MethodesDivers.TypeVerbe(m.ExtraireVGRad()).equals("")){
						//System.out.println("mot courant:"+m.ExtraireValeur()+" indice mot:"+k+" vg courant:"+m.ExtraireVGRad());													
						if(MethodesDivers.AppartientListe(ListMotsPreEllipse,m.ExtraireValeur())){							
							System.out.println("******************nouvelle instance ellipse sujet de verb gouv:"+m.ExtraireValeur());
							//if(EllipseMemeContexte(Ellip,m)){
							VerifCrit="";
							//ListAnteced=MethodesDivers.RechercheListAnteced(List_Ellip_Cand,pa,i,k);
							//Ellip=MethodesDivers.RechercheEllipse(List_Ellip_Cand,pa,i,k);
							//
							indexEllip++;
				        	Ellip=List_Ellip_Cand.get(indexEllip).getInst_Ellipse(); 
				        	ListAnteced=List_Ellip_Cand.get(indexEllip).getListeAnteced();							
							System.out.println("ellip:"+Ellip.getValVerbGouv());
							System.out.println("taille list anteced:"+ListAnteced.size());	
							System.out.println("phrase:"+ph.TextePhrase()+" verb gouv:"+m.ExtraireValeur());
							dist=MethodesDivers.Distance_Ellipse_VerbeGouvernant(phs,i, m.ExtraireValeur());
			        	    System.out.println("dist:"+dist);
			        	    System.out.println("recherche mot anteced k:"+k+" pa:"+pa+" i:"+i+" dist:"+dist);
			        	    Antecedent Anteced=MethodesDivers.RechercheMotAntecedent(NameFile,k, pa,i,dist);				        		
			        	    System.out.println("mot anteced:"+Anteced.getValeur());
			        	    //VerifCrit=EssaiQL.VerifiedCriteria(mtAnteced, m,txt, pa,ca.ExtraireNumPhrase(), i+1,dist);
	        				VerifCrit=Initialisation.VerifiedCriteria(m,Anteced,ListAnteced,txt,pa,i,dist,BestAntEllipPreced);
	        				System.out.println("Verified criteria:"+VerifCrit+" dist � l'anaphore:"+dist);
	        				if(VerifCrit.length()>0){
		        				 EnsbVerifCrit=VerifCrit.substring(1).split(" ");
		        				 System.out.println("nbr crit verif:"+EnsbVerifCrit.length+" Premier ele:"+EnsbVerifCrit[0]);
		        				 for(int c=0;c<EnsbVerifCrit.length;c++){
		        					 //System.out.println("combin possib:"+EnsbCombin.get(c));
		        					 IndexCrit=Integer.parseInt(EnsbVerifCrit[c])-1;
		        					 System.out.println("Index verif criteria:"+IndexCrit);
		        					 TF[IndexCrit]=TF[IndexCrit]+1; 
		        				 }
	        				 }
	        				 BestAntEllipPreced=Anteced;
        				 }
        				 else BestAntEllipPreced=new Antecedent(0,"","","",0,0,"","","","");
		        			 
		        	 }
				 }
			 }			 
		}
		NbrEllipBienResolu=indexEllip;
		System.out.println("Nbr Ellip Bien Resolu:"+NbrEllipBienResolu);
		for(int x=0;x<TF.length;x++){
			TP[x]=(double)TF[x]/NbrEllipBienResolu;
			System.out.print(TP[x]+"/");
		}
		System.out.println("");
		return TP;
	}
	public static void StatMoyenneDistance(String NameFile){
		Texte txt=new Texte();
		Paragraphe parag=new Paragraphe();
		Phrase ph=new Phrase();
		Syntagme sy=new Syntagme();
		Mot mt=new Mot();
		//Candidat ca=new Candidat();
		//Candidat ant=new Candidat();
		List phs;
		List syntags;
		List mots;
		List ListCand;
		String NumPhrAnteced=new String();
		String NumMotAnteced=new String();
		String MeilleurCombin=new String();
		String type_verb=new String();
		String VerifCrit=new String();
		String Ref=new String();
		Mot MtAnteced=new Mot();
		List<String> ListVerifCr=new ArrayList<String>();
		List<String> ListBestCr=new ArrayList<String>();
		List ListMotsPreEllipse=new ArrayList<String>();
		int NbrTot=0;
		int dist=0;
		int DistTot=0;
		int numMot;
		
		txt.nomfichier= NameFile;
		String texte = txt.nomfichier.substring(0,txt.nomfichier.indexOf(".")); 
		System.out.println("texte analys�:"+texte);
		List parags=txt.ExtractParagraphe();
		for(int pa=0;pa<parags.size();pa++){	
			 parag.paragraphe=(Element)parags.get(pa);
			 phs = parag.ExtrairePhrases();
			 for(int i=0;i<phs.size();i++){
				 ph.phrase=(Element)phs.get(i);
				 mots = sy.ExtraireMots();
				 for(int k=0;k<mots.size();k++){
					 mt.mot=(Element)mots.get(k);
					 numMot=Integer.parseInt(mt.ExtraireNum())-1;
					 type_verb=MethodesDivers.TypeVerbe(mt.ExtraireVGRad());
					 if(!MethodesDivers.TypeVerbe(mt.ExtraireVGRad()).equals("")){
						//System.out.println("mot courant:"+m.ExtraireValeur()+" indice mot:"+k+" vg courant:"+m.ExtraireVGRad());													
						if(MethodesDivers.AppartientListe(ListMotsPreEllipse,mt.ExtraireValeur())){							
							//System.out.println("******************nouvelle instance ellipse sujet");
							//if(EllipseMemeContexte(Ellip,m)){
							VerifCrit="";
			        	    dist=MethodesDivers.Distance_Ellipse_VerbeGouvernant(phs,i, mt.ExtraireValeur());
							System.out.println("Antecedent:"+MtAnteced.ExtraireValeur()+" distance="+dist);
							DistTot=DistTot+dist;
							 
			        	 }
		        	 }
				 }				 
			 }
		}
		System.out.println("NbrTotale:"+NbrTot);
		System.out.println("Dist moyenne:"+Double.toString(DistTot/NbrTot));
	}
}
