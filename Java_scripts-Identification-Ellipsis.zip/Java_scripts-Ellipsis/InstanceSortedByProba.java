package Detection_Resolution_Ellipse;

import java.util.*;

public class InstanceSortedByProba {
	
	int NumInstance;
	double ProbaDistrib;
	
	
	public InstanceSortedByProba(int NumInst, double probadistrib){
		NumInstance=NumInst;
		ProbaDistrib=probadistrib;
		}


	public int getNumInstance() {
		return NumInstance;
	}


	public void setNumInstance(int numInstance) {
		NumInstance = numInstance;
	}


	public double getProbaDistrib() {
		return ProbaDistrib;
	}


	public void setProbaDistrib(double probaDistrib) {
		ProbaDistrib = probaDistrib;
	}


	
	
	
}
