package Detection_Resolution_Ellipse;
 
public class InstanceEllipse {
	
	//private String Identifiant;
	private int Identifiant;
	private String Texte;
	private int NumParag;
	private int NumPhrase;
	private int NumVerbeGouvernant;
	private int NumPosition;
	private String PronVerbeGouv;
	private String TransVerbeGouv;
	private String VgVerbeGouv;
	private String ValVerbGouv;
	private int dist;
	private String bestCrit;
	
	
	
	public InstanceEllipse(int identifiant, String texte,int numParag, int numPhrase, int numVerbeGouvernant,int numPos){
		this.Identifiant=identifiant;
		this.Texte=texte;
		this.NumParag=numParag;
		this.NumPhrase=numPhrase;
		this.NumVerbeGouvernant=numVerbeGouvernant;
		this.NumPosition=numPos;
	}


	public int getIdentifiant() {
		return Identifiant;
	}

	public void setIdentifiant(int identifiant) {
		Identifiant = identifiant;
	}

	public String getTexte() {
		return Texte;
	}


	public void setTexte(String texte) {
		Texte = texte;
	}


	public int getNumPhrase() {
		return NumPhrase;
	}


	public void setNumPhrase(int numPhrase) {
		NumPhrase = numPhrase;
	}

	public int getNumParag() {
		return NumParag;
	}
	public void setNumParag(int numParag) {
		NumParag = numParag;
	}
	public int getNumPosition() {
		return NumPosition;
	}
	public void setNumPosition(int numPosition) {
		NumPosition = numPosition;
	}

	public int getNumVerbeGouvernant() {
		return NumVerbeGouvernant;
	}


	public void setNumVerbeGouvernant(int numVerbeGouvernant) {
		NumVerbeGouvernant = numVerbeGouvernant;
	}


	public String getPronVerbeGouv() {
		return PronVerbeGouv;
	}


	public void setPronVerbeGouv(String pronVerbeGouv) {
		PronVerbeGouv = pronVerbeGouv;
	}


	public String getTransVerbeGouv() {
		return TransVerbeGouv;
	}


	public void setTransVerbeGouv(String transVerbeGouv) {
		TransVerbeGouv = transVerbeGouv;
	}


	public String getVgVerbeGouv() {
		return VgVerbeGouv;
	}


	public void setVgVerbeGouv(String vgVerbeGouv) {
		VgVerbeGouv = vgVerbeGouv;
	}


	public String getValVerbGouv() {
		return ValVerbGouv;
	}


	public void setValVerbGouv(String valVerbGouv) {
		ValVerbGouv = valVerbGouv;
	}


	public int getDist() {
		return dist;
	}


	public void setDist(int dist) {
		this.dist = dist;
	}


	public String getBestCrit() {
		return bestCrit;
	}


	public void setBestCrit(String bestCrit) {
		this.bestCrit = bestCrit;
	}
	
	
}
