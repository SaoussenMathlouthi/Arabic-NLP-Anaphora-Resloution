package Detection_Resolution_Ellipse;

import java.io.*;

import java.util.*;

import org.jdom2.*;

import java.util.Iterator;

import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.bayes.NaiveBayes;
import weka.classifiers.bayes.NaiveBayesUpdateable;
import weka.classifiers.meta.FilteredClassifier;
import weka.classifiers.trees.J48;
import weka.core.*;
import weka.core.converters.ArffLoader;
import weka.core.converters.ArffSaver;
import weka.core.FastVector;
import weka.core.Instance;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.Remove;



import org.jdom2.input.*;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;



//import classificationSVM.ReadTxtFile;
//import classificationSVM.MethodeUtile;

//import classificationSVM.Mot;



import weka.core.Attribute;

public class ConstructFileArffPosEllipse {
  static Instances corpus = null;
  //static int NumPronom=0;
  
  public ConstructFileArffPosEllipse() {}
  //static Instance inst1 = new DenseInstance(37);
 // static List<String> ListParam=LectureFichierTexte.ReadParam("Parametres.txt");
//  static String[] ListTextes=ListParam.get(0).split(",");
  static List<InstanceEllipse> ListInstance=new ArrayList<InstanceEllipse>();
 
public static Instances CreationCorpus1(String choice, String[] ListTextes){
	  /****
	   * Construction de la liste d'attributs
	   */
	
	  //Mot m=null;
	/*public static Mot m=null;
	 public static Mot mp1=null;
	 public static Mot mp2=null;
	 public static Mot ms1=null;
	 public static Mot ms2=null;
	 public static Mot ms3=null;
	 public static Mot ms4=null;*/

	
	  FastVector attributes = new FastVector(27);
	    FastVector mots1 = new FastVector();
	    mots1 = null;
	    List<String> ListMotsPreEllipse=new ArrayList<String>();
	    String phrase_text=new String();
	    //Attribute Identifiant = new Attribute("ID");
	    /***
	     * Création des attributs
	     */
	    
	    FastVector my_nominal_test = new FastVector(1);
	    my_nominal_test.addElement("0");
	    my_nominal_test.addElement("1");
	    
	    FastVector my_nominal_vg = new FastVector(3);
	    for(int i=0;i<224;i++){
	    	my_nominal_vg.addElement(Integer.toString(i));
	    }
	    my_nominal_vg.addElement("");
	    
	    FastVector my_nominal_dist = new FastVector(3);
	    for(int i=0;i<60;i++){
	    	my_nominal_dist.addElement(Integer.toString(i));
	    }
	    my_nominal_dist.addElement("");
	    
	    Attribute existSujet = new Attribute("ExistSujet", my_nominal_test);
	    
	    Attribute existSignePonct = new Attribute("ExistSignePonct", my_nominal_test);
	    
	    Attribute vg_verb = new Attribute("VgVerb",my_nominal_vg);
	    
	    Attribute vg_mot_suiv1 = new Attribute("VgMotSuiv1",my_nominal_vg);
	    
	    Attribute vg_mot_suiv2 = new Attribute("VgMotSuiv2",my_nominal_vg);
	    
	    Attribute vg_mot_suiv3 = new Attribute("VgMotSuiv3",my_nominal_vg);
	    
	    Attribute vg_mot_preced1 = new Attribute("VgMotPreced1",my_nominal_vg);
	    
	    Attribute vg_mot_preced2 = new Attribute("VgMotPreced2",my_nominal_vg);
	    
	    Attribute vg_mot_preced3 = new Attribute("VgMotPreced3",my_nominal_vg);
	    
	    Attribute clause_preced_BF = new Attribute("ClausePrecedBF", my_nominal_test);
	    
	    Attribute dist_ellipse_CBF = new Attribute("DistEllipseCBF", my_nominal_dist);
	    
	    Attribute exist_Connecteur = new Attribute("ExistConnecteur", my_nominal_test);
	    
	    Attribute accord_VerbCEllip_VerbCBF = new Attribute("Accord_VerbCEllip_VerbCBF", my_nominal_test);
	    
	    Attribute verb_passif = new Attribute("VerbPassif", my_nominal_test);
	    
	    Attribute rules1 = new Attribute("Rules1", my_nominal_test);
	    Attribute rules2 = new Attribute("Rules2", my_nominal_test);
	    Attribute rules3 = new Attribute("Rules3", my_nominal_test);
	    Attribute rules4 = new Attribute("Rules4", my_nominal_test);
	    Attribute rules5 = new Attribute("Rules5", my_nominal_test);
	    Attribute rules6 = new Attribute("Rules6", my_nominal_test);
	    Attribute rules7 = new Attribute("Rules7", my_nominal_test);
	    Attribute rules8 = new Attribute("Rules8", my_nominal_test);
	    Attribute rules9 = new Attribute("Rules9", my_nominal_test);
	    Attribute rules10 = new Attribute("Rules10", my_nominal_test);
	    Attribute rules11 = new Attribute("Rules11", my_nominal_test);
	    Attribute rules12 = new Attribute("Rules12", my_nominal_test);
	    
	   	    
	    FastVector my_nominal_classe = new FastVector(1);
	    my_nominal_classe.addElement("0");
	    my_nominal_classe.addElement("1");

	    /***
	     * Création de l'attribut classe
	     */

	    Attribute classe = new Attribute("classe", my_nominal_classe);


	    /***
	     * Création du vecteur des attributs
	     */  	   
	   attributes.addElement(existSujet);
	   attributes.addElement(existSignePonct);
	   attributes.addElement(vg_verb);
	   attributes.addElement(vg_mot_suiv1);
	   attributes.addElement(vg_mot_suiv2);
	   attributes.addElement(vg_mot_suiv3);
	   attributes.addElement(vg_mot_preced1);
	   attributes.addElement(vg_mot_preced2);
	   attributes.addElement(vg_mot_preced3);
	   attributes.addElement(clause_preced_BF);
	   attributes.addElement(dist_ellipse_CBF);
	   attributes.addElement(exist_Connecteur);
	   attributes.addElement(accord_VerbCEllip_VerbCBF);
	   attributes.addElement(verb_passif);
	   
	   attributes.addElement(rules1);
	   attributes.addElement(rules2);
	   attributes.addElement(rules3);
	   attributes.addElement(rules4);
	   attributes.addElement(rules5);
	   attributes.addElement(rules6);
	   attributes.addElement(rules7);
	   attributes.addElement(rules8);
	   attributes.addElement(rules9);
	   attributes.addElement(rules10);
	   attributes.addElement(rules11);
	   attributes.addElement(rules12);
	   
	   
	   attributes.addElement(classe);

	    /***
	     * 
	     */
	    
	    corpus = new Instances("Corpus", attributes, 0);
	    String texte=new String();
	    int posCBF=-1;
	    int dist=0;
	    String mot_preced2=new String();
	    String type_verb=new String();
	    Phrase ph = new Phrase();
	    Phrase ph_preced = new Phrase();
	    List mots=new ArrayList<Mot>();
	    List mots_preced=new ArrayList<Mot>();
	    // Make position the class attribute
	    corpus.setClass(classe);
	    Mot m=new Mot();
	    Mot m_suiv1=new Mot();
	    Mot m_suiv_1=new Mot();
	    Mot m_suiv_2=new Mot();
	    Mot m_suiv_3=new Mot();
	    Mot m_preced=new Mot();
	    Mot m_pre_preced=new Mot();
	    Mot m_preced1=new Mot();
	    Mot m_preced2=new Mot();
	    Mot m_preced3=new Mot();
	    int nbr_inst_elliptique=0;
	    int nbr_inst_non_elliptique=0;
	    for(int t=0;t<ListTextes.length;t++){
	    	nbr_inst_elliptique=0;
	    	nbr_inst_non_elliptique=0;
	    	texte=ListTextes[t];
	    	System.out.println("+++++++++++++++++++++++++++++++++++"+texte);
	    	//String texteDonne="texte"+Integer.toString(t);
	    	ListMotsPreEllipse=new ArrayList<String>();
	    	//String [] ListMotsComp=new String[100];
	    	//ListElementMot=new ArrayList<Mot>();
		 	Texte txt = new Texte();
			  txt.nomfichier=texte;
			  List parags = txt.ExtractParagraphe();
			  for(int p=0;p<parags.size();p++){
				  System.out.println("nbr parags:"+parags.size());
				  Paragraphe parag=new Paragraphe();
				  parag.paragraphe=(Element)parags.get(p);
				  List phs=parag.ExtrairePhrases();
				  System.out.println("nbr phrase:"+phs.size());
				  //Iterator i = phs.iterator();
				  //while(i.hasNext()){
				  String clas = new String();
				  for(int i=0;i<phs.size();i++){
				    //ph = new Phrase();
				    ph.phrase=(Element)phs.get(i);
				    System.out.println(ph.TextePhrase());
				    phrase_text=ph.TextePhrase();
				    mots=ph.ExtraireMots();
				    ListMotsPreEllipse=MethodesDivers.ExtraireMotsPredEllipse(ph);
				    //Afficher_Liste(ListMotsPreEllipse);
				    String[] dataWord =ph.TextePhrase().split(" ");
				    //cas particulier d'étiquetage de textes
				    if(mots.size()==0){
				    	mots=ph.ExtraireMots2();
				    }
				    //*************************
				    if(i>0){
				    	//ph_preced = new Phrase();
					    ph_preced.phrase=(Element)phs.get(i-1);
					    mots_preced=ph_preced.ExtraireMots();
				    }
					
				    System.out.println("taille phrase:"+mots.size());
				    System.out.println("taille phrase preced:"+mots_preced.size());
				    System.out.println(ph.TextePhrase());
			    	//ListElementMot=new ArrayList<Mot>();
				    for(int j=0;j<mots.size();j++){
				    	//ListWord=new ArrayList<MotProperty>();
				    	
				    	mot_preced2="";
				    	//ListWord=new ArrayList<String>();
				    	m=new Mot();
						m.mot=(Element)mots.get(j);
						type_verb=MethodesDivers.TypeVerbe(m.ExtraireVGRad());
						//MotProperty w=new MotProperty(m.ExtraireVGRad(),m.ExtraireValeur(),m.ExtraireRad(),m.ExtraireGenre(),m.ExtraireNombre(),
						//		m.ExtraireVGEnc(),m.ExtraireValEnc(),m.ExtraireGenreanaph(),m.ExtraireNbranaph(),m.ExtraireVGProc());
						
						if(!MethodesDivers.TypeVerbe(m.ExtraireVGRad()).equals("")){
							Instance inst1 = new DenseInstance(27);
							System.out.println("mot courant:"+m.ExtraireValeur()+" vg courant:"+m.ExtraireVGRad());
														
							if(MethodesDivers.AppartientListe(ListMotsPreEllipse,m.ExtraireValeur())){
								inst1.setValue(classe, "1");
								System.out.println("nouveau instance ellipse sujet");
								nbr_inst_elliptique+=1;
							}
							else{
								inst1.setValue(classe, "0");
								nbr_inst_non_elliptique+=1;
							}
														
							// Initialisation des attributs et des règles
							inst1.setValue(existSujet,"0");
							inst1.setValue(existSignePonct,"0");
							inst1.setValue(vg_verb,"");
							inst1.setValue(vg_mot_suiv1,"");
							inst1.setValue(vg_mot_suiv2,"");
							inst1.setValue(vg_mot_suiv3,"");
							inst1.setValue(vg_mot_preced1,"");
							inst1.setValue(vg_mot_preced2,"");
							inst1.setValue(vg_mot_preced3,"");
							inst1.setValue(clause_preced_BF,"0");
							inst1.setValue(dist_ellipse_CBF,"");
							inst1.setValue(exist_Connecteur,"0");
							inst1.setValue(accord_VerbCEllip_VerbCBF,"0");
							inst1.setValue(verb_passif,"0");
							
							inst1.setValue(rules1,"0");
							inst1.setValue(rules2,"0");
							inst1.setValue(rules3,"0");
							inst1.setValue(rules4,"0");
							inst1.setValue(rules5,"0");
							inst1.setValue(rules6,"0");
							inst1.setValue(rules7,"0");
							inst1.setValue(rules8,"0");
							inst1.setValue(rules9,"0");
							inst1.setValue(rules10,"0");
							inst1.setValue(rules11,"0");
							inst1.setValue(rules12,"0");
							
							/***
						     * Création du vecteur des attributs
						     */
							//***********************************creation atribut vecteur verb_passif
							System.out.println("****creation attribut vecteur verb_passif");
							if(MethodesDivers.EstunVerbPassif(m.ExtraireVGRad()))
								inst1.setValue(verb_passif, "1");
							else
								inst1.setValue(verb_passif, "0");
							//***********************rules5
							System.out.println("****creation attribut rules5");
							if(m.ExtraireVGRad().equals("113")||m.ExtraireVGRad().equals("114"))
								inst1.setValue(rules5, "1");
							//***********************rules6
							System.out.println("****creation attribut rules6");
							if(m.ExtraireVGRad().equals("117"))
								inst1.setValue(rules6, "1");
							//***********************rules8
							System.out.println("****creation attribut rules8: verbe conjugué au premier et au deuxième personne du singulier et du pluriel");
							if(MethodesDivers.PronVerbe_PremierDeuxiemePersonne(m.ExtrairePronom()))	//15-11-2019
								inst1.setValue(rules8, "1");
							//***********************rules9
							System.out.println("****creation attribut rules9");
							if(type_verb.equals("verbe passe connu")||type_verb.equals("verbe present connu")||
									type_verb.equals("verbe passe incomplet conjugue")||type_verb.equals("verbe present complet conjugue")||
									type_verb.equals("verbe present incomplet conjugue"))
								inst1.setValue(rules9, "1");
							//***********************************creation atribut vecteur vg_verb
							System.out.println("****creation attribut vg_verb");
							inst1.setValue(vg_verb, m.ExtraireVGRad());
							if(j==mots.size()-1){
								System.out.println("****creation attribut existSujet, rules1");
								inst1.setValue(existSujet, "0");
								inst1.setValue(rules1, "1");
							}	
							if(j>1){	//Position clause bien formée dans la phrase courante et dist clause elliptique-clause Bien formée
								//posCBF=MethodesDivers.PositionClauseBienFormée(mots,Integer.valueOf(m.ExtraireNum()));
								posCBF=MethodesDivers.PositionClauseBienFormée(mots,j);
								if(posCBF!=-1){
									//***********************creation attribut vecteur clause_preced_BF
									System.out.println("****creation atribut clause_preced_BF");
									inst1.setValue(clause_preced_BF, "1");
									//dist=Integer.valueOf(m.ExtraireNum())-posCBF;
									dist=j-posCBF;
									System.out.println("distance ellip CB "+dist);
									//***********************creation attribut vecteur dist_ellipse_CBF
									System.out.println("****creation atribut dist_ellipse_CBF");
									inst1.setValue(dist_ellipse_CBF, Integer.toString(dist));
									//***********************creation attribut vecteur accord_VerbCEllip_VerbCBF
									System.out.println("****creation atribut accord_VerbCEllip_VerbCBF");
									if(MethodesDivers.Accord_Verb_Cl_BF_Cl_Ellip(mots,j,posCBF)){
										inst1.setValue(accord_VerbCEllip_VerbCBF, "1");
										m_preced=new Mot();
										m_preced.mot=(Element)mots.get(j-1);
										m_pre_preced=new Mot();
										m_pre_preced.mot=(Element)mots.get(j-2);
										//***********************creation attribut vecteur rules3	////Modifier le 02/08/2020
										System.out.println("****creation atribut rules3");
										if(MethodesDivers.EstunConnecteur(m.ExtraireVGProc(),m_preced.ExtraireVGRad(),
												m_preced.ExtraireValeur(),m_pre_preced.ExtraireValeur()))
											inst1.setValue(rules3, "1");
										}
									else
										inst1.setValue(accord_VerbCEllip_VerbCBF, "0");	
									}
								else
									inst1.setValue(clause_preced_BF, "0");	
								}
								else {	//chercher Position clause bien formée dans la phrase précédente et dist clause elliptique - clause Bien formée
									if(i>0){
										System.out.println("mots phrase preced:"+mots_preced.size());
										posCBF=MethodesDivers.PositionClauseBienFormée(mots_preced,mots_preced.size());
										if(posCBF!=-1){
											//***********************creation attribut vecteur clause_preced_BF
											System.out.println("****creation atribut clause_preced_BF");
											inst1.setValue(clause_preced_BF, "1");
											dist=j+(mots_preced.size()-posCBF);
											System.out.println("distance ellip CB="+dist);
											//***********************creation attribut vecteur dist_ellipse_CBF
											System.out.println("****creation atribut dist_ellipse_CBF");
											inst1.setValue(dist_ellipse_CBF, Integer.toString(dist));
											//***********************creation attribut vecteur accord_VerbCEllip_VerbCBF
											System.out.println("****creation atribut accord_VerbCEllip_VerbCBF");
											if(MethodesDivers.Accord_Verb_Cl_BF_Cl_Ellip2(mots,mots_preced,j,posCBF)){
												inst1.setValue(accord_VerbCEllip_VerbCBF, "1");
												m_preced=new Mot();
												if(j==1)	m_preced.mot=(Element)mots.get(j-1);
												
												//***********************creation attribut vecteur rules3	////Modifier le 02/08/2020
												System.out.println("****creation atribut rules3");
												if(MethodesDivers.EstunConnecteur(m.ExtraireVGProc(),m_preced.ExtraireVGRad(),
														m_preced.ExtraireValeur(),""))
													inst1.setValue(rules3, "1");
											}
											else
												inst1.setValue(accord_VerbCEllip_VerbCBF, "0");
												
										}
										else{
											inst1.setValue(clause_preced_BF, "0");
											
										}
										
									}
								}
							//}
							if(j+1<mots.size()){
								//***********************creation attribut vecteur existSignePonct
								System.out.println("****creation atribut existSignePonct");
								//if(MethodesDivers.ExistSignePonct(phrase_text, Integer.valueOf(m.ExtraireNum())))
								if(MethodesDivers.ExistSignePonct(phrase_text, j))
									inst1.setValue(existSignePonct, "1");
								else
									inst1.setValue(existSignePonct, "0");						
								m_suiv1=new Mot();
								m_suiv1.mot=(Element)mots.get(j+1);
								//***********************creation atribut vecteur vg_mot_suiv1
								System.out.println("****creation attribut vg_mot_suiv1");
								if(!m_suiv1.ExtraireVGRad().equals(""))
									inst1.setValue(vg_mot_suiv1, m_suiv1.ExtraireVGRad());
								else
									inst1.setValue(vg_mot_suiv1, m_suiv1.ExtraireVGEnc());
								//***********************creation attribut vecteur rules2
								System.out.println("****creation attribut rules2");
								System.out.println("mot suiv:"+m_suiv1.ExtraireValeur()+" "+m_suiv1.ExtraireVGRad());
								if((MethodesDivers.EstunNom(m_suiv1.ExtraireVGRad())&& !MethodesDivers.EstunNomNominatif(m_suiv1.ExtraireVGRad()))
										||(MethodesDivers.EstunePreposition(m_suiv1.ExtraireVGRad()))){
									inst1.setValue(rules2, "1");
								}
								//***********************rules7
								System.out.println("****creation attribut rules7");
								if(m.equals(m_suiv1))
									inst1.setValue(rules7, "1");
								//***********************rules4
								System.out.println("****Amélioration attribut rules4: le mot suivant est la particule èaNo");	//modifier le 15/08/2020
								if((m_suiv1.ExtraireVGRad().equals("89")||m_suiv1.ExtraireVGRad().equals("90"))
										&& m_suiv1.ExtraireRad().equals("èaNo"))
									inst1.setValue(rules4, "1");
								//***********************creation attribut vecteur existSujet, rules4
								System.out.println("****creation attribut existSujet, rules4");
								System.out.println("mot suiv:"+m_suiv1.ExtraireValeur()+" "+m_suiv1.ExtraireVGRad());
								if(MethodesDivers.EstunNomNominatif(m_suiv1.ExtraireVGRad())||
										(m_suiv1.ExtraireVGRad().equals("10")&& MethodesDivers.Accord_GNP(m.ExtrairePronom(), m_suiv1.ExtraireGenre(), m_suiv1.ExtraireNombre()))){	//Modifier le 10/08/2020
									inst1.setValue(existSujet, "1");
									inst1.setValue(rules1, "0");
									inst1.setValue(rules4, "1");
								
								}
								else{ // Pas de nom nominatif après le verbe; ellipse sujet probable
									inst1.setValue(existSujet, "0");
									inst1.setValue(rules1, "1");
									if(j+2<mots.size()){
										m_suiv_2=new Mot();
										m_suiv_2.mot=(Element)mots.get(j+2);
										if(MethodesDivers.EstunNomNominatif(m_suiv_2.ExtraireVGRad())){
											inst1.setValue(rules1, "0");
											//***********************creation attribut vecteur rules4
											System.out.println("****creation atribut rules4");
											if(MethodesDivers.EstunNom(m_suiv1.ExtraireVGRad()))
												inst1.setValue(rules4, "1");
										}
										else{
											inst1.setValue(rules1, "1");
											if(j+3<mots.size()){
												m_suiv_3=new Mot();
												m_suiv_3.mot=(Element)mots.get(j+3);
												if(MethodesDivers.EstunNomNominatif(m_suiv_3.ExtraireVGRad())){
													inst1.setValue(rules1, "0");
													//***********************creation attribut vecteur rules4
													System.out.println("****creation atribut rules4");
													System.out.println("mot suivant 1 et 2:"+m_suiv1.ExtraireVGRad()+" "+m_suiv_2.ExtraireVGRad());
													if(MethodesDivers.EstunePreposition(m_suiv1.ExtraireVGRad())&& 
															MethodesDivers.EstunNom(m_suiv_2.ExtraireVGRad()))
														inst1.setValue(rules4, "1");
												}
												else{
													inst1.setValue(rules1, "1");
													//Attribut rules12: le verbe est conjugué et connu et il n'existe pas un nom nominatif parmi les 3 mots suivants
													if(type_verb.equals("verbe passe connu")||type_verb.equals("verbe present connu")||
															type_verb.equals("verbe passe incomplet conjugue")||type_verb.equals("verbe present complet conjugue")||
															type_verb.equals("verbe present incomplet conjugue"))
														inst1.setValue(rules12, "1");
												}
													
												
											}
										}
									}
									if(j>1){	//Position clause bien formée dans la phrase courante et dist clause elliptique-clause Bien formée
										//posCBF=MethodesDivers.PositionClauseBienFormée(mots,Integer.valueOf(m.ExtraireNum()));
										posCBF=MethodesDivers.PositionClauseBienFormée(mots,j);
										if(posCBF!=-1){
											//***********************creation attribut vecteur clause_preced_BF
											System.out.println("****creation atribut clause_preced_BF");
											inst1.setValue(clause_preced_BF, "1");
											//dist=Integer.valueOf(m.ExtraireNum())-posCBF;
											dist=j-posCBF;
											System.out.println("distance ellip CB "+dist);
											//***********************creation attribut vecteur dist_ellipse_CBF
											System.out.println("****creation atribut dist_ellipse_CBF");
											inst1.setValue(dist_ellipse_CBF, Integer.toString(dist));
											//***********************creation attribut vecteur accord_VerbCEllip_VerbCBF
											System.out.println("****creation atribut accord_VerbCEllip_VerbCBF");
											if(MethodesDivers.Accord_Verb_Cl_BF_Cl_Ellip(mots,j,posCBF)){
												inst1.setValue(accord_VerbCEllip_VerbCBF, "1");
												m_preced=new Mot();
												m_preced.mot=(Element)mots.get(j-1);
												m_pre_preced=new Mot();
												m_pre_preced.mot=(Element)mots.get(j-2);
												//***********************creation attribut vecteur rules3	////Modifier le 02/08/2020
												System.out.println("****creation atribut rules3");
												if(MethodesDivers.EstunConnecteur(m.ExtraireVGProc(),m_preced.ExtraireVGRad(),
														m_preced.ExtraireValeur(),m_pre_preced.ExtraireValeur()))
													inst1.setValue(rules3, "1");
											}
											else
												inst1.setValue(accord_VerbCEllip_VerbCBF, "0");
												
										}
										else{
											inst1.setValue(clause_preced_BF, "0");
											
										}
										
									}
									else {	//Position clause bien formée dans la phrase précédente et dist clause elliptique - clause Bien formée
										if(i>0){
											posCBF=MethodesDivers.PositionClauseBienFormée(mots_preced,mots_preced.size());
											if(posCBF!=-1){
												//***********************creation attribut vecteur clause_preced_BF
												System.out.println("****creation atribut clause_preced_BF");
												inst1.setValue(clause_preced_BF, "1");
												dist=j+(mots_preced.size()-posCBF);
												System.out.println("distance ellip CB="+dist);
												//***********************creation attribut vecteur dist_ellipse_CBF
												System.out.println("****creation atribut dist_ellipse_CBF");
												inst1.setValue(dist_ellipse_CBF, Integer.toString(dist));
												//***********************creation attribut vecteur accord_VerbCEllip_VerbCBF
												System.out.println("****creation atribut accord_VerbCEllip_VerbCBF");
												if(MethodesDivers.Accord_Verb_Cl_BF_Cl_Ellip2(mots,mots_preced,j,posCBF)){
													inst1.setValue(accord_VerbCEllip_VerbCBF, "1");
													m_preced=new Mot();
													if(j==1)	m_preced.mot=(Element)mots.get(j-1);
													
													//***********************creation attribut vecteur rules3	////Modifier le 02/08/2020
													System.out.println("****creation atribut rules3");
													if(MethodesDivers.EstunConnecteur(m.ExtraireVGProc(),m_preced.ExtraireVGRad(),
															m_preced.ExtraireValeur(),""))
														inst1.setValue(rules3, "1");
												}
												else
													inst1.setValue(accord_VerbCEllip_VerbCBF, "0");
													
											}
											else{
												inst1.setValue(clause_preced_BF, "0");
												
											}
											
										}
									}
								}
								
								if(j+2<mots.size()){
									Mot m_suiv2=new Mot();
									m_suiv2.mot=(Element)mots.get(j+2);
									//**********************creation vecteur vg_mot_suiv2
									System.out.println("****creation atribut vg_mot_suiv2");
									if(!m_suiv2.ExtraireVGRad().equals(""))
										inst1.setValue(vg_mot_suiv2, m_suiv2.ExtraireVGRad());
									else
										inst1.setValue(vg_mot_suiv2, m_suiv2.ExtraireVGEnc());
									if(j+3<mots.size()){
										Mot m_suiv3=new Mot();
										m_suiv3.mot=(Element)mots.get(j+3);
										//********************creation vecteur vg_mot_suiv3
										System.out.println("****creation atribut vg_mot_suiv3");
										if(!m_suiv3.ExtraireVGRad().equals(""))
											inst1.setValue(vg_mot_suiv3, m_suiv3.ExtraireVGRad());
										else
											inst1.setValue(vg_mot_suiv3, m_suiv3.ExtraireVGEnc());
									}
								}
								
							}							
							if(j>0){
								m_preced1=new Mot();
								m_preced1.mot=(Element)mots.get(j-1);
								System.out.println("****creation attribut vg_mot_preced1");
								inst1.setValue(vg_mot_preced1, m_preced1.ExtraireVGRad());
								
								System.out.println("****creation attribut rules11");	//Modifier le 02/08/2020								
								if((MethodesDivers.EstunNomNominatif(m_preced1.ExtraireVGRad())
										&&!MethodesDivers.EstunConnecteur(m.ExtraireVGProc(),m_preced1.ExtraireVGRad(),m_preced1.ExtraireValeur(),mot_preced2))
										||m_preced1.ExtraireVGRad().equals("10"))
									inst1.setValue(rules11, "1");
								
								System.out.println("****creation attribut rules10");
								if(MethodesDivers.EstunPronomRelatif(m_preced1.ExtraireVGRad(),m_preced1.ExtraireRad())
										||MethodesDivers.EstuneParticuleInterrogative(m_preced1.ExtraireVGRad()))
									inst1.setValue(rules10, "1");
								else
									inst1.setValue(rules10, "0");
								if(j>1){
									m_preced2=new Mot();
									m_preced2.mot=(Element)mots.get(j-2);
									mot_preced2=m_preced2.ExtraireValeur();
									System.out.println("****creation attribut vg_mot_preced2");
									inst1.setValue(vg_mot_preced2, m_preced2.ExtraireVGRad());
									
									System.out.println("****creation attribut rules11");	//Ajouter le 10/08/2020								
									if((MethodesDivers.EstunNomNominatif(m_preced2.ExtraireVGRad())
											&&!MethodesDivers.EstunConnecteur(m.ExtraireVGProc(),m_preced1.ExtraireVGRad(),m_preced1.ExtraireValeur(),mot_preced2))
											&&(MethodesDivers.EstunNomPropre(m_preced1.ExtraireVGRad())
													||MethodesDivers.EstunAdjectifNominatif(m_preced1.ExtraireVGRad())
															||MethodesDivers.EstunAnnexe(m_preced1.ExtraireVGRad())))
										inst1.setValue(rules11, "1");									
									if(j>2){
										m_preced3=new Mot();
										m_preced3.mot=(Element)mots.get(j-3);
										System.out.println("****creation attribut vg_mot_preced3");
										inst1.setValue(vg_mot_preced3, m_preced3.ExtraireVGRad());
									}
								}
								//***********************creation attribut vecteur exist_Connecteur
								System.out.println("****creation atribut exist_Connecteur");
								//if(MethodesDivers.EstunConnecteur(m.ExtraireVGEnc(),m_preced1.ExtraireVGRad(),m_preced1.ExtraireValeur(),mot_preced2))
								//corriger le 02/08/2020
								if(MethodesDivers.EstunConnecteur(m.ExtraireVGProc(),m_preced1.ExtraireVGRad(),m_preced1.ExtraireValeur(),mot_preced2))
									inst1.setValue(exist_Connecteur, "1");
								else
									inst1.setValue(exist_Connecteur, "0");
								
							}
							
						    inst1.setDataset(corpus);
						    corpus.add(inst1);
						    System.out.println("Nouvelle instance ajoutée");
					    }
				    }
				  } 
			  }
			  System.out.println("****** nbr d'instances elliptiques du texte "+texte+" est:"+nbr_inst_elliptique);
			  System.out.println("****** nbr d'instances non elliptiques du texte "+texte+" est:"+nbr_inst_non_elliptique);
	    }
	    //ListInstanceF.addAll(ListInstance);
	    
	  Instances inst = new Instances(corpus);
	  System.out.println("Nombre des attributs: " + inst.numAttributes());
	  System.out.println("Nombre des instances Data: " + inst.numInstances());
	  System.out.println("Nombre de classe: " + inst.numClasses());
	  

	  return corpus;
	}

public static void CreerFichier(String texte){
  try{
    //BufferedWriter writer = new BufferedWriter(new FileWriter(
        //texte.substring(0, texte.indexOf(".")).concat(".arff")));
	BufferedWriter writer = new BufferedWriter(new FileWriter(
      texte.concat(".arff")));
    writer.write(corpus.toString());
    System.out.println("corpus créé avec succès " + corpus.numInstances());
    writer.flush();
    writer.close();
  }
  catch (Exception e){System.out.println(e);}

}
static void enregistre(String fichier,Document document)
{
   try
   {
      
      XMLOutputter sortie = new XMLOutputter(Format.getPrettyFormat());
      
      
      sortie.output(document, new FileOutputStream(fichier));
   }
   catch (java.io.IOException e){}
}
public static void Resultat(Evaluation eval,String nom) throws JDOMException, IOException{

	SAXBuilder builder = new SAXBuilder();
    Document document = builder.build(new File("resultat.xml"));
    Element racine = document.getRootElement();
    
	  Element resultat = new Element("resultat");
	  racine.addContent(resultat);
	  resultat.setAttribute("Nom",nom);
	  Element table4 = new Element("numberofcorrectlyclassifiedinstances");
	  resultat.addContent(table4);
	  String kk=String.valueOf(eval.correct());
	  table4.addContent(kk);
	  Element table = new Element("CorrectlyClassifiedInstances");
	  resultat.addContent(table);
	  String pc=String.valueOf(eval.pctCorrect()); 
	  table.addContent(pc);
	  Element table1 = new Element("numberofIncorrectlyClassifiedInstances");
	  resultat.addContent(table1);
	  String hh=String.valueOf(eval.incorrect());
	  table1.addContent( hh);
	  Element table2 = new Element("IncorrectlyClassifiedInstances");
	  resultat.addContent(table2);
	  String pic=String.valueOf(eval.pctIncorrect()); 
	  table2.addContent(pic);
	  XMLOutputter sortie = new XMLOutputter(Format.getPrettyFormat());
	  sortie.output(document, new FileOutputStream("resultat.xml"));
	
}


public static void Afficher_Liste(List<String> ListMots){
	//System.out.println("Taille de la liste:"+ListMots.size());
	System.out.println("Affichage");
	for(int a=0;a<ListMots.size();a++){
		System.out.println(ListMots.get(a)+" ");
	}
}
public static void Afficher(MotProperty w){
	System.out.print(w.getRad()+" ");System.out.print(w.getVg()+" "); System.out.print(w.getGenr()+" ");
	 System.out.print(w.getVal()+" "); System.out.print(w.getVgenc()+" ");System.out.println();
}
public static void ConstructArffFile0(){
	String[] ListTextesEtiq= new String[1];
	ListTextesEtiq[0]="fichierResultat1.xml";
	ConstructFileArffPosEllipse cc = new ConstructFileArffPosEllipse();
	cc.CreationCorpus1("Etiq",ListTextesEtiq);
	CreerFichier("fichResultatTrain");
	
	String[] ListTextesNonEtiq= new String[3];	
	ListTextesNonEtiq[0]="fichierResultat2.xml";
	ListTextesNonEtiq[1]="fichierResultat4.xml";ListTextesNonEtiq[2]="fichierResultat5.xml";
	ConstructFileArffPosEllipse cc1 = new ConstructFileArffPosEllipse();
	cc1.CreationCorpus1("Etiq",ListTextesNonEtiq);
	CreerFichier("fichResultatUnlabel");
	
	String[] ListTextesTest= new String[1];	
	ListTextesTest[0]="fichierResultat3.xml";
	ConstructFileArffPosEllipse cc2 = new ConstructFileArffPosEllipse();
	cc2.CreationCorpus1("Etiq",ListTextesTest);
	CreerFichier("fichResultatTest");
}
public static void ConstructArffFileEssai(){
	String[] ListTextesEtiq= new String[1];
	ListTextesEtiq[0]="fichierResultat1.xml";
	ConstructFileArffPosEllipse cc = new ConstructFileArffPosEllipse();
	cc.CreationCorpus1("Etiq",ListTextesEtiq);
	CreerFichier("fichResultatTrain_3");
	
	String[] ListTextesNonEtiq= new String[3];	
	ListTextesNonEtiq[0]="fichierResultat3.xml";
	ListTextesNonEtiq[1]="fichierResultat4.xml";ListTextesNonEtiq[2]="fichierResultat5.xml";
	ConstructFileArffPosEllipse cc1 = new ConstructFileArffPosEllipse();
	cc1.CreationCorpus1("Etiq",ListTextesNonEtiq);
	CreerFichier("fichResultatUnlabel_3");
	
	String[] ListTextesTest= new String[1];	
	ListTextesTest[0]="fichierResultat2.xml";
	ConstructFileArffPosEllipse cc2 = new ConstructFileArffPosEllipse();
	cc2.CreationCorpus1("Etiq",ListTextesTest);
	CreerFichier("fichResultatTest_3");
}
public static String DuplicationMeilleuresInstancesEllipClasse1(String FileTest, int nbrDuplic){
	  String FinalFile=new String();
	  FinalFile=FileTest.substring(0, FileTest.indexOf(".")).concat("_Duplic").concat(".arff");
	  
	  try {
		  
		  BufferedReader BrFile=new BufferedReader(new FileReader(FileTest));  
	      Instances InstFile = new Instances(BrFile);
	      InstFile.setClassIndex(InstFile.numAttributes()-1);
	      System.out.println(FileTest);
	      ArffSaver saver = new ArffSaver();
	      saver.setInstances(InstFile);
	      saver.setFile(new File(FinalFile));
	      saver.writeBatch();
	      
	      BufferedWriter BwNewFile=new BufferedWriter(new FileWriter(FinalFile,true)); 	
	      //int[] ListInstNonDuplic = new int[13];
	      //int[] TabInstNonDuplic = new int[] {3,4,7,8,27,40,41,42,51,52,54,65,66,72,74,75,84,85,92,98,103,105,110,132,159};
	      int[] TabInstNonDuplic = new int[] {3,7,40,41,42,51,52,54,66,72,73,74,75,77,84,85,92,98,103,105,110,132,141,152,159};
	      //ListInstNonDuplic[0]=9;		      ListInstNonDuplic[1]=12;		    ListInstNonDuplic[2]=14;
	      List<Integer> ListInstNonDuplic = new ArrayList<Integer>();
	      for(int j=0;j<TabInstNonDuplic.length;j++){
	    	  System.out.println(TabInstNonDuplic[j]+" ");
	    	  ListInstNonDuplic.add(TabInstNonDuplic[j]);
	      }		     
			for(int i=0;i<InstFile.numInstances();i++){
				System.out.println(i+" "+ListInstNonDuplic.contains(i));
				  if(!ListInstNonDuplic.contains(i)&& InstFile.instance(i).toString(InstFile.classIndex()).equals("1")){
					  System.out.println("inst "+i);
					  for(int j=0;j<nbrDuplic;j++)
						  BwNewFile.write("\n"+InstFile.instance(i).toString());	
				  }//Dupliquer l'instance choisie					  
			  }
			
			BwNewFile.close();
			BrFile.close();
			System.out.println(" Duplication termin�e");
			Instances insts = new Instances(new BufferedReader(new FileReader(FinalFile)));	//Donn�es �tiquet�es
		    System.out.println("instance duplicated file unlabeled"+insts.numInstances());
			
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return FinalFile;
}
public static void ConstructArffFile(){
	String TextesEtiq1=LectureFichierTexte.LectureParametres("ParametresClassification.txt").get(4);
	String TextesEtiq2=LectureFichierTexte.LectureParametres("ParametresClassification.txt").get(5);
	String TextesEtiq3=LectureFichierTexte.LectureParametres("ParametresClassification.txt").get(6);
	String[] ListTextesEtiq = TextesEtiq1.split(",");
	String[] ListTextesNonEtiq = TextesEtiq2.split(",");
	String[] ListTextesTest = TextesEtiq3.split(",");
	
	ConstructFileArffPosEllipse cc = new ConstructFileArffPosEllipse();
	cc.CreationCorpus1("Etiq",ListTextesEtiq);
	CreerFichier("CorpusTrainEtiq");
	
	ConstructFileArffPosEllipse cc1 = new ConstructFileArffPosEllipse();
	cc1.CreationCorpus1("Etiq",ListTextesNonEtiq);
	CreerFichier("CorpusTrainNonEtiq");
	
	ConstructFileArffPosEllipse cc2 = new ConstructFileArffPosEllipse();
	cc2.CreationCorpus1("Etiq",ListTextesTest);
	CreerFichier("CorpusTest");
}
public static void main(String[] args) {
	//creer les fichiers .arff etiqueté et non etiquete
	//ConstructArffFile();
	//ConstructArffFileEssai();
	String FileTest="CorpusTest.arff";
	DuplicationMeilleuresInstancesEllipClasse1(FileTest,3);
	System.out.println("fichier dupliqué");
}
}







