package Detection_Resolution_Ellipse;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;

public class LectureModelCollocation {
	static public String fichierCollo = "Collocation.xml";
	public static Element OuvrirFichier(){
	    org.jdom2.Document document;
	    Element racine= new Element("Modeles");
	    
	    SAXBuilder sxb = new SAXBuilder();

	  try {
	    document = sxb.build(new File(fichierCollo));
	    racine = document.getRootElement();
	    
	  //System.out.println("ouverture fichier avec succes");

	  }
	  catch (Exception e) {System.out.println(e.getMessage());}

	  return racine;

	}
	public static List ExtractCollocation(){
	    List collocations = new ArrayList();
	    Element racine = OuvrirFichier();
	    //System.out.println(racine.getName());
	    //System.out.println(racine.getChildren().size());
	    String s=racine.getAttributeValue("xmlns");
	    //System.out.println("fichier:"+s);
	    
	    collocations = racine.getChildren();
	   //System.out.println(collocations.size());
	    return collocations;
	  }
	
	public static List<String> ExtractValeurCollo(){
		String val=new String();
		List listVal=new ArrayList<String>();
		List collocations=ExtractCollocation();
		for(int i=0;i<collocations.size();i++){
			//Element collocation=new Element();
			val=((Element)collocations.get(i)).getAttributeValue("Valeur");
			//val=collocation.getAttributeValue("Valeur");
			listVal.add(val);
		}
		
		return listVal;
	}
	public static void main(String[] args) {
		List listcollo=ExtractValeurCollo();
		for(int i=0;i<listcollo.size();i++){
			System.out.println(listcollo.get(i));
		}
	}
}
