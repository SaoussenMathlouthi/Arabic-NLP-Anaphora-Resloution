package Detection_Resolution_Ellipse;
import java.util.Collections;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

public class Comparateur {
	public void main(String[] args){
		 Antecedent Ant=new Antecedent(0,"","","",0,0,"","","","");
		    Antecedent Ant1=new Antecedent(0,"","","",0,0,"","","","");
		    Ant1.setScore((float)2.5);
		    Antecedent Ant2=new Antecedent(0,"","","",0,0,"","","","");
		    Ant2.setScore((float)0.5);
		    ArrayList<Antecedent> myList=new ArrayList<Antecedent>();
		    myList.add(Ant1);
		    myList.add(Ant2);
		Compare(myList);
	}
	public static void Compare(ArrayList<Antecedent> myList){
	   
	    Collections.sort(myList, new Comparator<Antecedent>() {
	        public int compare(Antecedent p1, Antecedent p2) {
	            // return p1.age+"".compareTo(p2.age+""); //sort by age
	            return (int) (p1.getScore()+"".compareTo(p2.getScore()+"")); // if you want to short by name
	        }
	    });
	    System.out.println(myList.toString());
	    
	    Collections.reverse(myList);
	    System.out.println(myList.toString());
	    

	}

}
