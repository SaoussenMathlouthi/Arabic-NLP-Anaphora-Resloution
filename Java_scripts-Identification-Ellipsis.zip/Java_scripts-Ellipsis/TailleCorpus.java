package Detection_Resolution_Ellipse;

import java.util.ArrayList;
import java.util.List;

import org.jdom2.Element;

import weka.core.DenseInstance;
import weka.core.Instance;

public class TailleCorpus {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*String[] ListTextes= new String[8];
		ListTextes[0]="texteE2SegEtiqAnaphEllip.xml";
		ListTextes[1]="texteE4SegEtiqAnaphEllip.xml";
		ListTextes[2]="texteE6SegEtiqAnaphEllip.xml";
		ListTextes[3]="texteM1_1SegEtiqAnaphEllip.xml";
		ListTextes[4]="texteM1_2SegEtiqAnaphEllip.xml";
		ListTextes[5]="texteM2SegEtiqAnaphEllip.xml";
		ListTextes[6]="texteM3SegEtiqAnaphEllip.xml";
		ListTextes[7]="texteM4SegEtiqAnaphEllip.xml";
		TailleCopusEllip(ListTextes);*/
		
		/*String[] ListTextes= new String[5];
		ListTextes[0]="fichierResultat1.xml";
		ListTextes[1]="fichierResultat2.xml";
		ListTextes[2]="fichierResultat3.xml";
		ListTextes[3]="fichierResultat4.xml";
		ListTextes[4]="fichierResultat5.xml";
		TailleCopusEllip(ListTextes);*/
		
		String[] ListTextes= new String[1];
		ListTextes[0]="Corpus1DECEtiqEllip.xml";
		TailleCopusEllip(ListTextes);
	}
	public static void TailleCopusEllip(String[] ListTextes){
		String texte=new String();	   
	    
	    String type_verb=new String();
	    Phrase ph = new Phrase();
	    Mot m=new Mot();
	    List mots=new ArrayList<Mot>();
	    int nbr_inst_elliptique;
	    int nbr_inst_non_elliptique;
	    List<String> ListMotsPreEllipse=new ArrayList<String>();
	    int nbr_mots=0;
		for(int t=0;t<ListTextes.length;t++){
	    	nbr_inst_elliptique=0;
	    	nbr_inst_non_elliptique=0;
	    	nbr_mots=0;
	    	texte=ListTextes[t];
	    	System.out.println("+++++++++++++++++++++++++++++++++++"+texte);
	    	//String texteDonne="texte"+Integer.toString(t);
	    	ListMotsPreEllipse=new ArrayList<String>();
	    	//String [] ListMotsComp=new String[100];
	    	//ListElementMot=new ArrayList<Mot>();
		 	Texte txt = new Texte();
			  txt.nomfichier=texte;
			  List parags = txt.ExtractParagraphe();
			  for(int p=0;p<parags.size();p++){
				  System.out.println("nbr parags:"+parags.size());
				  Paragraphe parag=new Paragraphe();
				  parag.paragraphe=(Element)parags.get(p);
				  List phs=parag.ExtrairePhrases();
				  System.out.println("nbr phrase:"+phs.size());
				  //String clas = new String();
				  for(int i=0;i<phs.size();i++){
				    //ph = new Phrase();
				    ph.phrase=(Element)phs.get(i);
				    System.out.println(ph.TextePhrase());
				    //phrase_text=ph.TextePhrase();
				    mots=ph.ExtraireMots();
				    ListMotsPreEllipse=MethodesDivers.ExtraireMotsPredEllipse(ph);
				    //Afficher_Liste(ListMotsPreEllipse);
				    String[] dataWord =ph.TextePhrase().split(" ");
				    //cas particulier d'étiquetage de textes
				    if(mots.size()==0){
				    	mots=ph.ExtraireMots2();
				    }
				    //*************************				   
					
				    System.out.println("taille phrase:"+mots.size());
				
				    System.out.println(ph.TextePhrase());
			    	//ListElementMot=new ArrayList<Mot>();
				    for(int j=0;j<mots.size();j++){
				    	m=new Mot();
						m.mot=(Element)mots.get(j);
						nbr_mots++;
						type_verb=MethodesDivers.TypeVerbe(m.ExtraireVGRad());
						if(!MethodesDivers.TypeVerbe(m.ExtraireVGRad()).equals("")){
							Instance inst1 = new DenseInstance(26);
							//System.out.println("mot courant:"+m.ExtraireValeur()+" vg courant:"+m.ExtraireVGRad());
														
							if(MethodesDivers.AppartientListe(ListMotsPreEllipse,m.ExtraireValeur())){
								System.out.println("nouveau instance ellipse sujet");
								nbr_inst_elliptique+=1;
							}
							else{
								nbr_inst_non_elliptique+=1;
							}
						}
				    }
				  }
			  }
			  System.out.println("++++++++++++++nombre mots:"+nbr_mots);
			  System.out.println("++++++++++++++nombre inst ellip:"+nbr_inst_elliptique);
			  System.out.println("++++++++++++++nombre inst non ellip:"+nbr_inst_non_elliptique);
		}
	}
}
