package Detection_Resolution_Ellipse;

import java.util.ArrayList;
import java.util.List;

import org.jdom2.Element;

public class Paragraphe {
	static public Element paragraphe = new Element("Paragraphe");
	  public Paragraphe() {
	  }

	
	public static String NumeroParagraphe(){
	  String num = new String();
	  num=paragraphe.getAttributeValue("numero");
	  return num;
	}
	public static List ExtrairePhrases(){
		  List phrases = new ArrayList();
		  phrases = paragraphe.getChildren("Phrase");
		  return phrases;

		}
	
}
