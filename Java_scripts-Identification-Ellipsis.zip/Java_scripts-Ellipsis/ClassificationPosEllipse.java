package Detection_Resolution_Ellipse;

//package Main;


import weka.classifiers.AbstractClassifier;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import libsvm.*;

import java.io.*;
import java.util.*;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;
import org.xml.sax.SAXException;



import weka.core.*;
import weka.classifiers.Evaluation;
import weka.classifiers.bayes.NaiveBayes;
import weka.classifiers.evaluation.Prediction;
import weka.classifiers.functions.LibSVM;
import weka.classifiers.functions.Logistic;
import weka.classifiers.lazy.IBk;
import weka.classifiers.meta.FilteredClassifier;
import weka.classifiers.trees.J48;
import weka.core.Instances;
import weka.core.converters.ArffSaver;
import weka.core.converters.ConverterUtils.DataSource;
import weka.filters.supervised.instance.SMOTE;



public class ClassificationPosEllipse {
	static Instances FileUnlabelTemp = null;
    static Instance inst1 = new DenseInstance(10);
  public ClassificationPosEllipse() {
  }

  public static void main(String[] argv) throws Exception
  {
	  
	  //String FileLabled="LabledCorpora.arff";
	  //String FileUnlabled="UnlabledCorpora.arff";
	  //String FileTemp="FileUnlabelTemp.arff";
	  
	  /*String FileTrainNonEtiq="TestBigData.arff";
	  String FileTrainNonEtiqSmote="TestBigDataSmote4200.arff";
	  String FileTrainEtiq="TrainDataNoyau.arff";
	  String FileTest="TestCorpus.arff";*/
	  //String FileTest="TestBigDataAncien.arff";
	  //String FileTrainNonEtiq="fichResultatUnlabel.arff";
	  //String FileTrainNonEtiqSmote="fichResultatUnlabelSmote120.arff";
	  //String FileTrainNonEtiqSmote="fichResultatUnlabel_2Smote110.arff";
	  //String FileTrainNonEtiqSmote="fichResultatUnlabelSmote74.arff";
	  //String FileTrainNonEtiqSmote="fichResultatUnlabel_Smote300_Smote130.arff";
	  
	  //String FileTrainNonEtiqSmote="fichResultatUnlabel_Smote75.arff";
	  //String FileTrainEtiq="fichResultatTrain.arff";
	  //String FileTest="fichResultatTest.arff";
	  
	  //11/08/2020
	  String FileTrainNonEtiqSmote="CorpusTrainNonEtiq_100Smote.arff";
	  String FileTrainEtiq="CorpusTrainEtiq.arff";
	  String FileTest="CorpusTest.arff";
	  //String FileTest="CorpusTest_Duplic.arff";
	  
	  //ConstructionCorpusEtiq(FileTrainEtiq);
	  //ConstructionCorpusNonEtiq(FileTrainNonEtiq);
	  				//DuplicationInstNonRef(FileTrainNonEtiq);
	  //ConstructionARFF.ConstructionCorpusTest(FileTest);
	  
	  EcrireFichierTexte.CreateWriteTxtFile("ListeProbabilites.txt", "");
	  EcrireFichierTexte.CreateWriteTxtFile("EvaluationTest.txt", "");
	  
	  //ClassificationFinal1(FileTrainEtiq,FileTrainNonEtiq);
	  
	  //Clssification self training SVM
	  ClassificationFinalSVM(FileTrainEtiq,FileTrainNonEtiqSmote,FileTest);	  					
	  EvaluateCrossValidationTrainingSVM(FileTrainEtiq);
	  EvaluateTestOnTrainingSVM(FileTrainEtiq,FileTest);
	  
	  //Classification autres classifieurs
	  //int num_classifier=4;
	  //ClassificationFinalOtherClassifier(FileTrainEtiq,FileTrainNonEtiqSmote,FileTest,num_classifier);
	  //EvaluateCrossValidationTrainingClassifier(FileTrainEtiq,num_classifier);
	  //EvaluateTestOnTrainingClassifier(FileTrainEtiq,FileTest,num_classifier);
	  
  }
	   
  public static void ClassificationFinalSVM(String FileTrain,String FileTrainNonEtiqSmote, String FileTest) throws FileNotFoundException, IOException{
	  int iteration=1;
     
    //String TextesNonEtiq=LectureFichierTexte.LectureParametres("Parametres0.txt").get(6);
    //String[] dataNonEtiq = TextesNonEtiq.split(",");
    
       
    //Classification selftrain SVM
	 
	//Self training Classifieur SVM
	String FileArff=ClassificationSelfTrainSvm.SelfTrainingSVM(FileTrain, FileTrainNonEtiqSmote, iteration,FileTest);	
		
	System.out.println("classification termin�! fichier final "+FileArff);
	//System.out.println(MethodeUtile.currentTime());
  }
  
  public static void ClassificationFinalOtherClassifier(String FileTrain,String FileTrainNonEtiqSmote, String FileTest, int num_classifier) throws FileNotFoundException, IOException{
	  int iteration=1;
     
    //String TextesNonEtiq=LectureFichierTexte.LectureParametres("Parametres0.txt").get(6);
    //String[] dataNonEtiq = TextesNonEtiq.split(",");       
    
	//tester les autres classifieurs!
	//Self training Autres classifieurs
	
	String FileArff=ClassificationSelfTrainOtherClassifier_final.SelfTrainingVariousClassifier(FileTrain, FileTrainNonEtiqSmote,FileTest, iteration,num_classifier);
	
	System.out.println("classification termin�! fichier final "+FileArff);
	//System.out.println(MethodeUtile.currentTime());
  }
  public static void EvaluateTestOnTrainingClassifier(String FileLabled,String FileTestCorpus, int num_classifier){
	  try{
	  
	  BufferedReader BrTain=new BufferedReader(new FileReader(FileLabled));  
	  Instances train = new Instances(BrTain);	//Donn�es �tiquet�es
      System.out.println("instance file label "+FileLabled+":"+train.numInstances());
      
      BufferedReader BrUnlabeled=new BufferedReader(new FileReader(FileTestCorpus));  
      Instances test = new Instances(BrUnlabeled);	//Donn�es non �tiquet�es
      System.out.println("instance file unlabel "+FileTestCorpus+":"+test.numInstances());
      
      train.setClassIndex(train.numAttributes()-1);
      test.setClassIndex(test.numAttributes()-1);
      /*
       * Construction du classifieur svm
       */
 
      WekaPackageManager.loadPackages( false, true, false );
      Classifier classifier=null;
      switch(num_classifier) {
        case 1:
        	IBk knn = new IBk();
        	String[] options = new String[2];
        	options[0]= "-E";
        	options[1]= "-I";
        	knn.setOptions(options);
        	knn.setKNN(1);
        	knn.setCrossValidate(true);
        	classifier=knn;
        case 2:
        	NaiveBayes NB= new NaiveBayes();		        	
        	NB.setOptions(weka.core.Utils.splitOptions(""));
        	//NB.setCrossValidate(true);
        	classifier=NB;
        case 3:
        	Logistic lg = new Logistic();
        	lg.setOptions(Utils.splitOptions("-R 1.0E-8 -M -1"));
        	classifier=lg;
        case 4:
        	J48 j48 = new J48();
        	classifier=j48;
    }
      
      classifier.buildClassifier(train);System.out.println("entrainement du classifieur choisi");
            
	  Evaluation evaltest = new Evaluation(train);
      evaltest.evaluateModel(classifier,  test);
      IncorrectInstances(evaltest,test);
      
      System.out.println("evaluation test set");
      System.out.println(evaltest);
      System.out.println(evaltest.toSummaryString());
      System.out.println(evaltest.toClassDetailsString());
      System.out.println(evaltest.toMatrixString());
      double WeightPrecisionTest=evaltest.weightedPrecision();
      System.out.println("Precision classification corpus de test:"+WeightPrecisionTest);
 	}
 	catch(Exception e){System.out.println(e);}
  }
  public static void EvaluateCrossValidationTrainingClassifier(String FileLabled,int num_classifier){
	  try{
	  
		  Random rand = new Random(1); // using seed = 1
	      int folds = 10;
		  BufferedReader BrTain=new BufferedReader(new FileReader(FileLabled));  
		  Instances train = new Instances(BrTain);	//Donn�es �tiquet�es
	      System.out.println("instance file label "+FileLabled+":"+train.numInstances());
	      
	           
	      train.setClassIndex(train.numAttributes()-1);
	     
	      /*
	       * Construction du classifieur svm
	       */
	 
	      WekaPackageManager.loadPackages( false, true, false );
	      Classifier classifier=null;
	      switch(num_classifier) {
	        case 1:
	        	IBk knn = new IBk();
	        	String[] options = new String[2];
	        	options[0]= "-E";
	        	options[1]= "-I";
	        	knn.setOptions(options);
	        	knn.setKNN(1);
	        	knn.setCrossValidate(true);
	        	classifier=knn;
	        case 2:
	        	NaiveBayes NB= new NaiveBayes();		        	
	        	NB.setOptions(weka.core.Utils.splitOptions(""));
	        	//NB.setCrossValidate(true);
	        	classifier=NB;
	        case 3:
	        	Logistic lg = new Logistic();
	        	lg.setOptions(Utils.splitOptions("-R 1.0E-8 -M -1"));
	        	classifier=lg;
	        case 4:
	        	J48 j48 = new J48();
	        	classifier=j48;
	    }
	      
	      classifier.buildClassifier(train);System.out.println("entrainement du classifieur choisi");
	      
	      Evaluation eval = new Evaluation(train);
	      eval.crossValidateModel(classifier, train, folds, rand);
	      
	      System.out.println("evaluation Cross validation");
	      System.out.println(eval);
	      System.out.println(eval.toSummaryString());
	      System.out.println(eval.toClassDetailsString());
	      System.out.println(eval.toMatrixString());
	      System.out.println("Precision classification cross validation:"+eval.weightedPrecision());   
	       
 	}
 	catch(Exception e){System.out.println(e);}
  }
  public static void EvaluateTestOnTrainingSVM(String FileLabled,String FileTestCorpus){
	  try{
	  
	  BufferedReader BrTain=new BufferedReader(new FileReader(FileLabled));  
	  Instances train = new Instances(BrTain);	//Donn�es �tiquet�es
      System.out.println("instance file label "+FileLabled+":"+train.numInstances());
      
      BufferedReader BrUnlabeled=new BufferedReader(new FileReader(FileTestCorpus));  
      Instances test = new Instances(BrUnlabeled);	//Donn�es non �tiquet�es
      System.out.println("instance file unlabel "+FileTestCorpus+":"+test.numInstances());
      
      train.setClassIndex(train.numAttributes()-1);
      test.setClassIndex(test.numAttributes()-1);
      /*
       * Construction du classifieur svm
       */
 
      WekaPackageManager.loadPackages( false, true, false );
      AbstractClassifier classifier = ( AbstractClassifier ) Class.forName(
                  "weka.classifiers.functions.LibSVM" ).newInstance();
      System.out.println("construction du classifieur svm");
      LibSVM svm = (LibSVM) classifier;
      System.out.println("Setprobability");
      svm.setProbabilityEstimates(true);
      System.out.println("construction du classifieur svm termin�");
      
      //If you prefer to give options set the options like this

      //String options = ("-S 0 -K 0 -D 3 -G 0.0 -R 0.0 -N 0.5 -M 40.0 -C 1.0 -E 0.001 -P 0.1 -b 1" );
      String options = ("-S 0 -K 1 -D 3 -G 0.5 -M 40.0 -C 1.0 -E 0.001 -W 1 -B 1");	//Modifier le 12/08/2020
      String[] optionsArray = options.split(" ");
          svm.setOptions( optionsArray );  
      //classifier.setOptions( optionsArray );
      System.out.println("Set options");
      svm.buildClassifier(train);
      //classifier.buildClassifier(train);
      System.out.println("entrainement du classifieur svm entrain� avec self training");
      
	  Evaluation evaltest = new Evaluation(train);
      //evaltest.evaluateModel(classifier,  test);
      evaltest.evaluateModel(svm,  test);	//11/08/2020
      IncorrectInstances(evaltest,test);
      
      System.out.println("evaluation test set");
      System.out.println(evaltest);
      System.out.println(evaltest.toSummaryString());
      System.out.println(evaltest.toClassDetailsString());
      System.out.println(evaltest.toMatrixString());
      double WeightPrecisionTest=evaltest.weightedPrecision();
      System.out.println("Precision classification corpus de test:"+WeightPrecisionTest);
 	}
 	catch(Exception e){System.out.println(e);}
  }
  
  public static void EvaluateCrossValidationTrainingSVM(String FileLabled){
	  try{
	  
		  Random rand = new Random(1); // using seed = 1
	      int folds = 10;
		  BufferedReader BrTain=new BufferedReader(new FileReader(FileLabled));  
		  Instances train = new Instances(BrTain);	//Donn�es �tiquet�es
	      System.out.println("instance file label "+FileLabled+":"+train.numInstances());
	      
	           
	      train.setClassIndex(train.numAttributes()-1);
	     
	      /*
	       * Construction du classifieur svm
	       */
	 
	      WekaPackageManager.loadPackages( false, true, false );
	      AbstractClassifier classifier = ( AbstractClassifier ) Class.forName(
	                  "weka.classifiers.functions.LibSVM" ).newInstance();
	      System.out.println("construction du classifieur svm");
	      LibSVM svm = (LibSVM) classifier;
	      System.out.println("Setprobability");
	      svm.setProbabilityEstimates(true);
	      System.out.println("construction du classifieur svm termin�");
	      
	      //If you prefer to give options set the options like this
	
	      //String options = ("-S 0 -K 0 -D 3 -G 0.0 -R 0.0 -N 0.5 -M 40.0 -C 1.0 -E 0.001 -P 0.1 -b 1" );
	      String options = ("-S 0 -K 1 -D 3 -G 0.5 -M 40.0 -C 1.0 -E 0.001 -W 1 -B 1");
	      String[] optionsArray = options.split(" ");
          svm.setOptions( optionsArray );  
	      //classifier.setOptions( optionsArray );
	      System.out.println("Set options");
	      svm.buildClassifier(train);
	      //classifier.buildClassifier(train);
	      System.out.println("entrainement du classifieur svm entrain� avec self training");
	      
	      Evaluation eval = new Evaluation(train);
	      eval.crossValidateModel(svm, train, folds, rand);
	      
	      System.out.println("evaluation Cross validation");
	      System.out.println(eval);
	      System.out.println(eval.toSummaryString());
	      System.out.println(eval.toClassDetailsString());
	      System.out.println(eval.toMatrixString());
	      System.out.println("Precision classification cross validation:"+eval.weightedPrecision());   
	       
 	}
 	catch(Exception e){System.out.println(e);}
  }
  
  public static void IncorrectInstances(Evaluation evaltest,Instances testData) throws FileNotFoundException, IOException{
	  String NameFile="IncorrectInstances.txt";
	  EcrireFichierTexte.CreateWriteTxtFile(NameFile, "");
  ArrayList<Prediction> predictions = evaltest.predictions();
  for (int i = 0, testDataSize = testData.size(); i < testDataSize; i++) {
          Instance instance = testData.get(i);
          Prediction prediction = predictions.get(i);
          
          if (prediction.actual() != prediction.predicted()) {

              System.out.println(instance);
              EcrireFichierTexte.WriteToTxtFile(NameFile, i+" "+instance.toString());
              //double[] predictionDistribution=svm.distributionForInstance(Unlabel.instance(i));
          }

      }
  }
  
  public static void DisplayArray(String[] data){
		for(int i=0;i<data.length;i++){
			System.out.println(data[i]);
		}
	}
  
  }