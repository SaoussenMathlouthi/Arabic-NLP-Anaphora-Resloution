package Detection_Resolution_Ellipse;

public class CombinaisonCritere {
	
		 private String CombinaisonCritereFinal;
		 private double [] ProbabiliteFinal;
		 private double FonctionValeur;
		 
		public String getCombinaisonCritereFinal() {
			return CombinaisonCritereFinal;
		}
		public void setCombinaisonCritereFinal(String combinaisonCritereFinal) {
			CombinaisonCritereFinal = combinaisonCritereFinal;
		}
		public double[] getProbabiliteFinal() {
			return ProbabiliteFinal;
		}
		public void setProbabiliteFinal(double[] probabiliteFinal) {
			ProbabiliteFinal = probabiliteFinal;
		}
		public double getFonctionValeur() {
			return FonctionValeur;
		}
		public void setFonctionValeur(double fonctionValeur) {
			FonctionValeur = fonctionValeur;
		}	
		 
}
