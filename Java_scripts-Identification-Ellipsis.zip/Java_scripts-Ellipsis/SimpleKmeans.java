package Detection_Resolution_Ellipse;

//package Main;

import weka.classifiers.meta.FilteredClassifier;
import weka.classifiers.AbstractClassifier;
import weka.classifiers.Evaluation;
import libsvm.*;
import weka.classifiers.trees.J48;
import weka.classifiers.trees.DecisionStump;
//import weka.classifiers.trees.Id3;
//import weka.classifiers.trees.Id3;
import weka.classifiers.bayes.NaiveBayes;
import weka.filters.unsupervised.attribute.Remove;
import java.io.*;
import java.util.*;
import weka.core.*;
import weka.classifiers.functions.SMO;
//import wlsvm.WLSVM;
//import org.jdom.*;
//import libsvm.*;
//import weka.classifiers.bayes.AODE;
import weka.classifiers.bayes.BayesNet;
//import weka.classifiers.bayes.ComplementNaiveBayes;
import weka.classifiers.bayes.NaiveBayesMultinomial;
//import weka.classifiers.bayes.NaiveBayesSimple;
import weka.classifiers.bayes.NaiveBayesUpdateable;
import weka.classifiers.functions.Logistic;
import weka.classifiers.functions.LibSVM;
//import weka.classifiers.functions.LeastMedSq;
import weka.classifiers.functions.SMO;
import weka.classifiers.functions.VotedPerceptron;
//import weka.classifiers.functions.Winnow;
//import weka.classifiers.lazy.IB1;
import weka.classifiers.lazy.IBk;
import weka.classifiers.lazy.KStar;
//import weka.classifiers.lazy.LBR;
import weka.classifiers.lazy.LWL;
//import weka.classifiers.misc.HyperPipes;
//import weka.classifiers.misc.VFI;
import weka.classifiers.rules.OneR;
import weka.classifiers.rules.M5Rules;
import weka.classifiers.rules.DecisionTable;
import weka.classifiers.rules.ZeroR;
//import weka.classifiers.trees.ADTree;
import weka.classifiers.trees.DecisionStump;
import weka.classifiers.trees.J48;
import weka.classifiers.trees.LMT;
import weka.classifiers.trees.M5P;
import weka.classifiers.trees.RandomTree;
//import weka.classifiers.functions.RBFNetwork;
import weka.classifiers.functions.MultilayerPerceptron;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
 
import weka.clusterers.SimpleKMeans;
import weka.core.Instances;


public class SimpleKmeans {
  public SimpleKmeans() {
  }

   
  	public static BufferedReader readDataFile(String filename) {
  		BufferedReader inputReader = null;
   
  		try {
  			inputReader = new BufferedReader(new FileReader(filename));
  		} catch (FileNotFoundException ex) {
  			System.err.println("File not found: " + filename);
  		}
   
  		return inputReader;
  	}
   
  	public static void main(String[] args) throws Exception {
  		String file="";
  		Instances instances=CalculCentroid(file);
  		for ( int j = 0; j < instances.numInstances(); j++ ) {
  		    // for each cluster center
  		    Instance inst = instances.instance( j );
  		    // as you mentioned, you only had 1 attribute
  		    // but you can iterate through the different attributes
  		    for(int k=0; k<inst.numAttributes();k++){
	  		    double value = inst.value( k );
	  		    System.out.println( "Value for centroid " + j + ": "+"de l'attribut:"+k+"=" + value );
  		    }
  		}
  	}
  	
  	public static Instances CalculCentroid(String File)throws Exception{
  		//Instance instCentroid = new DenseInstance(33);
  		SimpleKMeans kmeans = new SimpleKMeans();
  	   
  		kmeans.setSeed(10);
   
  		//important parameter to set: preserver order, number of cluster.
  		kmeans.setPreserveInstancesOrder(true);
  		kmeans.setNumClusters(2);
   
  		BufferedReader datafile = readDataFile(File); 
  		Instances data = new Instances(datafile);
   
   
  		kmeans.buildClusterer(data);
   
  		// This array returns the cluster number (starting with 0) for each instance
  		// The array has as many elements as the number of instances
  		int[] assignments = kmeans.getAssignments();
   
  		int i=0;
  		for(int clusterNum : assignments) {
  		    //System.out.printf("Instance %d -> Cluster %d \n", i, clusterNum);
  		    i++;
  		}
  		//Instances instances =
  		
  		return  kmeans.getClusterCentroids();
  		
  		//return instCentroid;
  		
  	}
  }