package Detection_Resolution_Ellipse;


import java.util.*;

import org.jdom2.*;


import java.util.Iterator;

/**
 * <p>Titre : </p>
 * <p>Description : </p>
 * <p>Copyright : Copyright (c) 2010</p>
 * <p>Soci�t� : </p>
 * @author non attribuable
 * @version 1.0
 */

public class Mot {
	static public  Element mot = new Element("Mot");
  public Mot() {
  }
  public static String ExtraireValeur(){
    String val = new String();
    val = mot.getAttributeValue("valeur");
    return val;
  }
 

  public static String ExtraireNum(){
    String num = new String();
    num = mot.getAttributeValue("numero");
    //System.out.println("numero mot "+num);
    if(num==null)
    	num=mot.getAttributeValue("n");
    return num;
  }
  
  public static String ExtraireDecoupRacine(){
	  String racine=new String();
	  String decoup=ExtraireDecoup();
	  racine=decoup.substring(decoup.indexOf("/")+1,decoup.length());
	  racine=racine.substring(0, racine.indexOf("/"));
	  return racine;
  }
  public static String ExtraireDecoup(){
    String decoup = new String();
    Element decoupage = (Element) mot.getChild("Decoup");
    decoup = decoupage.getAttributeValue("valeur");
    return decoup;
  }
  public static List ExtraireListCandidats(){
	 List ListCand=new ArrayList();
	 if(mot.getChildren().size()>1){
		 if(mot.getChild("ListCandidats").getChildren("Candidat").size()>0)
			 ListCand=mot.getChild("ListCandidats").getChildren("Candidat");
		 else
			 System.out.println("List cand vide "+mot.getAttributeValue("valeur"));
	 }
	  return ListCand;
  }
  public static String ExtraireRefAnaph(){
		 String Ref=new String();
		 if(mot.getChildren().size()>1){
			 if(mot.getChild("ListCandidats").hasAttributes())
				 Ref=mot.getChild("ListCandidats").getAttributeValue("referentiel");
			 else if(mot.getChild("ListCandidats").getChildren().size()>0)
				 Ref="oui";
			 else
				 Ref="inconnu";
		 }
		 else Ref="";
		  return Ref;
	  }
  public static String ExtraireValanaphore(){
	    String valanaphore= new String();
	    Element anaphore = (Element) mot.getChild("Decoup").getChild("Enc");
	    if(anaphore.hasAttributes()){
	    
	    	valanaphore = "oui";
	    }
	    else valanaphore="";
	
	    return valanaphore;
	  }
  public static String enclitique(){
	    String valanaphore= new String();
	    Element anaphore = (Element) mot.getChild("Decoup").getChild("Enc");
	    
	    if(anaphore.hasAttributes()){
	    	 valanaphore= anaphore.getAttributeValue("valeurE");
	    	
	    }
	    else valanaphore="";
	    
	    return valanaphore;
	  }
  public static String ExtraireValanaphore2(){
	    String valanaphore= new String();
	    Element anaphore = (Element) mot.getChild("Decoup").getChild("Poss").getChild("Enc");
	    if(anaphore.hasAttributes()){
	    
	    	valanaphore = "oui";
	    }
	    else valanaphore="";
	
	    return valanaphore;
	  }
  
  public static String ExtraireValanaphore1(){
	  String anaphore= new String();
	  String vgrad="";
	  String test = new String();
	  Element Lemme = (Element) mot.getChild("Decoup").getChild("Rad").getChild(
	          "Lem");
	  if (Lemme.hasAttributes())
	  {
		 Element vgRad = Lemme.getChild("VGRad");
		 vgrad = vgRad.getAttributeValue("val");
		 test= Lemme.getAttributeValue("valeur");
		 if (test.equals("lLAViY") || test.equals("lLATiY")||test.equals("lLAViYNa")||test.equals("lLAlTiY")
				 ||test.equals("lLAValNi")||test.equals("lLATalNi")||vgrad.equals("54")||vgrad.equals("55")||vgrad.equals("56")
				 ||vgrad.equals("57"))
			anaphore="oui"; 
		 else anaphore="";
	  }else anaphore="";
	  return anaphore;
	  }
  public static String ExtraireValanaphore3(){
	  String anaphore= new String();
	  String vgrad="";
	  String test = new String();
	  Element Lemme = (Element) mot.getChild("Decoup").getChild("Poss").getChild("Radicaux").getChild("Rad").getChild(
	          "Lem");
	  if (Lemme.hasAttributes())
	  {
		 Element vgRad = Lemme.getChild("VGRad");
		 vgrad = vgRad.getAttributeValue("val");
		 test= Lemme.getAttributeValue("valeur");
		 if (test.equals("lLAViY") || test.equals("lLATiY")||test.equals("lLAViYNa")||test.equals("lLAlTiY")
				 ||test.equals("lLAValNi")||test.equals("lLATalNi")||vgrad.equals("54")||vgrad.equals("55")||vgrad.equals("56")
				 ||vgrad.equals("57"))
			anaphore="oui"; 
		 else anaphore="";
	  }else anaphore="";
	  return anaphore;
	  }
  
  
  public static String ExtraireValantecdent(){
	    String antecedent= new String();
	    Element anaphore = (Element) mot.getChild("Decoup").getChild("Enc").getChild("Anaphore");
	    if(anaphore.hasAttributes()){
	    	antecedent = anaphore.getAttributeValue("antec"); 
	    }
	    else antecedent="";
	    return antecedent;
	  }
  
  public static String ExtraireValantecdent1(){
	    String antecedent1= new String();
	    Element anaphore = (Element) mot.getChild("Anaphore");
	    if(anaphore.hasAttributes()){
	    	antecedent1 = anaphore.getAttributeValue("antec"); 
	    }
	    else antecedent1="";
	    return antecedent1;
	  }

  public static String ExtraireValProc(){
    String valproc = new String();
    Element proc = (Element) mot.getChild("Decoup").getChild("Proc");
    if(proc.hasAttributes()){
      valproc = proc.getAttributeValue("valeurP");
    }
    else valproc="";
    return valproc;
  }
  public static String ExtraireValProc2(){
	    String valproc = new String();
	    Element proc = (Element) mot.getChild("Decoup").getChild("Poss").getChild("Proc");
	    if(proc.hasAttributes()){
	      valproc = proc.getAttributeValue("VP");
	    }
	    else valproc="";
	    return valproc;
	  }

  public static String ExtraireVGProc(){
    String vgproc = new String();
    Element proc = (Element) mot.getChild("Decoup").getChild("Proc");
    if(proc.hasAttributes())
      vgproc=proc.getChildText("VgProc");
    if(vgproc==null)
    	vgproc=proc.getChildText("VgP");
    else  vgproc = "";
    return vgproc;
  }
  public static String ExtraireVGProc2(){
	    String vgproc = new String();
	    Element proc = (Element) mot.getChild("Decoup").getChild("Poss").getChild("Proc");
	    if(proc.hasAttributes())
	      vgproc=proc.getChildText("VgProc");
	      if(vgproc==null)
	    	  vgproc=proc.getChildText("VgP");
	    else  vgproc = "";
	    return vgproc;
	  }
  public static String ExtraireValEnc(){
    String valenc = new String();
    Element enc = (Element) mot.getChild("Decoup").getChild("Enc");
    if(enc.hasAttributes())
      valenc = enc.getAttributeValue("valeurE");
    else
      valenc="";
    return valenc;
  }
  public static String ExtraireValEnc2(){
	    String valenc = new String();
	    Element enc = (Element) mot.getChild("Decoup").getChild("Poss").getChild("Enc");
	    if(enc.hasAttributes())
	      valenc = enc.getAttributeValue("valeurE");
	    else
	      valenc="";
	    return valenc;
	  }
  public static String ExtraireVGEnc(){
    String vgenc = new String();
    Element enc = (Element) mot.getChild("Decoup").getChild("Enc");
    if(!enc.hasAttributes())
      vgenc="";
    else
      vgenc = enc.getChild("VgEnc").getTextTrim();
    return vgenc;
  }
  public static String ExtraireVGEnc2(){
    String vgenc = new String();
    Element enc = (Element) mot.getChild("Decoup").getChild("Poss").getChild("Enc");
    if(!enc.hasAttributes())
      vgenc="";
    else
      vgenc = enc.getChild("VgE").getTextTrim();
    return vgenc;
  }
  
  public static String ExtraireRad(){
    String rad = new String();
    Element radical = (Element) mot.getChild("Decoup").getChild("Rad");
    if(radical.hasAttributes()){
      rad = radical.getAttributeValue("val");
      if(rad==null)
    	  rad=radical.getAttributeValue("VR");
    }
    else rad="";
    if(rad.contains(";"))
    	rad=rad.substring(0, rad.indexOf(";"));
    return rad;
  }
  public static String ExtraireRad2(){
	    String rad = new String();
	    Element radical = (Element) mot.getChild("Decoup").getChild("Poss").getChild("Radicaux");
	    if(radical.getChildren().size()>0){
	      rad = radical.getChild("Rad").getAttributeValue("val");
	      if(rad==null)
	    	  rad=radical.getChild("Rad").getAttributeValue("VR");
	    }
	    else rad="";
	    return rad;
	  }
  public static String ExtraireRadE(){
	    String rad = new String();
	    Element radical = (Element) mot.getChild("Decoup").getChild("Rad").getChild("RadE");
	    if(!radical.getTextTrim().equals(""))
	      rad = radical.getTextTrim();
	    else rad="";
	    return rad;
	  }
  public static String ExtraireLem(){
    String lem = new String();
    Element radical = (Element) mot.getChild("Decoup").getChild("Rad");
    if(radical.hasAttributes()){
      Element Lemme = (Element) mot.getChild("Decoup").getChild("Rad").getChild(
          "Lem");
      lem = Lemme.getAttributeValue("valeur");
    }
    else lem="";
    return lem;
  }
  public static String ExtraireLem2(){
    String lem = new String();
    Element radical = (Element) mot.getChild("Decoup").getChild("Poss").getChild("Radicaux");
    if((radical.getChildren().size())>0){
      Element Lemme = (Element) radical.getChild("Rad").getChild("Lem");
      lem = Lemme.getAttributeValue("valeur");
    }
    else lem="";
    return lem;
	 }
  
  public static String ExtraireVGRad(){
    String vgrad = new String();
    Element radical = (Element) mot.getChild("Decoup").getChild("Rad");
    if(radical.hasAttributes()){
      Element vgRad = (Element) mot.getChild("Decoup").getChild("Rad").getChild(
          "Lem").getChild("VGRad");
      vgrad = vgRad.getAttributeValue("val");
    }
    else vgrad="";
    return vgrad;
  }
  public static String ExtraireVGRad2(){
	    String vgrad = new String();
	    Element radical = (Element) mot.getChild("Decoup").getChild("Poss").getChild("Radicaux");
	    if(radical.getChildren().size()>0){
	      Element vgRad = (Element) radical.getChild("Rad").getChild("Lem").getChild("VGRad");
	      vgrad = vgRad.getAttributeValue("val");
	    }
	    else vgrad="";
	    return vgrad;
	  }

  public static String ExtraireGenre(){
    String genre = new String();
    Element radical = (Element) mot.getChild("Decoup").getChild("Rad");
    if(radical.hasAttributes()){
      Element gen = (Element) mot.getChild("Decoup").getChild("Rad").getChild(
          "Lem").getChild("VGRad").getChild("Genr");
          if(!gen.getTextTrim().equals(""))
            genre = gen.getTextTrim();
          else genre="";
    }
    else genre="";
    return genre;
  }
  public static String ExtraireGenre2(){
	    String genre = new String();
	    Element radical = (Element) mot.getChild("Decoup").getChild("Poss").getChild("Radicaux");
	    if((radical.getChildren().size()>0)){
	      Element gen = (Element) radical.getChild("Rad").getChild("Lem").getChild("VGRad").getChild("Genr");
	          if(!gen.getTextTrim().equals(""))
	            genre = gen.getTextTrim();
	          else genre="";
	    }
	    else genre="";
	    return genre;
	  }
  
  public static String ExtraireGenreanaph(){
	    String genre = new String();
	    Element Enc = (Element) mot.getChild("Decoup").getChild("Enc");
	    if(Enc.hasAttributes() && Enc.getChildren().size()>1){
	      Element gen = (Element) mot.getChild("Decoup").getChild("Enc").getChild(
	          "Gen");
	      if (gen==null){
	    	  	gen = (Element) mot.getChild("Decoup").getChild("Enc").getChild(
		         "Genr");
	      }
	          if(!gen.getTextTrim().equals(""))
	            genre = gen.getTextTrim();
	          else genre=""; 
	    }
	    else genre="";
	    return genre;
	  }
  public static String ExtraireGenreanaph2(){
	    String genre = new String();
	    Element Enc = (Element) mot.getChild("Decoup").getChild("Poss").getChild("Enc");
	    if(Enc.hasAttributes() && Enc.getChildren().size()>1){
	      Element gen = (Element) mot.getChild("Decoup").getChild("Poss").getChild("Enc").getChild(
	          "Gen");
	      if (gen==null){
	    	  	gen = (Element) mot.getChild("Decoup").getChild("Poss").getChild("Enc").getChild(
		         "Genr");
	      }
	          if(!gen.getTextTrim().equals(""))
	            genre = gen.getTextTrim();
	          else genre=""; 
	    }
	    else genre="";
	    return genre;
	  }
  public static String ExtraireNbranaph(){
	    String nombre = new String();
	    Element Enc = (Element) mot.getChild("Decoup").getChild("Enc");
	    if(Enc.hasAttributes()&& Enc.getChildren().size()>1){
	      Element nbr = (Element) mot.getChild("Decoup").getChild("Enc").getChild(
	          "Nomb");
	      if (nbr==null){
	    	  	nbr = (Element) mot.getChild("Decoup").getChild("Enc").getChild(
		         "Nombr");
	      }
	          if(!nbr.getTextTrim().equals(""))
	            nombre = nbr.getTextTrim();
	          else nombre="";
	    }
	    else nombre="";
	    return nombre;
	  }
  public static String ExtraireNbranaph2(){
	    String nombre = new String();
	    Element Enc = (Element) mot.getChild("Decoup").getChild("Poss").getChild("Enc");
	    if(Enc.hasAttributes()&& Enc.getChildren().size()>1){
	      Element nbr = (Element) mot.getChild("Decoup").getChild("Poss").getChild("Enc").getChild(
	          "Nomb");
	      if (nbr==null){
	    	  	nbr = (Element) mot.getChild("Decoup").getChild("Poss").getChild("Enc").getChild(
		         "Nombr");
	      }
	          if(!nbr.getTextTrim().equals(""))
	            nombre = nbr.getTextTrim();
	          else nombre="";
	    }
	    else nombre="";
	    return nombre;
	  }

  public static String ExtraireNombre(){
    String nombre = new String();
    Element radical = (Element) mot.getChild("Decoup").getChild("Rad");
    if(radical.hasAttributes()){
      Element nomb = (Element) mot.getChild("Decoup").getChild("Rad").getChild(
          "Lem").getChild("VGRad").getChild("Nombr");
          if(!nomb.getTextTrim().equals(""))
            nombre = nomb.getTextTrim();
          else nombre="";
    }
    else nombre="";
    return nombre;
  }
  public static String ExtraireNombre2(){
	    String nombre = new String();
	    Element radical = (Element) mot.getChild("Decoup").getChild("Poss").getChild("Radicaux");
	    if((radical.getChildren().size()>0)){
	      Element nomb = (Element) radical.getChild("Rad").getChild("Lem").getChild("VGRad").getChild("Nombr");
	          if(!nomb.getTextTrim().equals(""))
	            nombre = nomb.getTextTrim();
	          else nombre="";
	    }
	    else nombre="";
	    return nombre;
	  }
  public static String ExtrairePronom(){
    String pronom = new String();
    Element radical = (Element) mot.getChild("Decoup").getChild("Rad");
    if(radical.hasAttributes()){
      Element pron = (Element) mot.getChild("Decoup").getChild("Rad").getChild(
          "Lem").getChild("VGRad").getChild("Pron");
          if(!pron.getTextTrim().equals(""))
            pronom = pron.getTextTrim();
          else pronom="";
    }
    else pronom="";
    return pronom;
  }

  public static String ExtraireTransitivite(){
    String transt = new String();
    Element radical = (Element) mot.getChild("Decoup").getChild("Rad");
    if(radical.hasAttributes()){
      Element trans = (Element) mot.getChild("Decoup").getChild("Rad").getChild(
          "Lem").getChild("VGRad").getChild("Trans");
          if(!trans.getTextTrim().equals(""))
            transt = trans.getTextTrim();
          else transt="";
    }
    else transt="";
    return transt;
  }
  public static String ExtraireMeilleurCombin(){
	  String Combin=new String();
	  if(mot.getChildren().size()>1){
			 Combin=mot.getChild("ListCandidats").getAttributeValue("MeilleurCrit");
	  }
	  return Combin;
  }
  public static String ExtraireCas(String valcatG) {
    String cas = new String();
    if (valcatG.equals("4") || valcatG.equals("7") ||
        valcatG.equals("11") ||
        valcatG.equals("14") || valcatG.equals("19") ||
        valcatG.equals("22") || valcatG.equals("26") ||
        valcatG.equals("29") || valcatG.equals("33") ||
        valcatG.equals("36") || valcatG.equals("42") ||
        valcatG.equals("43") || valcatG.equals("48") ||
        valcatG.equals("51") || valcatG.equals("55") ||
        valcatG.equals("60") || valcatG.equals("63") ||
        valcatG.equals("103") || valcatG.equals("107") ||
        valcatG.equals("110") || valcatG.equals("140") ||
        valcatG.equals("141") || valcatG.equals("148")
        || valcatG.equals("149") || valcatG.equals("150") ||
        valcatG.equals("151") || valcatG.equals("160") ||
        valcatG.equals("161") || valcatG.equals("162") ||
        valcatG.equals("163") || valcatG.equals("180") ||
        valcatG.equals("181") || valcatG.equals("182") ||
        valcatG.equals("183") || valcatG.equals("193") ||
        valcatG.equals("198") || valcatG.equals("201") ||
        valcatG.equals("204") || valcatG.equals("205") ||
        valcatG.equals("208") ||
        valcatG.equals("211") || valcatG.equals("214") ||
        valcatG.equals("220"))
      cas = "A";
    else if (valcatG.equals("5") || valcatG.equals("8") ||
             valcatG.equals("12") ||
             valcatG.equals("15") || valcatG.equals("20") ||
             valcatG.equals("23") || valcatG.equals("27") ||
             valcatG.equals("30") || valcatG.equals("34") ||
             valcatG.equals("37") || valcatG.equals("44") ||
             valcatG.equals("45") || valcatG.equals("49") ||
             valcatG.equals("52") || valcatG.equals("56") ||
             valcatG.equals("61") || valcatG.equals("64") ||
             valcatG.equals("108") ||
             valcatG.equals("111") || valcatG.equals("142") ||
             valcatG.equals("143") || valcatG.equals("152")
             || valcatG.equals("153") || valcatG.equals("154") ||
             valcatG.equals("155") || valcatG.equals("164") ||
             valcatG.equals("165") || valcatG.equals("166") ||
             valcatG.equals("167") || valcatG.equals("172") ||
             valcatG.equals("173") || valcatG.equals("174") ||
             valcatG.equals("175") || valcatG.equals("184") ||
             valcatG.equals("185") || valcatG.equals("186") ||
             valcatG.equals("187") || valcatG.equals("194") ||
             valcatG.equals("199") ||
             valcatG.equals("202") || valcatG.equals("206") ||
             valcatG.equals("209") || valcatG.equals("212") ||
             valcatG.equals("215") || valcatG.equals("218") ||
             valcatG.equals("219"))
      cas = "N";
    else if (valcatG.equals("6") || valcatG.equals("9") ||
             valcatG.equals("13") ||
             valcatG.equals("16") || valcatG.equals("21") ||
             valcatG.equals("24") || valcatG.equals("28") ||
             valcatG.equals("31") || valcatG.equals("35") ||
             valcatG.equals("38") || valcatG.equals("46") ||
             valcatG.equals("47") || valcatG.equals("50") ||
             valcatG.equals("53") || valcatG.equals("57") ||
             valcatG.equals("62") || valcatG.equals("65") ||
             valcatG.equals("104") || valcatG.equals("109") ||
             valcatG.equals("112") || valcatG.equals("195") ||
             valcatG.equals("196") || valcatG.equals("197")
             || valcatG.equals("200") || valcatG.equals("203") ||
             valcatG.equals("207") || valcatG.equals("210") ||
             valcatG.equals("213") || valcatG.equals("216"))
      cas = "G";
    else if (valcatG.equals("144") || valcatG.equals("145") ||
             valcatG.equals("156") ||
             valcatG.equals("157") || valcatG.equals("158") ||
             valcatG.equals("159") || valcatG.equals("168") ||
             valcatG.equals("169") || valcatG.equals("170") ||
             valcatG.equals("171") || valcatG.equals("176") ||
             valcatG.equals("177") || valcatG.equals("178") ||
             valcatG.equals("179") || valcatG.equals("188") ||
             valcatG.equals("189") || valcatG.equals("190") ||
             valcatG.equals("191"))
      cas = "S";
    else cas = "";
    return cas;

  }
  
  
  
  
  public static void main(String[] args) {
  // Create the empty dataset "race" with above attributes
  Texte txt = new Texte();
  //txt.nomfichier= "train2.xml";
  String texte1 = txt.nomfichier.substring(0,txt.nomfichier.indexOf("."));
  System.out.println(texte1);
  List parags=txt.ExtractParagraphe();
  for(int x=0;x<parags.size();x++){
	  Paragraphe parag=new Paragraphe();
	  parag.paragraphe=(Element) parags.get(x);
	  List phrases=parag.ExtrairePhrases();
	  for(int y=0;y<phrases.size();y++){
		  Phrase phr=new Phrase();
		  phr.phrase=(Element) phrases.get(y);
		  System.out.println(phr.TextePhrase());
	  }
  }
  List phs = txt.ExtractPhrase();
  System.out.println(phs.size());
  Iterator i =phs.iterator();
  while(i.hasNext()){

    Phrase ph = new Phrase();
    ph.phrase=(Element)i.next();
    //System.out.println(ph.TextePhrase());
    //System.out.println(ph.ExtraireSyntagmes().size());
    List mots = ph.ExtraireSyntagmes();
    Iterator j = mots.iterator();
    while(j.hasNext())
    {
    	Syntagme m1 = new Syntagme();
    	 m1.syntagme=(Element)j.next();
    	 List mots1 = m1.ExtraireMots();
    	 Iterator k = mots1.iterator();
    	 while(k.hasNext())
    	    {
    		 Mot m = new Mot();
        	 m.mot=(Element)k.next();
  }
  }
  }

  System.out.println("corpus cr�� avec succ�s");
  
  }
}


