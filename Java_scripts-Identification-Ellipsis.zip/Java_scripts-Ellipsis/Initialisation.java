package Detection_Resolution_Ellipse;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import org.jdom2.Element;

public class Initialisation {

	/**
	 * @param args
	 */
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String NameFile="";
		//Qlearning_Step();
		////System.out.println("aaabbccccc".toUpperCase().contains("d".toUpperCase()));
		
	}
	
	
	public static Integer [] FrequenceCombinCrit(InstanceEllipse Ellip,String[] ListNameFile, ArrayList<String> ListCombin){
		//Integer[][] TF= new Integer[2][ListCombin.size()];
		Integer[] TF= new Integer[ListCombin.size()+1];
		Texte txt = new Texte();
		Paragraphe parag=new Paragraphe();
		Phrase ph = new Phrase();
		Syntagme s=new Syntagme();
		Mot m=new Mot();
		Candidat ca=new Candidat();
		List ListMotsPreEllipse=new ArrayList<String>();
		List phs;
		List syntags;
		List mots;
		List ListCand=new ArrayList();
		String type_verb;
		String VerifCrit=new String();
		ArrayList<String> EnsbCombin=new ArrayList<String>();
		int IndexCombin;
		String NameFile=new String();
		String[] EnsbVerifCrit;
		int NbrEllipBienResolu=0;
		int numMot;
		int dist=0;
		int indexEllip=-1;
		Antecedent BestAntEllipPrec=new Antecedent(0,"","","",0,0,"","","","");		
		List<Ellipse_Candidat> List_Ellip_Cand=new ArrayList<Ellipse_Candidat>();
		List<Antecedent> ListAnteced=new ArrayList<Antecedent>();
	
		//Initialisation
		for(int x=0;x<TF.length;x++){
			TF[x]=0;
		}
		//Remplir la premi�re ligne de la table de fr�quence TF avec toutes les combinaisons de crit�res possibles
		/*for(int x=0;x<ListCombin.size();x++){
			TF[0][x]=Integer.parseInt(ListCombin.get(x));
		}*/
		for(int f=0;f<ListNameFile.length;f++){
			NameFile=ListNameFile[f];
			indexEllip=-1;
			List_Ellip_Cand=ExtractionEllipseAntecedents.Extraction(NameFile);
			txt.nomfichier= NameFile;
			String texte1 = txt.nomfichier.substring(0,txt.nomfichier.indexOf(".")); 
			//System.out.println("texte analysé:"+texte1);
			List parags=txt.ExtractParagraphe();
			for(int pa=0;pa<parags.size();pa++){	
				 parag.paragraphe=(Element)parags.get(pa);
				 phs = parag.ExtrairePhrases();
				 for(int i=0;i<phs.size();i++){
					 ph.phrase=(Element)phs.get(i);					 
					 mots = ph.ExtraireMots();
					 ListMotsPreEllipse=MethodesDivers.ExtraireMotsPredEllipse(ph);
					 for(int k=0;k<mots.size();k++){
						 m.mot=(Element)mots.get(k);
						 numMot=Integer.parseInt(m.ExtraireNum())-1;
						 type_verb=MethodesDivers.TypeVerbe(m.ExtraireVGRad());
						 if(!MethodesDivers.TypeVerbe(m.ExtraireVGRad()).equals("")){
							////System.out.println("mot courant:"+m.ExtraireValeur()+" indice mot:"+k+" vg courant:"+m.ExtraireVGRad());													
							if(MethodesDivers.AppartientListe(ListMotsPreEllipse,m.ExtraireValeur())){							
								//System.out.println("******************nouvelle instance ellipse sujet");
								indexEllip++;
					        	Ellip=List_Ellip_Cand.get(indexEllip).getInst_Ellipse(); 
					        	ListAnteced=List_Ellip_Cand.get(indexEllip).getListeAnteced();
								if(EllipseMemeContexte(Ellip,m)){									
									VerifCrit="";
									//System.out.println("///++++++verb gouv:"+m.ExtraireValeur());
					        	    dist=MethodesDivers.Distance_Ellipse_VerbeGouvernant(phs,i, m.ExtraireValeur());
					        	    Antecedent Anteced=MethodesDivers.RechercheMotAntecedent(NameFile,k, pa,i,dist);				        		
		        					NbrEllipBienResolu++;
			        				 ////System.out.println("Anaphore de meme contexte:"+m.ExtraireValeur()+" phrase:"+(i+1));
		        					m.mot=(Element)mots.get(k);		        				 
			        				//System.out.println(Anteced.getValeur()+"///++++++verb gouv:"+m.ExtraireValeur());
			        				VerifCrit=VerifiedCriteria(m,Anteced,ListAnteced,txt,pa,i,dist,BestAntEllipPrec);
			        				////System.out.println("Verified criteria:"+VerifCrit);
			        				if(VerifCrit.length()>0){
				        				 EnsbVerifCrit=VerifCrit.substring(1).split(" ");
				        				 EnsbCombin=Combinaison.CombinaisonPossibles(EnsbVerifCrit);
				        				 ////System.out.println("nbr crit verif:"+EnsbVerifCrit.length+" Premier ele:"+EnsbVerifCrit[0]+" nbr ensb combin:"+EnsbCombin.size());
				        				 for(int c=0;c<EnsbCombin.size();c++){
				        					 ////System.out.println("combin possib:"+EnsbCombin.get(c));
				        					 IndexCombin=SearchIndexCombin(EnsbCombin.get(c),ListCombin);
				        					 ////System.out.println("Index verif criteria:"+IndexCombin);
				        					 TF[IndexCombin]=TF[IndexCombin]+1; 
				        				 }
			        				 }
			        				
			        				 BestAntEllipPrec=Anteced;
								}
								else 
									BestAntEllipPrec=new Antecedent(0,"","","",0,0,"","","","");
							}
						 }
					}
				}				
			}
		}
		//System.out.println("nbr combinaison "+ListCombin.size());
		//System.out.println("nbr d'anaphore bien r�solu:"+NbrEllipBienResolu);
		TF[ListCombin.size()]=NbrEllipBienResolu;
		return TF;
	}
	
	public static Integer [] FrequenceCombinCritSeul(InstanceEllipse Ellip, String[] ListNameFile, ArrayList<String> ListCombin){
		//Integer[][] TF= new Integer[2][ListCombin.size()];
		Integer[] TF= new Integer[ListCombin.size()];
		Texte txt = new Texte();
		Paragraphe parag=new Paragraphe();
		Phrase ph = new Phrase();
		Syntagme s=new Syntagme();
		Mot m=new Mot();
		Mot mtAnteced=new Mot();
		List phs;
		List syntags;
		List mots;
		List ListCand=new ArrayList();
		String type_verb;
		String VerifCrit=new String();
		ArrayList<String> CombinVerifCrit=new ArrayList<String>();
		int IndexCombin;
		String NameFile=new String();
		int numMot;
		int dist=0;
		int indexEllip=-1;
		Antecedent BestAntEllipPrec=new Antecedent(0,"","","",0,0,"","","","");
		List ListMotsPreEllipse=new ArrayList<String>();
		List<Ellipse_Candidat> List_Ellip_Cand=new ArrayList<Ellipse_Candidat>();
		List<Antecedent> ListAnteced=new ArrayList<Antecedent>();
		//Initialisation
		for(int x=0;x<TF.length;x++){
			TF[x]=0;
		}
		//Remplir la premi�re ligne de la table de fr�quence TF avec toutes les combinaisons de crit�res possibles
		/*for(int x=0;x<ListCombin.size();x++){
			TF[0][x]=Integer.parseInt(ListCombin.get(x));
		}*/
		for(int f=0;f<ListNameFile.length;f++){
			NameFile=ListNameFile[f];
			indexEllip=-1;
			List_Ellip_Cand=ExtractionEllipseAntecedents.Extraction(NameFile);
			txt.nomfichier= NameFile;
			String texte1 = txt.nomfichier.substring(0,txt.nomfichier.indexOf(".")); 
			//System.out.println("texte analys�:"+texte1);
			List parags=txt.ExtractParagraphe();
			for(int pa=0;pa<parags.size();pa++){	
				 parag.paragraphe=(Element)parags.get(pa);
				 phs = parag.ExtrairePhrases();
				 for(int i=0;i<phs.size();i++){
					 ph.phrase=(Element)phs.get(i);					 
					 mots = ph.ExtraireMots();
					 ListMotsPreEllipse=MethodesDivers.ExtraireMotsPredEllipse(ph);
					 for(int k=0;k<mots.size();k++){
						 m.mot=(Element)mots.get(k);
						 numMot=Integer.parseInt(m.ExtraireNum())-1;
						 type_verb=MethodesDivers.TypeVerbe(m.ExtraireVGRad());
						 if(!MethodesDivers.TypeVerbe(m.ExtraireVGRad()).equals("")){
							////System.out.println("mot courant:"+m.ExtraireValeur()+" indice mot:"+k+" vg courant:"+m.ExtraireVGRad());													
							if(MethodesDivers.AppartientListe(ListMotsPreEllipse,m.ExtraireValeur())){							
								//System.out.println("******************nouvelle instance ellipse sujet");			        	 
								VerifCrit="";	
								indexEllip++;
					        	Ellip=List_Ellip_Cand.get(indexEllip).getInst_Ellipse(); 
					        	ListAnteced=List_Ellip_Cand.get(indexEllip).getListeAnteced();
								if(EllipseMemeContexte(Ellip,m)){
									//System.out.println("///++++++verb gouv:"+m.ExtraireValeur());
									dist=MethodesDivers.Distance_Ellipse_VerbeGouvernant(phs,i, m.ExtraireValeur());
			        				Antecedent Anteced=MethodesDivers.RechercheMotAntecedent(NameFile,k, pa,i,dist);			        				 
			        				m.mot=(Element)mots.get(k);	
			        				//System.out.println(Anteced.getValeur()+"///++++++verb gouv:"+m.ExtraireValeur());			        				
			        				VerifCrit=VerifiedCriteria(m,Anteced,ListAnteced,txt,pa,i,dist,BestAntEllipPrec);
			        				// //System.out.println("Verified criteria:"+VerifCrit);
			        				 if(!VerifCrit.equals("")){
				        				 IndexCombin=SearchIndexCombin(VerifCrit.substring(1),ListCombin);		//supprimer le 1ier caract�re du VerifCrit parceque c'est une espace
				        				// //System.out.println("Index verif criteria:"+IndexCombin);
				        				 TF[IndexCombin]=TF[IndexCombin]+1; 
			        				 }
			        				 //}
			        				 BestAntEllipPrec=Anteced;
								}
								else
									BestAntEllipPrec=new Antecedent(0,"","","",0,0,"","","","");
							}
						 }
					 }						 
				 }
			}
		}
		return TF;
	}
	public static Integer [] FrequenceContexteEllipAnteced(InstanceEllipse Ellip, String NameFile ){
		//Integer[][] TF= new Integer[2][ListCombin.size()];
		Integer[] TF= new Integer[10];
		Texte txt = new Texte();
		Paragraphe parag=new Paragraphe();
		Phrase ph = new Phrase();
		Syntagme s=new Syntagme();
		Mot m=new Mot();
		Candidat ca=new Candidat();
		
		List phs;
		List syntags;
		List mots;
		List ListCand=new ArrayList();
		String type_verb;
		String VerifCrit=new String();
		ArrayList<String> EnsbCombin=new ArrayList<String>();
		int IndexCombin;
		String TypeAnteced=new String();
		String[] EnsbVerifCrit;
		int NbrAnaphBienResolu=0;
		int numMot;
		int dist=0;
		List ListMotsPreEllipse=new ArrayList<String>();
		//Initialisation
		for(int x=0;x<TF.length;x++){
			TF[x]=0;
		}
		//Remplir la premi�re ligne de la table de fr�quence TF avec toutes les combinaisons de crit�res possibles
		/*for(int x=0;x<ListCombin.size();x++){
			TF[0][x]=Integer.parseInt(ListCombin.get(x));
		}*/
		
			txt.nomfichier= NameFile;
			String texte1 = txt.nomfichier.substring(0,txt.nomfichier.indexOf(".")); 
			//System.out.println("texte analysé:"+texte1);
			List parags=txt.ExtractParagraphe();
			for(int pa=0;pa<parags.size();pa++){	
				 parag.paragraphe=(Element)parags.get(pa);
				 phs = parag.ExtrairePhrases();
				 for(int i=0;i<phs.size();i++){
					 ph.phrase=(Element)phs.get(i);					 
					 mots = ph.ExtraireMots();
					 ListMotsPreEllipse=MethodesDivers.ExtraireMotsPredEllipse(ph);
					 for(int k=0;k<mots.size();k++){
						 m.mot=(Element)mots.get(k);						 
						 numMot=Integer.parseInt(m.ExtraireNum())-1;
						 type_verb=MethodesDivers.TypeVerbe(m.ExtraireVGRad());
						 if(!MethodesDivers.TypeVerbe(m.ExtraireVGRad()).equals("")){
							////System.out.println("mot courant:"+m.ExtraireValeur()+" indice mot:"+k+" vg courant:"+m.ExtraireVGRad());													
							if(MethodesDivers.AppartientListe(ListMotsPreEllipse,m.ExtraireValeur())){							
								////System.out.println("******************nouvelle instance ellipse sujet");
			        		 VerifCrit="";
			        		 if(EllipseMemeContexte(Ellip,m)){
		        				 ////System.out.println("Anaphore de meme contexte:"+m.ExtraireValeur()+" phrase:"+(i+1));			        				 
		        					 NbrAnaphBienResolu++;				        				 
			        				 ////System.out.println("candidat "+ca.ExtraireValeur()+" "+ca.ExtraireNumPhrase()+" "+ca.ExtraireNumMot());
		        					 dist=MethodesDivers.Distance_Ellipse_VerbeGouvernant(phs,i, m.ExtraireValeur());
		        					 Antecedent mtAnteced=MethodesDivers.RechercheMotAntecedent(NameFile,k, pa,i,dist);
			        				 TypeAnteced=TypeCandidat(mtAnteced.getVg());
			        				 if(TypeAnteced.equals("Nom_ville_ou_pays"))
			        					 TF[0]++;
			        				 if(TypeAnteced.equals("Nom_propre"))
			        					 TF[1]++;
			        				 if(TypeAnteced.equals("Nom_verbal"))
			        					 TF[2]++;
			        				 if(TypeAnteced.equals("Nom_indefini"))
			        					 TF[3]++;
			        				 if(TypeAnteced.equals("Nom_defini"))
			        					 TF[4]++;
			        				 if(TypeAnteced.equals("Compose"))
			        					 TF[5]++;
			        				 if(TypeAnteced.equals("Complement"))
			        					 TF[6]++;
			        				 if(TypeAnteced.equals("les_5_noms"))
			        					 TF[7]++;
			        				 if(TypeAnteced.equals("Adjectif"))
			        					 TF[8]++;
				        				 
			        				 }
			        			 }
				        	 }
						 }
					 }
				 }
			
		
		//System.out.println("nbr d'anaphore bien r�solu pour contexte anaph anteced:"+NbrAnaphBienResolu);
		TF[9]=NbrAnaphBienResolu;
		return TF;
	}
	public static Integer [] FrequenceContexteEllipAnteced2(InstanceEllipse Ellip, String[] NameFiles ){
		//Integer[][] TF= new Integer[2][ListCombin.size()];
		Integer[] TF= new Integer[10];
		Texte txt = new Texte();
		Paragraphe parag=new Paragraphe();
		Phrase ph = new Phrase();
		Syntagme s=new Syntagme();
		Mot m=new Mot();
		
		List ListMotsPreEllipse=new ArrayList<String>();
		List phs;
		List syntags;
		List mots;
		List ListCand=new ArrayList();
		String type_verb;
		String VerifCrit=new String();
		ArrayList<String> EnsbCombin=new ArrayList<String>();
		int IndexCombin;
		String TypeAnteced=new String();
		String[] EnsbVerifCrit;
		int NbrAnaphBienResolu=0;
		int numMot;
		int dist=0;
		//Initialisation
		for(int x=0;x<TF.length;x++){
			TF[x]=0;
		}
		//Remplir la premi�re ligne de la table de fr�quence TF avec toutes les combinaisons de crit�res possibles
		/*for(int x=0;x<ListCombin.size();x++){
			TF[0][x]=Integer.parseInt(ListCombin.get(x));
		}*/
		for(int f=0;f<NameFiles.length;f++){
			String NameFile=NameFiles[f];
			txt.nomfichier= NameFile;
			String texte1 = txt.nomfichier.substring(0,txt.nomfichier.indexOf(".")); 
			//System.out.println("texte analys�:"+texte1);
			List parags=txt.ExtractParagraphe();
			for(int pa=0;pa<parags.size();pa++){	
				 parag.paragraphe=(Element)parags.get(pa);
				 phs = parag.ExtrairePhrases();
				 for(int i=0;i<phs.size();i++){
					 ph.phrase=(Element)phs.get(i);					 
					 mots = ph.ExtraireMots();
					 ListMotsPreEllipse=MethodesDivers.ExtraireMotsPredEllipse(ph);
					 for(int k=0;k<mots.size();k++){
						 m.mot=(Element)mots.get(k);
						 numMot=Integer.parseInt(m.ExtraireNum())-1;
						 type_verb=MethodesDivers.TypeVerbe(m.ExtraireVGRad());
						 if(!MethodesDivers.TypeVerbe(m.ExtraireVGRad()).equals("")){
							////System.out.println("mot courant:"+m.ExtraireValeur()+" indice mot:"+k+" vg courant:"+m.ExtraireVGRad());													
							if(MethodesDivers.AppartientListe(ListMotsPreEllipse,m.ExtraireValeur())){							
								//System.out.println("******************nouvelle instance ellipse sujet");
			        		 VerifCrit="";
			        		 if(EllipseMemeContexte(Ellip,m)){				        			
			        					 NbrAnaphBienResolu++;	
			        					 dist=MethodesDivers.Distance_Ellipse_VerbeGouvernant(phs,i, m.ExtraireValeur());
			        					 Antecedent mtAnteced=MethodesDivers.RechercheMotAntecedent(NameFile,k, pa,i,dist);
				        				 TypeAnteced=TypeCandidat(mtAnteced.getVg());
				        				 if(TypeAnteced.equals("Nom_ville_ou_pays"))
				        					 TF[0]++;
				        				 if(TypeAnteced.equals("Nom_propre"))
				        					 TF[1]++;
				        				 if(TypeAnteced.equals("Nom_verbal"))
				        					 TF[2]++;
				        				 if(TypeAnteced.equals("Nom_indefini"))
				        					 TF[3]++;
				        				 if(TypeAnteced.equals("Nom_defini"))
				        					 TF[4]++;
				        				 if(TypeAnteced.equals("Compose"))
				        					 TF[5]++;
				        				 if(TypeAnteced.equals("Complement"))
				        					 TF[6]++;
				        				 if(TypeAnteced.equals("les_5_noms"))
				        					 TF[7]++;
				        				 if(TypeAnteced.equals("Adjectif"))
				        					 TF[8]++;
				        				 
			        				 }
			        			 }
				        	 }
						 }
					 }				 
			}
		}
		//System.out.println("nbr d'anaphore bien r�solu pour contexte anaph anteced:"+NbrAnaphBienResolu);
		TF[9]=NbrAnaphBienResolu;
		return TF;
	}
	public static double ProbaContexteEllipAnteced(String TypeAnteced,Integer[] FreqContextEllipAnteced ){
		double Proba=0;
		if(TypeAnteced.equals("Nom_ville_ou_pays"))
			Proba=(double)FreqContextEllipAnteced[0]/FreqContextEllipAnteced[9];
		else if(TypeAnteced.equals("Nom_propre"))
			Proba=(double)FreqContextEllipAnteced[1]/FreqContextEllipAnteced[9];
		else if(TypeAnteced.equals("Nom_verbal"))
			Proba=(double)FreqContextEllipAnteced[2]/FreqContextEllipAnteced[9];
		else if(TypeAnteced.equals("Nom_indefini"))
			Proba=(double)FreqContextEllipAnteced[3]/FreqContextEllipAnteced[9];
		else if(TypeAnteced.equals("Nom_defini"))
			Proba=(double)FreqContextEllipAnteced[4]/FreqContextEllipAnteced[9];
		else if(TypeAnteced.equals("Compose"))
			Proba=(double)FreqContextEllipAnteced[5]/FreqContextEllipAnteced[9];
		else if(TypeAnteced.equals("Complement"))
			Proba=(double)FreqContextEllipAnteced[6]/FreqContextEllipAnteced[9];
		else if(TypeAnteced.equals("les_5_noms"))
			Proba=(double)FreqContextEllipAnteced[7]/FreqContextEllipAnteced[9];
		else if(TypeAnteced.equals("Adjectif"))
			Proba=(double)FreqContextEllipAnteced[8]/FreqContextEllipAnteced[9];
			
		return Proba;
	}
	public static boolean EllipseMemeContexte(InstanceEllipse Ellip, Mot mt){
		boolean verif=false;
		if(mt.ExtraireVGRad().equals(Ellip.getVgVerbeGouv()))
			verif=true;
		
		return verif;
	}
	public static boolean CategoriePronPersAttacheNom(String Vg){
		boolean verif=false;
		if(Vg.equals("38")||Vg.equals("39")||Vg.equals("40")||Vg.equals("45")||Vg.equals("46")||Vg.equals("47"))
			verif=true;
		return verif;
	}
	public static String VerifiedCriteria(Mot VerbGouvEllip,Antecedent motAnteced, List<Antecedent> ListAnteced, Texte txt, int nparag, int nphr,int dist,Antecedent BestAntEllipPreced){
		//System.out.println("verif:"+motAnteced.getValeur()+" // verb gouv ellipse:"+VerbGouvEllip.ExtraireValeur());
		String VerifCrit=new String();
		VerifCrit="";
		if(VerifCritPlusProche(motAnteced, ListAnteced))
			VerifCrit=VerifCrit+" "+"1";		//l'antecedent le plus proche
		if(motAnteced.getDistance()<=5)
			VerifCrit=VerifCrit+" "+"2";		//distance
		else if(motAnteced.getDistance()<=10)
			VerifCrit=VerifCrit+" "+"3";		//distance
		else if(motAnteced.getDistance()<=15)
			VerifCrit=VerifCrit+" "+"4";		//distance
		if(nphr==motAnteced.getNumPh())
			VerifCrit=VerifCrit+" "+"5";		//Ellip et antecedent dans la meme phrase
		if(VerifCritDefinition(motAnteced))
			VerifCrit=VerifCrit+" "+"6";		//Definition
		if(VerifCritTheme(motAnteced))
			VerifCrit=VerifCrit+" "+"7";		//theme
		if(VerifCritNomPropre(motAnteced))
			VerifCrit=VerifCrit+" "+"8";		//nom propre		
		if(VerifCritTeteParag(motAnteced))
			VerifCrit=VerifCrit+" "+"9";		//tete de parag		
		if(VerifCritRepetition(motAnteced,txt,nparag))
			VerifCrit=VerifCrit+" "+"10";		//repetition
		if(VerifCritAccordPT(VerbGouvEllip,motAnteced,txt,nparag))
			VerifCrit=VerifCrit+" "+"11";		//AccordPT
		//if(VerifCritClauseBienForme(motAnteced,txt,nparag))
			//VerifCrit=VerifCrit+" "+"12";		//Antecedent dans une clause bien forme
		if(VerifCritAntEllipPreced(motAnteced,BestAntEllipPreced))
			VerifCrit=VerifCrit+" "+"12";		//Antecedent de l'ellipse precedent
		/*if(VerifCritCollocation(motAnteced,motAnaph))
			VerifCrit=VerifCrit+" "+"7";*/
		
		return VerifCrit;
	}
	public static boolean VerifCritClauseBienForme(Antecedent motAnteced,Texte txt,int nparag){
		boolean verif=false;
		////System.out.println("crit clause bien forme: mot anteced:"+motAnteced.getNumMot()+" "+ motAnteced.getNumPh()+" "+ nparag);
		Mot mt=MethodesDivers.RechercheMot(txt, Integer.parseInt(motAnteced.getNumMot())-2, motAnteced.getNumPh(), nparag);
		if(!MethodesDivers.TypeVerbe((mt.ExtraireVGRad())).equals(""))
			verif=true;
		
		return verif;
	}
	public static boolean VerifCritAccordPT(Mot VerbGouvEllip,Antecedent motAnteced, Texte txt, int nparag){
		boolean verif=false;
		////System.out.println("Ellip verb gouv:"+Ellip.getValVerbGouv()+" anteced:"+motAnteced.getValeur());
		Mot VerbGouvAnteced=MethodesDivers.RechercheVerbeGouvAnteced(motAnteced, txt, nparag);
		if(VerbGouvAnteced.ExtrairePronom().equals(VerbGouvEllip.ExtrairePronom())&& VerbGouvAnteced.ExtraireTransitivite().equals(VerbGouvEllip.ExtraireTransitivite()))
			verif=true;
		return verif;
	}
	public static boolean VerifCritPlusProche(Antecedent motAnteced, List<Antecedent>ListAntec){
		boolean verif=false;
		int distmin=1000;
		////System.out.println("critere le plus proche: la distance du mot anteced:"+motAnteced.getDistance());
		for(int i=0;i<ListAntec.size();i++){
			////System.out.println("distance anteced="+ListAntec.get(i).getDistance());
			if(ListAntec.get(i).getDistance()<distmin)
				distmin=ListAntec.get(i).getDistance();
		}
		if(motAnteced.getDistance()==distmin)
			verif=true;
		return verif;
	}
	public static Boolean VerifCritDefinition(Antecedent Ant){
		boolean verif=false;
		if(Ant.getVg().equals("48")||Ant.getVg().equals("49")||Ant.getVg().equals("50")
				||Ant.getVg().equals("197")||Ant.getVg().startsWith("lL")||MethodesDivers.MotAnnexe(Ant.getVg())
				||VerifCritNomPropre(Ant))  /*Un GN defini*/
			verif=true;
		
		return verif;
	}
	
	public static Boolean VerifCritTheme(Antecedent Ant){
		boolean verif=false;
		if(Ant.getVg().equals("23")||Ant.getVg().equals("34")||Ant.getVg().equals("37")||Ant.getVg().equals("44")||
				Ant.getVg().equals("45")||Ant.getVg().equals("49")||Ant.getVg().equals("52")||
				Ant.getVg().equals("61")||Ant.getVg().equals("194")||Ant.getVg().equals("202"))  /*Un GN nominatif */
			verif=true;
			
		return verif;
	}
	public static Boolean VerifCritNomPropre(Antecedent Ant){
		boolean verif=false;
		if(Ant.getVg().equals("33")||Ant.getVg().equals("34")||Ant.getVg().equals("35")||
				Ant.getVg().equals("36")||Ant.getVg().equals("37")||Ant.getVg().equals("38"))  /*Un nom propre */
			verif=true;
			
		return verif;
	}
	public static Boolean VerifCritDistance(int nph, int nphAnaph){
		boolean verif=false;
		if(nph==nphAnaph||(nphAnaph>1 && nph==nphAnaph-1)){
			verif=true;
		}
			
		return verif;
	}
	public static Boolean VerifCritTeteParag(Antecedent Ant){
		boolean verif=false;
		if(Ant.getNumPh()==0 && MethodesDivers.Nominatif(Ant.getVg()))
			verif=true;
			
		return verif;
	}	
	public static Boolean VerifCritRepetition(Antecedent Ant, Texte txt, int nparag){
		boolean verif=false;
		//if(methodeUtil.NombreRepetition(Ant.getVg(),txt, nparag,nphr)>=2)
		if(MethodesDivers.NombreRepetition(Ant.getLemme(),txt, nparag,Ant.getNumPh())>=2)
			verif=true;
			
		return verif;
	}
	public static Boolean VerifCritCollocation(Antecedent Ant, Mot motAnaph){
		boolean verif=false;
		if(MethodesDivers.EstuneCollocation(motAnaph.ExtraireLem(),Ant.getLemme()))
			verif=true;
			
		return verif;
	}	
	public static boolean VerifCritAntEllipPreced(Antecedent motAnteced,Antecedent BestAntEllipPreced){
		boolean verif=false;
		//System.out.println(motAnteced.getValeur()+" BestAntEllipPr:"+BestAntEllipPreced.getValeur());
		//System.out.println(motAnteced.getNumPh()+"--"+BestAntEllipPreced.getNumPh()+"   "+motAnteced.getNumMot()+" "+BestAntEllipPreced.getNumMot());
		if((motAnteced.getNumPh()==BestAntEllipPreced.getNumPh() && motAnteced.getNumMot().equals(BestAntEllipPreced.getNumMot()))||
				motAnteced.getValeur().equals(BestAntEllipPreced.getValeur()))
			verif=true;//System.out.println("crit ant ellip preced verifie");}
		return verif;
	}
	
	public static String MacroVg(String Vg){
		String MVg=new String();
		int ValGram=0;
		if(!Vg.equals(""))
			ValGram=Integer.parseInt(Vg);
		
		/*if(ValGram>=19 && ValGram<=24){
			MVg="Nom de ville ou de pays";
		}
		else if(ValGram>=33 && ValGram<=38){
			MVg="Nom propre";
		}*/
		if(ValGram==0)
			MVg="vide";
		if((ValGram==2)||(ValGram>=66 && ValGram<=93)||(ValGram==58)||(ValGram==59)||(ValGram==222)||(ValGram==223)){
			MVg="Particule";
		}
		else if(ValGram>=113 && ValGram<=191){
			MVg="Verbe";
		}
		else
			MVg="Substantif";

		return MVg;
	}
	
	
	public static List<String> TableState(int nbrAnt, ArrayList<String> ListCombin){
		List<String> TS=new ArrayList<String>();
		String S=new String();
		TS.add("S0");
		for(int i=0;i<nbrAnt;i++){
			for(int j=0;j<ListCombin.size();j++){
				S="A"+Integer.toString(i)+"C"+ListCombin.get(j);
				TS.add(S);
			}
		}
		TS.add("SF");
		return TS;
	}
	public static List<String> TableAction(int nbrAnt, int nbrCrit){
		List<String> TS=new ArrayList<String>();
		String S=new String();
		for(int i=0;i<nbrAnt;i++){
			for(int j=0;j<nbrCrit;j++){
				S="A"+Integer.toString(i)+"C"+Integer.toString(j+1);
				TS.add(S);
			}
		}
		for(int j=0;j<nbrCrit;j++){
			S="C"+Integer.toString(j+1);
			TS.add(S);
		}
		TS.add("CF");
		return TS;
	}
	public static List<String> SearchStateSuiv(String Combin, int nbcrit){
		List<String> ListState=new ArrayList<String>();
		String[] List=Combin.split(" ");
		////System.out.println("taille combin:"+List.length);
		for(int i=1;i<=nbcrit;i++){
			////System.out.println("crit:"+Integer.toString(i)+" ");
			if(!CritBelongsCombin(Integer.toString(i),List)){
				ListState.add(Combin+" "+Integer.toString(i));
			}
			
		}
		return ListState;
	}
	public static int SearchIndexCombin(String NewCombin,ArrayList<String> ListCombin){
		int index=-1;
		int i=0;
		
		while(index==-1 && i<ListCombin.size()){
			//if(ListCombin.get(i).equals(NewCombin));
			String[] L1=NewCombin.split(" ");////System.out.println(L1.length);
			String[] L2=ListCombin.get(i).split(" ");////System.out.println(L2.length);
			if((Arrays.asList(L1).containsAll(Arrays.asList(L2))) && (Arrays.asList(L2).containsAll(Arrays.asList(L1))))
				index=i;
			i++;
		}
		return index;
	}
	public static boolean CritBelongsCombin(String crit,String[] List){
		boolean exist=false;
		int i=0;
		
		while(i<List.length && !exist){
			////System.out.println("crit:"+crit+" elemnt combin:"+List[i].replaceAll("\\s+",""));
			if(List[i].replaceAll("\\s+","").equals(crit))
				exist=true;
			i++;
		}
		return exist;
	}
	public static boolean CombinIncludCrit(int NumCombin,String Crit,ArrayList<String> ListCombin){
		boolean existe=false;
		int i=0;
		if(NumCombin<ListCombin.size()){
			String Combin=ListCombin.get(NumCombin-1);
			existe=Combin.toUpperCase().contains(Crit.toUpperCase());
		}
		return existe;
	}
	public static Double[][] InitialisationQ(int NbState, int NbAct){
		Double[][] MQ=new Double[NbState][NbAct];
		for (int i=0;i<NbState;i++){
			for (int j=0;j<NbAct;j++){
				MQ[i][j]=0.0;
			}
		}
		return MQ;
	}
	public static boolean StateIncludAction(String State,String Crit,ArrayList<String> ListCombin){
		boolean existe=false;
		int i=0;
		////System.out.println("State inclu crit:"+State+" crit:"+Crit);
		String CombinCrit=State.substring(State.indexOf("C")+1, State.length());
		////System.out.println("CombinCrit:"+CombinCrit);		
		existe=CombinCrit.toUpperCase().contains(Crit.toUpperCase());
		////System.out.println(existe);
		return existe;
	}
	public static int SearchIndexofState(String State,List<String>TabState){
		int index=-1;
		
		String Ant1=new String();
		String Ant2=new String();
		String CombinCrit1=new String();
		String CombinCrit2=new String();
		
		if(State.equals("S0"))
			index=0;
		else if(State.equals("SF"))
			index=TabState.size()-1;
		else{
			int i=1;
			while(i<TabState.size()-1 && index==-1){
				////System.out.println(TabState.get(i)+"vs"+State);
				Ant1=TabState.get(i).substring(0,TabState.get(i).indexOf("C"));
				Ant2=State.substring(0, State.indexOf("C"));
				CombinCrit1=TabState.get(i).substring(TabState.get(i).indexOf("C")+1, TabState.get(i).length());
				CombinCrit2=State.substring(State.indexOf("C")+1, State.length());
				String[] L1=CombinCrit1.split(" ");////System.out.println(L1.length);
				String[] L2=CombinCrit2.split(" ");////System.out.println(L2.length);
				if(Ant1.equals(Ant2) && (Arrays.asList(L1).containsAll(Arrays.asList(L2))) && (Arrays.asList(L2).containsAll(Arrays.asList(L1))))
					index=i;
				i++;
			
			}
		}
		
		return index;
	}

	public static List<String> RemoveDuplicate(List<String> List){
		List<String> NewList=new ArrayList<String>();
		

		Iterator iterator = List.iterator();

		        while (iterator.hasNext())
		        {
		            String o = (String) iterator.next();
		            if(!NewList.contains(o)) NewList.add(o);
		        }
		return NewList;
	}
	public static List<String> AllTerminalState(Double[][] MatriceQ,List<String> TabState,List<Antecedent>ListAntec, int NbCrit,int NbAct){
		List<String> TerminalStates=new ArrayList<String>();
		ArrayList<String> SelectedState=new ArrayList<String>();
		String action=new String();
		String state=new String();
		int index_state;
		int index_action;
		List<String> TabAct=TableAction(ListAntec.size(),NbCrit);
		
		for(int a=0;a<NbCrit*ListAntec.size();a++){
			SelectedState=new ArrayList<String>();
			action=TabAct.get(a);
			index_state=SearchIndexofState(action,TabState);
			//System.out.println("index state:"+index_state);
			state=IndexToState(index_state,TabState);//System.out.print("State init:"+state);
			SelectedState.add(state);
			int i=index_state;
			while(i<MatriceQ.length-1){
				index_action=ChoixAction(MatriceQ[i]);//System.out.println(" chosen action:"+TabAct.get(index_action));
				
				if(index_action==NbAct-1){
					index_state=MatriceQ.length-1;		//Passage � l'�tat final
					state="SF";
				}
				else {
					state=state+" "+Integer.toString(index_action-(NbCrit*ListAntec.size())+1);//Ss=Scour+" "+TabAct.get(Ac_Index);
					//System.out.println("state suiv"+state);
					index_state=SearchIndexofState(state,TabState);
					state=IndexToState(index_state,TabState);
				}
				//System.out.print("State current:"+state);
				SelectedState.add(state);
				//System.out.println(" index State suiv:"+index_state+"-->"+state);
				i=index_state;
			}
			TerminalStates.add(SelectedState.get(SelectedState.size()-2));
		}
		
		return TerminalStates;
	}
	public static List<String> ChoiceAllBestState(Double[][] MatriceQ,List<String> TabState,List<Antecedent>ListAntec, int NbCrit,int NbAct){
		List<String> BestStates=new ArrayList<String>();
		List<String> AllBestState=new ArrayList<String>();
		ArrayList<String> SelectedState=new ArrayList<String>();
		ArrayList<Double> SelectedQvalue=new ArrayList<Double>();
		String action=new String();
		String state=new String();
		int index_state;
		int index_action;
		double SumQvalue=0;
		List<String> TabAct=TableAction(ListAntec.size(),NbCrit);
		
		for(int a=0;a<NbCrit*ListAntec.size();a++){
			SumQvalue=0;
			SelectedState=new ArrayList<String>();
			action=TabAct.get(a);
			index_state=SearchIndexofState(action,TabState);
			//System.out.println("index state:"+index_state);
			state=IndexToState(index_state,TabState);//System.out.print("State init:"+state);
			SelectedState.add(state);
			int i=index_state;
			while(i<MatriceQ.length-1){
				index_action=ChoixAction(MatriceQ[i]);//System.out.println(" chosen action:"+TabAct.get(index_action));
				SumQvalue=SumQvalue+MatriceQ[i][index_action];
				if(index_action==NbAct-1){
					index_state=MatriceQ.length-1;		//Passage � l'�tat final
					state="SF";
				}
				else {
					state=state+" "+Integer.toString(index_action-(NbCrit*ListAntec.size())+1);//Ss=Scour+" "+TabAct.get(Ac_Index);
					////System.out.println("state suiv"+state);
					index_state=SearchIndexofState(state,TabState);
					state=IndexToState(index_state,TabState);
				}
				////System.out.print("State current:"+state);
				SelectedState.add(state);
				////System.out.println(" index State suiv:"+index_state+"-->"+state);
				i=index_state;
			}
			AllBestState.add(SelectedState.get(SelectedState.size()-2));
			SelectedQvalue.add(SumQvalue);
		}
		
		/*//System.out.println("Affichage des meilleurs �tats avant ordre");
		for(int j=0;j<AllBestState.size();j++){
			//System.out.println("State "+j+":"+AllBestState.get(j)+" Qmax="+SelectedQvalue.get(j));
		}*/

		//BestStates=BubbleSort(AllBestState,SelectedQvalue);
		
		double SumQmax=SelectedQvalue.get(0);
		for(int x=1;x<SelectedQvalue.size();x++){
			if(SumQmax<SelectedQvalue.get(x)){
				SumQmax=SelectedQvalue.get(x);
			}			
		}
		
		for(int y=0;y<AllBestState.size();y++){
			if(SelectedQvalue.get(y)==SumQmax){
				BestStates.add(AllBestState.get(y));
			}			
		}
		//System.out.println("Affichage des meilleurs �tats");
		for(int j=0;j<BestStates.size();j++){
			//System.out.println("State "+j+":"+BestStates.get(j)+" Qmax="+SelectedQvalue.get(j));
		}
		
		
		
		return BestStates;
	}
	public static String[][] ExtractAllBestState(Double[][] MatriceQ,List<String> TabState,List<Antecedent>ListAntec, int NbCrit,int NbAct){
		
		List<String> AllBestState=new ArrayList<String>();
		ArrayList<String> SelectedState=new ArrayList<String>();
		ArrayList<Double> SelectedQvalue=new ArrayList<Double>();
		String action=new String();
		String state=new String();
		int index_state;
		int index_action;
		double SumQvalue=0;
		List<String> TabAct=TableAction(ListAntec.size(),NbCrit);
		
		for(int a=0;a<NbCrit*ListAntec.size();a++){
			SumQvalue=0;
			SelectedState=new ArrayList<String>();
			action=TabAct.get(a);
			index_state=SearchIndexofState(action,TabState);
			//System.out.println("index state:"+index_state);
			state=IndexToState(index_state,TabState);//System.out.print("State init:"+state);
			SelectedState.add(state);
			int i=index_state;
			while(i<MatriceQ.length-1){
				index_action=ChoixAction(MatriceQ[i]);//System.out.println(" chosen action:"+TabAct.get(index_action));
				SumQvalue=SumQvalue+MatriceQ[i][index_action];
				if(index_action==NbAct-1){
					index_state=MatriceQ.length-1;		//Passage � l'�tat final
					state="SF";
				}
				else {
					state=state+" "+Integer.toString(index_action-(NbCrit*ListAntec.size())+1);//Ss=Scour+" "+TabAct.get(Ac_Index);
					////System.out.println("state suiv"+state);
					index_state=SearchIndexofState(state,TabState);
					state=IndexToState(index_state,TabState);
				}
				////System.out.print("State current:"+state);
				SelectedState.add(state);
				////System.out.println(" index State suiv:"+index_state+"-->"+state);
				i=index_state;
			}
			AllBestState.add(SelectedState.get(SelectedState.size()-2));
			SelectedQvalue.add(SumQvalue);
		}
		
		String[][] BestStates=new String[2][AllBestState.size()];
		
		for(int j=0;j<AllBestState.size();j++){
			BestStates[0][j]=AllBestState.get(j);
			BestStates[1][j]=Double.toString(SelectedQvalue.get(j));
			//System.out.println("Sate:"+AllBestState.get(j)+" Qmax:"+SelectedQvalue.get(j) );
		}
		
		return BestStates;
	}
	 public static List<String> BubbleSort (List<String> ListAnt,List<Double> SelectedQvalue) { //I tried to use the same
	                                                    //approach just with the List
	        int firstLoopCount = 0;
	        int SecLoopCount = 0;
	        for (int i=0; i<ListAnt.size()-1; i++) {
	            firstLoopCount++;
	            ////System.out.println(Arrays.toString(empList) + i + " << First Loop interation");

	           for (int j=0; j<ListAnt.size()-1; j++) {
	               if (SelectedQvalue.get(j) > SelectedQvalue.get(j+1)) {    //I get errors here in Eclipse and 
	            	   ListAnt.add(j, ListAnt.get(j + 1));
	            	   ListAnt.remove(j + 1);
	                }
	               SecLoopCount++;
	             

	           }
	        }
	        ////System.out.println((firstLoopCount+SecLoopCount));
	        return ListAnt;

	    }
	public static String ChoiceBestState(Double[][] MatriceQ,List<String> TabState,List<Antecedent>ListAntec, int NbCrit,int NbAct){
		String BestState=new String();
		ArrayList<String> SelectedState=new ArrayList<String>();
		ArrayList<Integer> SelectedCrit=new ArrayList<Integer>();
		
		List<String> TabAct=TableAction(ListAntec.size(),NbCrit);
		int i;
		int Ac_Index;
		int Ss_Index;
		String Scour;
		String Ssuiv;
		String Ss;
		//int pas=0;
		Scour="";
		Ac_Index=ChoixAction(MatriceQ[0]);//System.out.println(" chosen action for initial state:"+Ac_Index);
		SelectedCrit.add(Ac_Index);
		if(Ac_Index>NbCrit*ListAntec.size()){
			//System.out.println("Attention!!!!!!!!!!!! Verifier la matrice R -- Passage directe � l'�tat final!");
			Random random1 = new Random();
			Ac_Index = random1.nextInt(NbCrit*ListAntec.size());	//Choix al�atoire d'une action possible autre que l'action finale
			Ss=TabAct.get(Ac_Index);//Ss=IndexToState(Ss_Index,TabState);
			Ss_Index=SearchIndexofState(Ss,TabState);
			//System.out.println("index action="+Ac_Index+" "+Ss+" index �tat="+Ss_Index);
		}
		else {Ss=TabAct.get(Ac_Index);Ss_Index=SearchIndexofState(Ss,TabState);}
		i=Ss_Index;
		while(i<MatriceQ.length-1 ){ 	// ){&& pas <MatriceQ.length
			Scour=IndexToState(i,TabState);////System.out.print("State current:"+Scour);
			SelectedState.add(Ss);
			Ac_Index=ChoixAction(MatriceQ[i]);////System.out.println(" chosen action:"+TabAct.get(Ac_Index));
			SelectedCrit.add(Ac_Index);
			if(Ac_Index==NbAct-1){
				Ss_Index=MatriceQ.length-1;		//Passage � l'�tat final
				Ss="SF";
			}
			else {
				Ss=Scour+" "+Integer.toString(Ac_Index-(NbCrit*ListAntec.size())+1);//Ss=Scour+" "+TabAct.get(Ac_Index);
				////System.out.println("state suiv"+Ss);
				Ss_Index=SearchIndexofState(Ss,TabState);
			}
			////System.out.println(" index State suiv:"+Ss_Index+"-->"+IndexToState(Ss_Index,TabState)+" verif:"+Ss);
			i=Ss_Index;
			//pas++;
		}
		////System.out.println("nbr crit choisie:"+SelectedCrit.size());
		BestState=SelectedState.get(SelectedState.size()-1);  //la combin de crit�re final est l'�l�ment avant dernier (�tat final) de la liste SelectedCombinCrit
	
		return BestState;
	}
	
	public static void DisplayMatrix(Double[][] Matrice){
		for(int i=0;i<Matrice.length;i++){
			for(int j=0;j<Matrice[i].length;j++){
				//System.out.print(Matrice[i][j]);
				////System.out.print(Math.round(Matrice[i][j] * 100d) / 100d+" ");
				//DecimalFormat df = new DecimalFormat("#.##");
				//DecimalFormat df = new DecimalFormat();
			    //df.setMinimumFractionDigits(2);
				////System.out.printf("%.2f",df.format(Matrice[i][j])+" ");
			}
			//System.out.println();
		}
	}
	public static void DisplayTable(Integer[] Table){
		//System.out.println("******Afficher table ************");
		for(int i=0;i<Table.length;i++){
			//System.out.print(Table[i]+" ");
		}
		//System.out.println();
	}
	public static void DisplayList(List<String> List){
		//System.out.println("******Afficher list ************");
		for(int i=0;i<List.size();i++){
			//System.out.print(List.get(i)+" ");
		}
		//System.out.println();
	}
	public static int ChoixAction(Double[] MQL){
		int index=1;
		Double Qval=MQL[0];
		for(int j=0;j<MQL.length;j++){
			if(MQL[j]>=Qval){
				index=j;
				Qval=MQL[j];
			}
		}
		return index;
	}
	public static int ChoixCombin(int i,Double[] MQL){
		int index=1;
		Double Qval=MQL[1];
		int size;
		if(i==0)
			size=MQL.length-2;
		else
			size=MQL.length;
		
		for(int j=2;j<size;j++){
			if(MQL[j]>=Qval)
				index=j;
		}
		return index;
	}
	public static ArrayList<Integer> PossibleActions(int S0Index,Double[][] MatriceR){
		ArrayList<Integer> PossibActions=new ArrayList<Integer>();
		for(int j=0;j<MatriceR[S0Index].length;j++){
			if(MatriceR[S0Index][j]!=(double)-1){
				PossibActions.add(j);
			}
		}
		
		return PossibActions;
	}
	
	public static double Qsuiv_Max(Double[][]MatriceQ,int Ssuiv_Index){
		double Qmax=0;
		Qmax=MatriceQ[Ssuiv_Index][0];
		for(int j=0;j<MatriceQ[Ssuiv_Index].length;j++){
			if(MatriceQ[Ssuiv_Index][j]>Qmax)
				Qmax=MatriceQ[Ssuiv_Index][j];
		}
		return Qmax;
	}
	
	public static String IndexToState(int index,List<String> TabState ){
		String stat=new String();
		if (index==0)
			stat="S0";
		else if(index==TabState.size()-1)
			stat="SF";
		else
			stat= TabState.get(index);					//initialisation de l'�tat initial S0
		return stat;
	}
	public static String TypeCandidat(String Vg){
		String type=new String();
		if(Vg.equals("19")||Vg.equals("20")||
				Vg.equals("21")||Vg.equals("22")||
				Vg.equals("23")||Vg.equals("24"))
			type="Nom_ville_ou_pays";
			
		else if (Vg.equals("33")||Vg.equals("34")||
				Vg.equals("35")||Vg.equals("36")||
				Vg.equals("37")||Vg.equals("38"))
			type="Nom_propre";
		
		else if (Vg.equals("39")||Vg.equals("40")||
				Vg.equals("41"))
			type="Nom_verbal";	
		
		else if (Vg.equals("42")||Vg.equals("43")||
				Vg.equals("44")||Vg.equals("45")||
				Vg.equals("46")||Vg.equals("47")||Vg.equals("51")||
				Vg.equals("52")||Vg.equals("53"))
			type="Nom_indefini";
		
		else if (Vg.equals("48")||Vg.equals("49")||
				Vg.equals("50"))
			type="Nom_defini";
		
		else if(Vg.equals("192"))
			type="Compose";
		
		else if(Vg.equals("193")||Vg.equals("194")||
				Vg.equals("195")||Vg.equals("196")||
				Vg.equals("197"))
			type="Complement";
		
		else if((Vg.equals("60")||Vg.equals("61")||
				Vg.equals("62")) && !(Vg.equals("VuW")||Vg.equals("VlT")))
			type="les_5_noms";
		
		else if(EstunAdjectif(Vg))
			type="Adjectif";
		else type="";
			
			return type;
	}
	public static boolean EstunAdjectif(String valeurGr){
		boolean verif=false;
		////System.out.println("vg "+Integer.parseInt(valeurGr));
		int vg=Integer.parseInt(valeurGr);
		if(Integer.parseInt(valeurGr)>=198 && Integer.parseInt(valeurGr)<=220)
			verif=true;
		return verif;
	}
}
