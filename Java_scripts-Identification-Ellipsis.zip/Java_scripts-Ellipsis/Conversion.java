package Detection_Resolution_Ellipse;




/**
 * <p>Titre : </p>
 * <p>Description : </p>
 * <p>Copyright : Copyright (c) 2009</p>
 * <p>Soci�t� : </p>
 * @author non attribuable
 * @version 1.0
 */

import java.lang.*;
import java.awt.ComponentOrientation;


public class Conversion {
	public static void main(String[] args){
		String cc="lLVY";
		System.out.println(transtowin(cc));
	}
  public static String transtowin (String chSrc )
         {
                 char [] Tran2Win =
 {

//         0      1      2      3      4      5      6      7      8      9      A      B      C      D      E      F

 /* 0 */ 0x00 , 0x01 , 0x02 , 0x03 , 0x04 , 0x05 , 0x06 , 0x07 , 0x08 , 0x09 , 0x0A , 0x0B , 0x0C , 0x0D , 0x0E , 0x0F ,
 /* 1 */ 0x10 , 0x11 , 0x12 , 0x13 , 0x14 , 0x15 , 0x16 , 0x17 , 0x18 , 0x19 , 0x1A , 0x1B , 0x1C , 0x1D , 0x1E , 0x1F ,
 /* 2 */ 0x20 , 0x21 , 0x22 , 0x23 , 0x24 , 0x25 , 0x26 , 0x27 , 0x29 , 0x28 , 0x2A , 0x2B , 0x60C, 0x2D , 0x2E , 0x5C ,
 /* 3 */ 0x30 , 0x31 , 0x32 , 0x33 , 0x34 , 0x35 , 0x36 , 0x37 , 0x38 , 0x39 , 0x3A , 0x61B, 0x3E , 0x3D , 0x3C , 0x61F,

 /* 4 */ 0x40 , 0x41 , 0x628, 0x62B, 0x637, 0x622, 0x641, 0x626, 0x62D, 0x49 , 0x62C, 0x4B , 0x644, 0x645, 0x646, 0x4F ,
 /* 5 */ 0xD0 , 0x642, 0x63A, 0x634, 0x62A, 0x55 , 0x630, 0x648, 0x58 , 0x64A, 0x632, 0x5B , 0x5C , 0x5D , 0x5E , 0x640,
 /* 6 */ 0x60 , 0x64E, 0x638, 0x63 , 0x62F, 0x621, 0x66 , 0x639, 0x647, 0x650, 0x64C, 0x643, 0x627, 0x6D , 0x6E , 0x652,
 /* 7 */ 0x636, 0x62E, 0x631, 0x633, 0x629, 0x64F, 0x76 , 0x651, 0x64D, 0x649, 0x64B, 0x7B , 0x7C , 0x7D , 0x7E , 0x7F ,

 /* 8 */ 0x80 , 0x81 , 0xC5 , 0x83 , 0x84 , 0x85 , 0x86 , 0xD5 , 0x88 , 0x89 , 0xC3 , 0x8B , 0x8C , 0x8D , 0x8E , 0x8F ,
 /* 9 */ 0x90 , 0x91 , 0x92 , 0x93 , 0x94 , 0x95 , 0x96 , 0xC4 , 0x98 , 0x99 , 0x9A , 0x9B , 0x9C , 0x9D , 0x9E , 0x9F ,
 /* A */ 0xA0 , 0xA1 , 0xA2 , 0xA3 , 0xA4 , 0xA5 , 0xA6 , 0xA7 , 0xA8 , 0xA9 , 0xAA , 0xAB , 0xAC , 0xAD , 0xAE , 0xAF ,
 /* B */ 0xB0 , 0xB1 , 0xB2 , 0xB3 , 0xB4 , 0xB5 , 0xB6 , 0xB7 , 0xB8 , 0xB9 , 0xBA , 0xBB , 0xBC , 0xBD , 0xBE , 0xBF ,

 /* C */ 0xC0 , 0xC1 , 0xC2 , 0xC3 , 0xC4 , 0xC5 , 0xC6 , 0xC7 , 0xC8 , 0xC9 , 0xCA , 0xCB , 0xCC , 0xCD , 0xCE , 0xCF ,
 /* D */ 0xD0 , 0xD1 , 0xD2 , 0xD3 , 0xD4 , 0xD5 , 0xD6 , 0xD7 , 0xD8 , 0xD9 , 0xDA , 0xDB , 0xDC , 0xDD , 0xDE , 0xDF ,
 /* E */ 0xE0 , 0xE1 , 0xE2 , 0xE3 , 0xE4 , 0xE5 , 0xE6 , 0x635, 0x623, 0x625, 0xEA , 0xEB , 0xEC , 0xED , 0xEE , 0xEF ,
 /* F */ 0xF0 , 0xF1 , 0xF2 , 0xF3 , 0xF4 , 0xF5 , 0xF6 , 0xF7 , 0xF8 , 0x624, 0xFA , 0xFB , 0xFC , 0xFD , 0xFE , 0xFF
 };

                 String chDest= "";
                 String chDesti= "";// chaine destination interm�diaire
                 String temp = "";



                 
                 for (int i=0 ; i < chSrc.length(); i++)
                 {
                	 
                         switch (chSrc.charAt(i))
                         {
                                 case 'v':
                                  chDesti += "w";
                          chDesti += "z";
                                  break;

                                 case 'm':
                                  chDesti += "w";
                          chDesti += "j";
                                  break;

                                 case 'n':
                                  chDesti += "w";
                          chDesti += "x";
                          break;

                                 case 'A':
                                  chDesti += "w";
                          chDesti += "a";
                                 break;

                                 case 'U':
                          chDesti += "w";
                          chDesti += "u";
                                 break;

                                 case 'I':
                                   chDesti += "w";
                                   chDesti += "i";
                                 break;

                                 default:
                           chDesti += chSrc.charAt(i);
                         }
                 }

                 chSrc = chDesti;

                 StringBuffer s = new StringBuffer(chSrc);


                  for (int i=0; i<chSrc.length();i++)
                  {
                                if((s.length()-i)+1>3)
                                {

                                 if ( (s.charAt(i) == 'L') &&
                                 ((s.charAt (i+1) == 'z') ||(s.charAt (i+1) == 'a') ) && (s.charAt (i+2) == 'l') )
                                 {
                                         s.setCharAt(i+2, s.charAt(i+1));
                                         s.setCharAt(i+1,  'l');
                                 }
                                }
                                if((s.length()-i)+1>4)
                                {

                            if ((s.charAt(i) == 'L') &&
                                    (s.charAt(i+1) == 'w') && (s.charAt(i+3) == 'l') )
                                 {
                                    s.setCharAt(i+3, s.charAt(i+2));
                                    s.setCharAt(i+2, s.charAt(i+1));
                                    s.setCharAt(i+1, 'l');

                                 }
                                }

                                 chSrc = new String(s);
                                 chDest  += Tran2Win [chSrc.charAt(i)];
                 }


                 return (chDest);
         }
}
