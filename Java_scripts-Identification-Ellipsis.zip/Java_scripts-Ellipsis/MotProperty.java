package Detection_Resolution_Ellipse;
 
public class MotProperty {
	
	private String vg;
	private String rad;
	private String val;
	private String genr;
	private String nbr;
	private String vgenc;
	private String valenc;
	private String genrenc;
	private String nbrenc;
	private String vgproc;
	
	public MotProperty(String Vg, String Val, String Rad, String Genr,String Nbr,String Vgenc,String Valenc, String Genenc, String Nbrenc,String Vgproc){
		this.vg=Vg;
		this.val=Val;
		this.rad=Rad;
		this.genr=Genr;
		this.nbr=Nbr;
		this.vgenc=Vgenc;
		this.valenc=Valenc;
		this.genrenc=Genenc;
		this.nbrenc=Nbrenc;
		this.vgproc=Vgproc;
	}

	public String getVg() {
		return vg;
	}

	public void setVg(String vg) {
		this.vg = vg;
	}

	public String getVal() {
		return val;
	}

	public void setVal(String val) {
		this.val = val;
	}

	public String getRad() {
		return rad;
	}

	public void setRad(String rad) {
		this.rad = rad;
	}

	public String getGenr() {
		return genr;
	}

	public void setGenr(String genr) {
		this.genr = genr;
	}

	public String getNbr() {
		return nbr;
	}

	public void setNbr(String nbr) {
		this.nbr = nbr;
	}

	public String getVgenc() {
		return vgenc;
	}

	public void setVgenc(String vgenc) {
		this.vgenc = vgenc;
	}

	public String getValenc() {
		return valenc;
	}

	public void setValenc(String valenc) {
		this.valenc = valenc;
	}

	public String getGenrenc() {
		return genrenc;
	}

	public void setGenrenc(String genrenc) {
		this.genrenc = genrenc;
	}

	public String getNbrenc() {
		return nbrenc;
	}

	public void setNbrenc(String nbrenc) {
		this.nbrenc = nbrenc;
	}

	public String getVgproc() {
		return vgproc;
	}

	public void setVgproc(String vgproc) {
		this.vgproc = vgproc;
	}

	
}
