package Detection_Resolution_Ellipse;

public class Critere {
	private int num;
	private String typeCritere;
	private String NomArabe;
	private float scoreRecompense;
	private float scorePunition;
	private int[] scoreDistance;
	
	public Critere(){	
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getTypeCritere() {
		return typeCritere;
	}

	public void setTypeCritere(String typeCritere) {
		this.typeCritere = typeCritere;
	}

	public float getScoreRecompense() {
		return scoreRecompense;
	}

	public void setScoreRecompense(float scoreRecompense) {
		this.scoreRecompense = scoreRecompense;
	}

	public float getScorePunition() {
		return scorePunition;
	}

	public void setScorePunition(float scorePunition) {
		this.scorePunition = scorePunition;
	}
	public int[] getScoreDistance() {
		return scoreDistance;
	}

	public void setScoreDistance(int[] scoreDistance) {
		this.scoreDistance = scoreDistance;
	}

	public String getNomArabe() {
		return NomArabe;
	}

	public void setNomArabe(String nomArabe) {
		NomArabe = nomArabe;
	}
	
}
