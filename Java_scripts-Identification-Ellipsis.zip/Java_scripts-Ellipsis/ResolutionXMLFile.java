package Detection_Resolution_Ellipse;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;




public class ResolutionXMLFile {
	public static void main(String[] args) throws InterruptedException {
		Texte txt=new Texte();
		
		//String NameFile="fichierResultat1.xml";		
		//String NameFile="fichierResultat2.xml";
		//String NameFile="fichierResultat3.xml";
		//String NameFile="fichierResultat4.xml";
		//String NameFile="fichierResultat5V1.xml";
		//String NameFile="texteE2SegEtiqAnaphEllip.xml";
		//String NameFile="texteE4SegEtiqAnaphEllip.xml";
		//String NameFile="texteE6SegEtiqAnaphEllip.xml";
		//String NameFile="texteM1_1SegEtiqAnaphEllip.xml";
		//String NameFile="texteM1_2SegEtiqAnaphEllip.xml";
		//String NameFile="texteM3SegEtiqAnaphEllip.xml";
		String NameFile="texteM4SegEtiqAnaphEllip.xml";
		AjouterAntecedent(NameFile,0);
	}
	
	
	public static String AjouterAntecedent(String NameFile,int numfile) throws InterruptedException{
		String update=new String();
		String model=LectureFichierTexte.LectureParametres("Input.txt").get(16);
	  try { 
		  String bestCrit=new String();
		  String bestCombinCrit=new String();
		  List ListMotsPreEllipse=new ArrayList<String>();
		SAXBuilder builder = new SAXBuilder();
		String texte = NameFile.substring(0,NameFile.indexOf("."));
		//String FileRes=texte+"ResoluW2V_Param"+numfile+".xml";
		String FileRes=texte+"Resolu.xml";
		int indexEllip=-1;
		//String FileRes=texte+"ResCritDist.xml";
		//String FileRes="test1SegV3ResCritDist.xml";
		//String FileRes="test2SegV4ResCritDist.xml";
		//String FileRes="test3SegV3ResCritDist.xml";
		//String FileRes="test4SegV2ResCritDist.xml";
		
		
		//String FileRes="test5SegV3ResSansProba.xml";
		//String FileRes="Corpus2Text2V1ResSansProba.xml";
		System.out.println("fichier resultat "+FileRes);
		File xmlFile = new File(FileRes);
		Document doc = (Document) builder.build(xmlFile);
		Element rootNode = doc.getRootElement();
 
		Texte txt=new Texte();
		
		System.out.println("R�solution en cours... Veuillez attendre");
		//String NameFileEtiq=NameFile.substring(0,NameFile.indexOf("."))+"EtiqAnaph.xml";
		String NameFileEtiq=NameFile;
		//List<AnaphCandidat> ListResolu=Resolution.ResolutionText2(NameFileEtiq);	//Resolution du texte
		//List<AnaphCandidat> ListResolu=ResolutionBaseline.ResolutionBasique1(NameFileEtiq);
		//List<AnaphCandidat> ListResolu=ResolutionBaseline.ResolutionBasiqueMeilleurCombin(NameFileEtiq);
		
		//Methode Qlearning
		//List<Ellipse_Candidat> ListResolu=ResolutionQlearning.ResolutionText(NameFileEtiq);
		
		//Methode WordEmbedding
		//List<Ellipse_Candidat> ListResolu=ResolutionWordEmbedding.ResolutionTextW2V_FastText(NameFileEtiq,model);
		//List<Ellipse_Candidat> ListResolu=ResolutionWordEmbedding.ResolutionTextBert(NameFileEtiq);
		List<Ellipse_Candidat> ListResolu=ResolutionWordEmbedding.ResolutionText_TrainModel_W2V_Bert_ou_FastText_ParamTuning(NameFileEtiq);
		
		//Methode combin Qlearning WordEmbedding
		//List<Ellipse_Candidat> ListResolu=ResolutionCombin_Qlearning_WordEmbedd.ResolutionText(NameFileEtiq,model);
		
		
		System.out.println("***Afficher list ellipse meilleur antecedent***");
		for(int i=0;i<ListResolu.size();i++){
			System.out.println("Ellip:"+ListResolu.get(i).Inst_Ellipse.getValVerbGouv()+" Antecedent:"+ListResolu.get(i).BestAntec.getValeur());
		}
		System.out.println("Enregistrement des r�sultats");
		List parags=rootNode.getChildren("Paragraphe"); 
		//System.out.println("taillparag "+parags.size());
		for(int p=0;p<parags.size();p++){
			Element parag=(Element)parags.get(p);
			List phrs=parag.getChildren("Phrase");
			//System.out.println("taillphr "+phrs.size());
			for(int ph=0;ph<phrs.size();ph++){
				//System.out.println("num phrase "+ph);
				Element phr=(Element)phrs.get(ph);
				List Ellipses=phr.getChild("Ellipses").getChildren("Ellipse");
				ListMotsPreEllipse=MethodesDivers.ExtraireMotsGouvEllipse(Ellipses);	
				//System.out.println("taille list verb gouv:"+ListMotsPreEllipse);
				Element EllipsesResol=new Element("EllipsesResol");
				phr.addContent(EllipsesResol);
				List syntags=phr.getChildren();
				//System.out.println("taillsyntag "+syntags.size());
				for(int sy=0;sy<syntags.size();sy++){
					Element syntag=(Element)syntags.get(sy);
					if(!syntag.getName().equals("Ponctuation")&&!syntag.getName().equals("Ellipses")&&!syntag.getName().equals("ArbreDerivation")){
						List mots=syntag.getChildren();
						//System.out.println("taillmot "+mots.size());
						for(int m=0;m<mots.size();m++){
							Element mot=(Element)mots.get(m);
							if(mot.getName().startsWith("M")||mot.getName().startsWith("S")){
								List Autremots=mot.getChildren("Mot");
								System.out.println("mot "+mot.getAttributeValue("valeur"));
								if(Autremots.size()==0){
									Mot word=new Mot();
									word.mot=mot;
									if(!MethodesDivers.TypeVerbe(word.ExtraireVGRad()).equals("")){
										//System.out.println("mot courant:"+word.ExtraireValeur()+" indice mot:"+m+" vg courant:"+word.ExtraireVGRad());													
										if(MethodesDivers.AppartientListe(ListMotsPreEllipse,word.ExtraireValeur())){							
											System.out.println("******************nouvelle instance ellipse sujet");
											indexEllip++;
											//System.out.println(mot.getAttributeValue("valeur")+" "+word.ExtraireValeur());									
											Element EllipResol=new Element("Ellipse");
											EllipsesResol.addContent(EllipResol);											
											//Antecedent Ant=BestAntecedent(word,ListResolu,p,ph);
											//if(indexEllip<ListResolu.size()){
												Antecedent Ant=ListResolu.get(indexEllip).getBestAntec();
												if(!Ant.getValeur().equals("")){
													System.out.println("existe best antecedent");
													bestCrit=BestCriteria(word,ListResolu,p,ph);
													EllipResol.setAttribute("Verbe_gouvernant", word.ExtraireValeur());
													EllipResol.setAttribute("BestAnteced", Ant.getValeur());
													EllipResol.setAttribute("numPhrase",Integer.toString(Ant.getNumPh()));
													EllipResol.setAttribute("numMot", Ant.getNumMot());
													if(!bestCrit.equals(null))
														EllipResol.setAttribute("CombinCrit",bestCrit );
													EllipResol.setAttribute("Score", Double.toString(Ant.getScore()));
													EllipResol.setAttribute("distance", Integer.toString(Ant.getDistance()));													
													//EllipResol.setAttribute("Vote1", Integer.toString(Ant.getVote1()));
													//EllipResol.setAttribute("Vote2", Integer.toString(Ant.getVote2()));
													EllipResol.setAttribute("Vote", Integer.toString(Ant.getVote()));
													EllipResol.setAttribute("Similarity", Double.toString(Ant.getValSimilarity()));
													//EllipResol.setAttribute("Rang", Integer.toString(Ant.getRang()));
													//Element candidats = new Element("ListCandidats");
													//EllipResol.addContent(candidats);
													//bestCrit=BestCriteria(word,ListResolu,p,ph);
													//candidats.setAttribute("MeilleurCrit", bestCrit);
																						
													//System.out.println("candidat "+lc.get(c).getValeur());
													//List<Antecedent> lc=ListeCandidat(word,ListResolu,p,ph);
													//List<Antecedent> lc=ListAntecedent(word,ListResolu,p,ph);
													List<Antecedent> lc=ListResolu.get(indexEllip).getListCandOrdonnees();
													if(lc.size()!=0){
														for(int c=0;c<lc.size();c++){
															System.out.println("existe liste antecedents");
															Element cand=new Element("Candidat");
															EllipResol.addContent(cand);
															cand.setAttribute("val", lc.get(c).getValeur());
															cand.setAttribute("numPhrase",Integer.toString(lc.get(c).getNumPh()));
															cand.setAttribute("numMot", lc.get(c).getNumMot());
															//cand.setAttribute("CombinCrit", lc.get(c).getCombinaisonCritere());
															//cand.setAttribute("Score", Double.toString(lc.get(c).getScore()));
															cand.setAttribute("dist", Integer.toString(lc.get(c).getDistance()));
															cand.setAttribute("score", Double.toString(lc.get(c).getScore()));
															cand.setAttribute("scoreBase", Double.toString(lc.get(c).getScorebase()));
															//if(!lc.get(c).getCritVerif().equals(null))
																//cand.setAttribute("CritVerif", lc.get(c).getCritVerif());
															//cand.setAttribute("scorebase", Double.toString(lc.get(c).getScorebase()));
															//cand.setAttribute("Vote1", Integer.toString(lc.get(c).getVote1()));
															//cand.setAttribute("Vote2", Integer.toString(lc.get(c).getVote2()));
															cand.setAttribute("Vote", Integer.toString(lc.get(c).getVote()));
															cand.setAttribute("Similarity", Double.toString(lc.get(c).getValSimilarity()));
															//cand.setAttribute("Rang", Integer.toString(lc.get(c).getRang()));
														}
													}
												}
											//}
										}
									}
								}
								else{
									for(int a=0;a<Autremots.size();a++){
										//System.out.println("n parag:"+p);
										//System.out.println("n phrase:"+ph);
										Element Autremot=(Element)Autremots.get(a);
										Mot word=new Mot();
										word.mot=Autremot;
										if(!MethodesDivers.TypeVerbe(word.ExtraireVGRad()).equals("")){
											////System.out.println("mot courant:"+m.ExtraireValeur()+" indice mot:"+k+" vg courant:"+m.ExtraireVGRad());													
											if(MethodesDivers.AppartientListe(ListMotsPreEllipse,word.ExtraireValeur())){							
												//System.out.println("******************nouvelle instance ellipse sujet");
												indexEllip++;
												System.out.println("autres mots"+mot.getAttributeValue("valeur")+" "+word.ExtraireValeur());
												Element EllipResol=new Element("Ellipse");
												EllipsesResol.addContent(EllipResol);												
												//Antecedent Ant=BestAntecedent(word,ListResolu,p,ph);
												//if(indexEllip<ListResolu.size()){
													Antecedent Ant=ListResolu.get(indexEllip).getBestAntec();
													if(!Ant.getValeur().equals("")){
														bestCrit=BestCriteria(word,ListResolu,p,ph);
														EllipResol.setAttribute("Verbe_gouvernant", word.ExtraireValeur());
														EllipResol.setAttribute("BestAnteced", Ant.getValeur());
														EllipResol.setAttribute("numPhrase",Integer.toString(Ant.getNumPh()));
														EllipResol.setAttribute("numMot", Ant.getNumMot());
														if(!bestCrit.equals(null))
															EllipResol.setAttribute("CombinCrit",bestCrit );
														EllipResol.setAttribute("Score", Double.toString(Ant.getScore()));
														EllipResol.setAttribute("distance", Integer.toString(Ant.getDistance()));
														//BestCand.setAttribute("Vote1", Integer.toString(Ant.getVote1()));
														//BestCand.setAttribute("Vote2", Integer.toString(Ant.getVote2()));
														EllipResol.setAttribute("Vote", Integer.toString(Ant.getVote()));
														EllipResol.setAttribute("Similarity", Double.toString(Ant.getValSimilarity()));
														//EllipResol.setAttribute("Rang", Integer.toString(Ant.getRang()));
														//Element candidats = new Element("ListCandidats");
														//EllipResol.addContent(candidats);
														//bestCrit=BestCriteria(word,ListResolu,p,ph);
														//candidats.setAttribute("MeilleurCrit", bestCrit);
																							
														//System.out.println("candidat "+lc.get(c).getValeur());
														//List<Antecedent> lc=ListeCandidat(word,ListResolu,p,ph);
														//List<Antecedent> lc=ListAntecedent(word,ListResolu,p,ph);
														List<Antecedent> lc=ListResolu.get(indexEllip).getListCandOrdonnees();
														if(lc.size()!=0){
															for(int c=0;c<lc.size();c++){
																Element cand=new Element("Candidat");
																EllipResol.addContent(cand);
																cand.setAttribute("val", lc.get(c).getValeur());
																cand.setAttribute("numPhrase",Integer.toString(lc.get(c).getNumPh()));
																cand.setAttribute("numMot", lc.get(c).getNumMot());
																//cand.setAttribute("CombinCrit", lc.get(c).getCombinaisonCritere());
																//cand.setAttribute("Score", Double.toString(lc.get(c).getScore()));
																cand.setAttribute("dist", Integer.toString(lc.get(c).getDistance()));
																cand.setAttribute("score", Double.toString(lc.get(c).getScore()));
																cand.setAttribute("scoreBase", Double.toString(lc.get(c).getScorebase()));
																//if(!lc.get(c).getCritVerif().equals(null))
																//	cand.setAttribute("CritVerif", lc.get(c).getCritVerif());
																//cand.setAttribute("scorebase", Double.toString(lc.get(c).getScorebase()));
																//cand.setAttribute("Vote1", Integer.toString(lc.get(c).getVote1()));
																//cand.setAttribute("Vote2", Integer.toString(lc.get(c).getVote2()));
																cand.setAttribute("Vote", Integer.toString(lc.get(c).getVote()));
																cand.setAttribute("Similarity", Double.toString(lc.get(c).getValSimilarity()));
																//cand.setAttribute("Rang", Integer.toString(lc.get(c).getRang()));
															}
														}
													}
												//}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		Format format = Format.getPrettyFormat();
        format.setEncoding("UTF-8");
		//format.setEncoding("ISO-8859-1");
        XMLOutputter xmlOutput = new XMLOutputter(format);
		
		// display nice nice
		//xmlOutput.setFormat(Format.getPrettyFormat());
		
		xmlOutput.output(doc, new FileWriter(FileRes));
		
		
        
		// xmlOutput.output(doc, System.out);
		update="update";
		System.out.println("File updated!");
	  } catch (IOException io) {
		io.printStackTrace();
	  } catch (JDOMException e) {
		e.printStackTrace();
	  }
	  return update;
	}
	
	  public static List<Antecedent> ListeCandidat(Mot mot,List<Ellipse_Candidat>ListResolu,int numparag,int numphr){
			List<Antecedent> Lc=new ArrayList<Antecedent>();
			String numMot=mot.ExtraireNum();
			//System.out.println("num mot "+numMot);
			boolean trouve=false;
			int i=0;
			while(i<ListResolu.size() && !trouve){
				InstanceEllipse ellip=ListResolu.get(i).getInst_Ellipse();
				if(ellip.getNumVerbeGouvernant()==Integer.parseInt(numMot) && ellip.getNumParag()==numparag && ellip.getNumPhrase()==numphr){
					trouve=true;
				}
				else
					i++;
			}
			if(trouve){
				Lc=ListResolu.get(i).getListCandOrdonnees();
			}
			return Lc;
		}
	public static Antecedent BestAntecedent(Mot mot,List<Ellipse_Candidat>ListResolu,int numparag,int numphr){
		Antecedent Ant=new Antecedent(0,"","","",0,0,"","","","");
		String numMot=mot.ExtraireNum();
		System.out.println("num mot "+numMot+" num phrase "+numphr+" num parag "+numparag);
		
		boolean trouve=false;
		int i=0;
		while(i<ListResolu.size() && !trouve){
			InstanceEllipse ellip=ListResolu.get(i).getInst_Ellipse();
			System.out.println("num verb gouv ellip "+ellip.getNumVerbeGouvernant()+" num phrase "+ellip.getNumPhrase()+" num parag "+ellip.getNumParag());
			if(ellip.getNumVerbeGouvernant()==Integer.parseInt(numMot)-1 && ellip.getNumParag()==numparag && ellip.getNumPhrase()==numphr){
				trouve=true;
			}
			else
				i++;
		}
		if(trouve){
			Ant=ListResolu.get(i).getBestAntec();
		}
		return Ant;
	}
	public static String BestCriteria(Mot mot,List<Ellipse_Candidat>ListResolu,int numparag,int numphr){
		String bestcrit=new String();
		bestcrit="";
		String numMot=mot.ExtraireNum();
		//System.out.println("num mot "+numMot+" val mot:"+mot.ExtraireValeur()+" numparag:"+numparag+" numphr:"+numphr);
		boolean trouve=false;
		int i=0;
		while(i<ListResolu.size() && !trouve){
			InstanceEllipse ellip=ListResolu.get(i).getInst_Ellipse();
			//System.out.println(ellip.getNumVerbeGouvernant()+" "+ellip.getNumParag()+" "+ellip.getNumPhrase());
			if(ellip.getNumVerbeGouvernant()==Integer.parseInt(numMot)-1 && ellip.getNumParag()==numparag && ellip.getNumPhrase()==numphr){
				trouve=true;
			}
			else
				i++;
		}
		if(trouve){
			bestcrit=ListResolu.get(i).Inst_Ellipse.getBestCrit();			
			//bestcrit=ListResolu.get(i).BestAntec.getBestCombinCrit();
		}
		if(bestcrit==null)
			bestcrit="";
		return bestcrit;
	}
	public static List<Antecedent> ListAntecedent(Mot mot,List<Ellipse_Candidat>ListResolu,int numparag,int numphr){
		List<Antecedent> ListAnt=new ArrayList<Antecedent>();
		//Antecedent Ant=new Antecedent(0,"","","",0,0,"","","","");
		String numMot=mot.ExtraireNum();
		//System.out.println("num mot "+numMot);
		boolean trouve=false;
		int i=0;
		while(i<ListResolu.size() && !trouve){
			InstanceEllipse ellip=ListResolu.get(i).getInst_Ellipse();
			if(ellip.getNumVerbeGouvernant()==Integer.parseInt(numMot)-1 && ellip.getNumParag()==numparag && ellip.getNumPhrase()==numphr){
				trouve=true;
			}
			else
				i++;
		}
		if(trouve){
			//ListAnt=ListResolu.get(i).getListeAnteced();
			ListAnt=ListResolu.get(i).getListCandOrdonnees();
		}
		System.out.println("list resolu "+ListAnt.size());
		return ListAnt;
	}
}