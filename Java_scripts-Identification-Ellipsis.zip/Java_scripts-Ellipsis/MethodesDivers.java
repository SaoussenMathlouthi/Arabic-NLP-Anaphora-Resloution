package Detection_Resolution_Ellipse;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.jdom2.Element;


public class MethodesDivers {

	/**
	 * @param args
	 */
	public static boolean EstunNomPropre(String ValGram){
		boolean test=false;
		int vg=Integer.parseInt(ValGram);
		if(vg>=33 && vg<=38)
			test=true;
		return test;
	}
	public static boolean EstunNomRelatif(String ValGram){
		boolean test=false;
		int vg=Integer.parseInt(ValGram);
		if(vg>=54 && vg<=57)
			test=true;
		return test;
	}
	public static List<Integer> RangeList(List<Double> List){
		List<Integer> ListRg=new ArrayList<Integer>();
		double ele;
		int rang;
		for(int i=0;i<List.size();i++){
			ele=List.get(i);
			rang=1;
			for(int j=0;j<List.size();j++){
				if(ele<List.get(j))
					rang++;
					
			}
			ListRg.add(rang);
		}
		return ListRg;
	}
	public static boolean EstUnePrepositionCirconst(String RadMot){
		boolean test=false;
		if(RadMot.equals("BaYoN")||RadMot.equals("ValT")||RadMot.equals("HiYN")||RadMot.equals("Bagop")
				||RadMot.equals("ValT")||RadMot.equals("JaMiYg"))
			test=true;
		return test;
	}
	public static List<String> ExtraireMotsGouvEllipse(List<Element> ellipses){
		List<String> ListMots=new ArrayList<String>();		
		
		////System.out.println("taille liste:"+ellipses.size());
		for(int i=0;i<ellipses.size();i++){
			Ellipse Elp=new Ellipse();
			Elp.ellipse=(Element) ellipses.get(i);
			////System.out.println("Elp:"+Elp.ExtraireType()+" "+Elp.ExtraireMotPreced());
			if(Elp.ExtraireType().equals("Sujet")||Elp.ExtraireType().equals("sujet")){
				ListMots.add(Elp.ExtraireMotPrecedouAvant());
			}
		}
		////System.out.println("Afficher Liste mots preced ellipse");
		//for(int a=0;a<ListMots.size();a++){
			////System.out.println(ListMots.get(a)+" ");
		//}
		return ListMots;
	}
	public static List<Antecedent> RechercheListAnteced(List<Ellipse_Candidat> List_Ellip_Cand,int numparag,int numphr,int numVerbgouv){
		List<Antecedent> ListAnteced=new ArrayList<Antecedent>();
		int i=0;
		boolean trouve=false;
		while(i<List_Ellip_Cand.size() && !trouve){
			if(List_Ellip_Cand.get(i).getInst_Ellipse().getNumParag()==numparag 
					&& List_Ellip_Cand.get(i).getInst_Ellipse().getNumPhrase()==numphr
					&& List_Ellip_Cand.get(i).getInst_Ellipse().getNumVerbeGouvernant()==numVerbgouv)
				trouve=true;
			else		//10/01/2020
				i++;
		}
		if(trouve)
			ListAnteced= List_Ellip_Cand.get(i).getListeAnteced();
		return ListAnteced;
	}
	public static InstanceEllipse RechercheEllipse(List<Ellipse_Candidat> List_Ellip_Cand,int numparag,int numphr,int numVerbgouv){
		InstanceEllipse Ellip=new InstanceEllipse(-1,"",-1,-1,-1,-1);
		int i=0;
		boolean trouve=false;
		while(i<List_Ellip_Cand.size() && !trouve){
			if(List_Ellip_Cand.get(i).getInst_Ellipse().getNumParag()==numparag 
					&& List_Ellip_Cand.get(i).getInst_Ellipse().getNumPhrase()==numphr
					&& List_Ellip_Cand.get(i).getInst_Ellipse().getNumVerbeGouvernant()==numVerbgouv)
				trouve=true;
			else	//10/01/2020
				i++;
		}
		if(trouve)
			Ellip=List_Ellip_Cand.get(i).getInst_Ellipse();
		return Ellip;
	}
	public static Ellipse ExtractionEllipse(Phrase ph, String VerbeGouv){
		Ellipse Ellip=new Ellipse();
		List ellipses;
		int i=0;
		boolean trouve=false;
		ellipses=ph.ExtraireEllipses();
		while(!trouve && i<ellipses.size()){
			Ellip=new Ellipse();
			Ellip.ellipse=(Element)ellipses.get(i);
			if(Ellip.ExtraireMotPrecedouAvant().equals(VerbeGouv))
				trouve=true;
			i++;
		}
				
		return Ellip;
	}
	public static Mot RechercheMot(Texte txt, int nmot,int nphr,int nparag){
		Mot mt=new Mot();
		List parags;
		List phs;
		List mots;
		Paragraphe parag=new Paragraphe();
		Phrase ph = new Phrase();
		
		if(nmot>=0){
			parags=txt.ExtractParagraphe();
			parag.paragraphe=(Element)parags.get(nparag);
			phs = parag.ExtrairePhrases();				
			ph.phrase=(Element)phs.get(nphr);
			mots=ph.ExtraireMots();
			mt.mot=(Element)mots.get(nmot);			
		}
		//System.out.println("mot :"+mt.ExtraireValeur());
		return mt;
	}
	public static Antecedent RechercheMotAntecedent(String NameFile,int numMotRepere, int nparag, int nphr, int distance){
		Antecedent Ant=new Antecedent(-1,"","","",-1,-1,"","","","");
		Texte txt = new Texte();
		Paragraphe parag=new Paragraphe();
		Phrase ph = new Phrase();
		//Syntagme s=new Syntagme();
		Mot mtAnteced=new Mot();
		Mot mt=new Mot();
		List parags;
		List phs;
		//List syntags;
		List mots;
		int i=numMotRepere;
		int p=nphr;
		int d=1;
		txt.nomfichier= NameFile;
		parags=txt.ExtractParagraphe();
		parag.paragraphe=(Element)parags.get(nparag);
		phs = parag.ExtrairePhrases();				
		ph.phrase=(Element)phs.get(nphr);
		mots=ph.ExtraireMots();
		////System.out.println(" p="+p);
		while(i>0 && d<distance){		//si l'antecedent est dans la même phrase que le mot repere(verbe gouvernant)
			i--;
			mt.mot=(Element)mots.get(i);															
			d++;
		}
		if(d<distance){
			//System.out.println("anteced dans les phrases precedente");
			p=nphr-1;
			while(p>=0 && d<distance){
				ph.phrase=(Element)phs.get(p);
				mots=ph.ExtraireMots();
				i=mots.size();
				while(i>0 && d<distance){
					i--;
					mt.mot=(Element)mots.get(i);														
					d++;
				}
				if(d<distance)
					p--;
			}
			
		}
		//else
			////System.out.println("anteced dans la premiere phrase");
		if (d==distance)
			mtAnteced.mot=(Element)mots.get(i);
		Ant=new Antecedent(0,mtAnteced.ExtraireValeur(),  mtAnteced.ExtraireVGRad(),  mtAnteced.ExtraireNum(),  
				p, nparag,mtAnteced.ExtraireGenre(), mtAnteced.ExtraireNombre(), mtAnteced.ExtraireRad(),"");
		Ant.setLemme(mtAnteced.ExtraireLem());
		Ant.setDistance(distance);
		//System.out.println("Ant: "+Ant.getValeur()+" num mot:"+Ant.getNumMot()+" num phr:"+Ant.getNumPh()+" num parag:"+Ant.getNumParag());
		
		return Ant;
	}
	public static Mot RechercheVerbeGouvAnteced(Antecedent motAnteced, Texte txt, int nparag){
		Mot VerbGouvAnteced=new Mot();
		Paragraphe parag=new Paragraphe();
		Phrase ph = new Phrase();
		//System.out.println("RechercheVerbeGouvAnteced:");
		//System.out.print("num parag mot anteced:"+nparag);
		//System.out.print(" num phrase mot anteced:"+motAnteced.getNumPh());
		//System.out.println(" num mot anteced:"+motAnteced.getNumMot());
		Mot mtAnteced=new Mot();
		Mot mt=new Mot();
		List parags;
		List phs;		
		List mots;
		int i=Integer.parseInt(motAnteced.getNumMot())-1;
		parags=txt.ExtractParagraphe();
		parag.paragraphe=(Element)parags.get(nparag);
		phs = parag.ExtrairePhrases();	
		ph.phrase=(Element)phs.get(motAnteced.getNumPh());
		//System.out.println("phrase "+Integer.toString(motAnteced.getNumPh()-1)+" :"+ph.TextePhrase());
		mots=ph.ExtraireMots();
		boolean trouve=false;
		while(i>0 && !trouve){		
			i--;
			mt.mot=(Element)mots.get(i);			
			if(!TypeVerbe(mt.ExtraireVGRad()).equals("")){
				trouve=true;
				VerbGouvAnteced=mt;
			}
		}
		//System.out.println("---verb gouv anteced:"+VerbGouvAnteced.ExtraireValeur());
		return VerbGouvAnteced;
	}
	
	public static int Distance_Ellipse_VerbeGouvernant(List phrs,int numphr, String Verbe){
		int dist=-1;
		List<String> ListMots=new ArrayList<String>();
		Phrase phr=new Phrase();
		phr.phrase=(Element)phrs.get(numphr);
		List ellipses=phr.ExtraireEllipses();
		int i=0;
		boolean trouve=false;
		while(!trouve && i<ellipses.size()){
			Ellipse Elp=new Ellipse();
			Elp.ellipse=(Element) ellipses.get(i);
			if(Elp.ExtraireMotPrecedouAvant().equals(Verbe)){
				trouve=true;
				if(Elp.ExtraireDistance().contains("-"))
					dist=Integer.parseInt(Elp.ExtraireDistance().substring(0, Elp.ExtraireDistance().indexOf("-")));
				else
					dist=Integer.parseInt(Elp.ExtraireDistance());
			}
			i++;
		}
		return dist;
	}
	public static boolean MotAnnexe(String ValGram){
		boolean trouve=false;
		if((ValGram.equals("193"))||(ValGram.equals("194"))||(ValGram.equals("195"))){
			trouve=true;
			////System.out.println("ok Ann");
		}
		return trouve;
	}
	public static boolean Nominatif(String vg ){
		boolean trouve=false;
		if(vg.equals("23")||vg.equals("34")||vg.equals("37")||vg.equals("44")||vg.equals("45")
				||vg.equals("49")||vg.equals("52")||vg.equals("61")||
				vg.equals("194")||vg.equals("202")){
			trouve=true;
		}
		return trouve;
	}
	public static int NombreRepetition(String racineMot,Texte txt, int NumParag,int NumPhr){
		int Nbr=0;
		Paragraphe parag=new Paragraphe();
		List parags = txt.ExtractParagraphe();
		parag.paragraphe=(Element)parags.get(NumParag);
		List phs=parag.ExtrairePhrases();
		//System.out.println("crit repetition");
		//System.out.println("taille:"+phs.size()+" numphr:"+NumPhr+" "+racineMot);
		for(int i=0;i<=NumPhr;i++){
			Phrase ph=new Phrase();
			ph.phrase=(Element)phs.get(i);
			List mots=ph.ExtraireMots();
			////System.out.println("taille mot:"+mots.size());
			for(int j=0;j<mots.size();j++){
				Mot mt=new Mot();
				mt.mot=(Element)mots.get(j);
				//System.out.println(mt.ExtraireLem());
				//if(mt.ExtraireRad().equals(Radical))
				if(mt.ExtraireLem().equals(racineMot))
					Nbr++;
			}
		}
		return Nbr;
	}
	public static boolean EstuneCollocation(String m1,String m2){
		boolean trouve=false;
		String m=m1+" "+m2;
		String mdef=m1+" "+"lLo"+m2;
		////System.out.println("le modele "+m+" "+mdef);
		List listCollo=LectureModelCollocation.ExtractValeurCollo();
		int i=0;
		while((i<listCollo.size()) && (!trouve)){
			if(listCollo.get(i).equals(m)||listCollo.get(i).equals(mdef)){
				trouve=true;
			}
			i++;
		}
		return trouve;
	}
	public static Boolean Accord_GNP(String Pron,String Genre, String Nombre){
		boolean verif=false;
		String AccordFP=LectureFichierTexte.LectureParametres("Input.txt").get(10);
		
		if(Pron.equals("1")&& Nombre.equals("S"))
			verif=true;
		if(Pron.equals("2") && Genre.equals("M") && Nombre.equals("S"))
			verif=true;
		if(Pron.equals("3") && Genre.equals("F") && Nombre.equals("S"))
			verif=true;
		if(Pron.equals("4") && Genre.equals("M") && Nombre.equals("S"))
			verif=true;
		if(Pron.equals("5") && ((Genre.equals("F")&& Nombre.equals("S"))||(AccordFP.equals("1")&& Genre.equals("F")&& Nombre.equals("P"))
				||(AccordFP.equals("1")&& Genre.equals("M")&& Nombre.equals("P"))))
				verif=true;			
		if(Pron.equals("6")  && Nombre.equals("D"))
			verif=true;
		if(Pron.equals("7") && Genre.equals("M") && Nombre.equals("D"))
			verif=true;
		if(Pron.equals("8") && Genre.equals("F") && Nombre.equals("D"))
			verif=true;
		if(Pron.equals("9") && Nombre.equals("P"))
			verif=true;
		if(Pron.equals("10") && ((Genre.equals("M") && Nombre.equals("P"))||(Genre.equals("F") && Nombre.equals("S"))))
			verif=true;
		if(Pron.equals("11") && Genre.equals("F") && Nombre.equals("P"))
			verif=true;
		if(Pron.equals("12") && ((Genre.equals("M") && Nombre.equals("P"))||(AccordFP.equals("1")&& Genre.equals("F") && Nombre.equals("S"))))
			verif=true;
		if(Pron.equals("13") && Genre.equals("F") && Nombre.equals("P"))
			verif=true;
		return verif;
	}
	public static String typeCandidat(Mot m){
		String type=new String();
		if(m.ExtraireVGRad().equals("4")||m.ExtraireVGRad().equals("5")||
				m.ExtraireVGRad().equals("6")||m.ExtraireVGRad().equals("7")||
				m.ExtraireVGRad().equals("8")||m.ExtraireVGRad().equals("9"))
			type="Nom_preference";	
		else if(m.ExtraireVGRad().equals("19")||m.ExtraireVGRad().equals("20")||
				m.ExtraireVGRad().equals("21")||m.ExtraireVGRad().equals("22")||
				m.ExtraireVGRad().equals("23")||m.ExtraireVGRad().equals("24"))
			type="Nom_ville_ou_pays";			
		else if (m.ExtraireVGRad().equals("33")||m.ExtraireVGRad().equals("34")||
				m.ExtraireVGRad().equals("35")||m.ExtraireVGRad().equals("36")||
				m.ExtraireVGRad().equals("37")||m.ExtraireVGRad().equals("38"))
			type="Nom_propre";	
		else if (m.ExtraireVGRad().equals("39")||m.ExtraireVGRad().equals("40")||
				m.ExtraireVGRad().equals("41"))
			type="Nom_verbe";
		else if (m.ExtraireVGRad().equals("42")||m.ExtraireVGRad().equals("43")||
				m.ExtraireVGRad().equals("44")||m.ExtraireVGRad().equals("45")||
				m.ExtraireVGRad().equals("46")||m.ExtraireVGRad().equals("47"))
			type="Nom_indefini";
		else if (m.ExtraireVGRad().equals("48")||m.ExtraireVGRad().equals("49")||
				m.ExtraireVGRad().equals("50")||m.ExtraireVGRad().equals("51")||
				m.ExtraireVGRad().equals("52")||m.ExtraireVGRad().equals("53"))
			type="Nom_defini";
		else if(m.ExtraireVGRad().equals("192"))
			type="Compose";
		else if(m.ExtraireVGRad().equals("193")||m.ExtraireVGRad().equals("194")||
				m.ExtraireVGRad().equals("195")||m.ExtraireVGRad().equals("196")||
				m.ExtraireVGRad().equals("197"))
			type="Complement";
		else if((m.ExtraireVGRad().equals("60")||m.ExtraireVGRad().equals("61")||
				m.ExtraireVGRad().equals("62")) && 
				!(m.ExtraireValeur().equals("VuW")||m.ExtraireValeur().equals("VlT")))
			type="les_5_noms";
		else type="";
			
			return type;
	}
	public static String Position_Ellipse_VerbeGouvernant(Phrase phr, String VerbeVal){
		String pos=new String();
		List<String> ListMots=new ArrayList<String>();
		List ellipses=phr.ExtraireEllipses();
		int i=0;
		boolean trouve=false;
		while(!trouve && i<ellipses.size()){
			Ellipse Elp=new Ellipse();
			Elp.ellipse=(Element) ellipses.get(i);
			if(Elp.ExtraireMotPrecedouAvant().equals(VerbeVal)){
				trouve=true;
				pos=Elp.ExtrairePosition();
			}
			i++;
		}
		return pos;
	}
	public static List<String> ExtraireMotsPredEllipse(Phrase phr){
		List<String> ListMots=new ArrayList<String>();
		List ellipses=phr.ExtraireEllipses();
		
		//System.out.println("taille liste:"+ellipses.size());
		for(int i=0;i<ellipses.size();i++){
			Ellipse Elp=new Ellipse();
			Elp.ellipse=(Element) ellipses.get(i);
			//System.out.println("Elp:"+Elp.ExtraireType()+" "+Elp.ExtraireMotPrecedouAvant());
			if(Elp.ExtraireType().equals("Sujet")||Elp.ExtraireType().equals("sujet")){
				ListMots.add(Elp.ExtraireMotPrecedouAvant());
			}
		}
		//System.out.println("Afficher Liste mots preced ellipse");
		//for(int a=0;a<ListMots.size();a++){
			//System.out.println(ListMots.get(a)+" ");
		//}
		return ListMots;
	}
	
	public static boolean PronVerbe_PremierDeuxiemePersonne(String Pron){
		boolean trouve=false;
		if(Pron.equals("1")||Pron.equals("2")||Pron.equals("3")||Pron.equals("6")
				||Pron.equals("9")||Pron.equals("10")||Pron.equals("11"))
			trouve=true;		
		return trouve;
	}
	public static boolean EstuneParticuleInterrogative(String Vg){
		boolean trouve=false;
		Integer vg=-1;
		if(!Vg.equals(""))
			vg=Integer.parseInt(Vg);
		if(vg>=11 && vg<=18)
			trouve=true;		
		return trouve;
	}
	public static boolean EstunPronomRelatif(String Vg, String Rad){
		boolean trouve=false;
		//if(Vg.equals("54")||Vg.equals("55")||Vg.equals("56")||Vg.equals("57")
		if(Vg.equals("54")||Vg.equals("55")||Vg.equals("56")||Vg.equals("57")&&!Rad.equals("Mal"))  //14/08/2020
			trouve=true;		
		return trouve;
	}
	public static boolean EstunePreposition(String Vg){
		//une préposition (une particule) sauf les particules de coordination
		boolean trouve=false;
		Integer vg=-1;
		if(!Vg.equals(""))
			vg=Integer.parseInt(Vg);
		if(vg==66||(vg>=68 && vg<=70)||(vg>=72 && vg<=82)||(vg>=84 && vg<=93)||vg==222)
			trouve=true;
		return trouve;
	}
	public static Boolean EstunVerbPassif(String Vg_verb){
		boolean trouve=false;
		if(Vg_verb.equals(122)||Vg_verb.equals(123)||
				(Integer.parseInt(Vg_verb)>=140 &&Integer.parseInt(Vg_verb)<=145))
			trouve=true;
		return trouve;
	}
	public static Boolean EstunAdjectifNominatif(String Vgmot){
		boolean trouve=false;
		if(Vgmot.equals(199)||Vgmot.equals(202)||Vgmot.equals(206)||Vgmot.equals(209)||
				Vgmot.equals(212)||Vgmot.equals(215)||Vgmot.equals(218)||Vgmot.equals(219))
			trouve=true;
		return trouve;
	}
	
	public static Boolean EstunAnnexe(String Vgmot){
		boolean trouve=false;
		if(Vgmot.equals(196)||Vgmot.equals(197))
			trouve=true;
		return trouve;
	}
	
	public static Boolean Accord_Verb_Cl_BF_Cl_Ellip(List mots,int index_verb_ellip,int index_verb_BF){
		boolean trouve=false;
		Mot verb_ellip=new Mot();
		verb_ellip.mot=(Element)mots.get(index_verb_ellip);
		Mot verb_BF=new Mot();
		verb_BF.mot=(Element)mots.get(index_verb_BF);
		if(verb_ellip.ExtraireGenre().equals(verb_BF.ExtraireGenre())&&
				verb_ellip.ExtraireNombre().equals(verb_BF.ExtraireNombre())&&
				verb_ellip.ExtrairePronom().equals(verb_BF.ExtrairePronom())&&
				verb_ellip.ExtraireTransitivite().equals(verb_BF.ExtraireTransitivite()))
			trouve=true;
		return trouve;
		
	}
	public static Boolean Accord_Verb_Cl_BF_Cl_Ellip2(List mots,List mots_preced,int index_verb_ellip,int index_verb_BF){
		boolean trouve=false;
		Mot verb_ellip=new Mot();
		verb_ellip.mot=(Element)mots.get(index_verb_ellip);
		Mot verb_BF=new Mot();
		verb_BF.mot=(Element)mots_preced.get(index_verb_BF);
		if(verb_ellip.ExtraireGenre().equals(verb_BF.ExtraireGenre())&&
				verb_ellip.ExtraireNombre().equals(verb_BF.ExtraireNombre())&&
				verb_ellip.ExtrairePronom().equals(verb_BF.ExtrairePronom())&&
				verb_ellip.ExtraireTransitivite().equals(verb_BF.ExtraireTransitivite()))
			trouve=true;
		return trouve;
		
	}
	public static Boolean EstunConnecteur(String Vg_proc, String Vg_motPre1,String val_motPre1,String val_motPre2){
		boolean trouve=false;
		Integer vgproc=-1;
		if(!Vg_proc.equals(""))
			vgproc=Integer.parseInt(Vg_proc);	//corriger le 02/08/2020
		if(vgproc==3||(vgproc>=29 && vgproc<=34)
				||Vg_motPre1.equals("67")||Vg_motPre1.equals("71")||Vg_motPre1.equals("83")
				||(val_motPre1.equals("èN")&&val_motPre2.equals("QBL"))
				||(val_motPre1.equals("èN")&&val_motPre2.equals("Bgd")))
			trouve=true;
		return trouve;
	}
	public static Integer PositionClauseBienFormée(List mots,int num_mot){
		boolean existe=false;
		Integer pos=-1;
		int i=num_mot-2;
		while(i>=0 && !existe){
			Mot mt1=new Mot();
			mt1.mot=(Element)mots.get(i);
			if(!TypeVerbe(mt1.ExtraireVGRad()).equals("")){
				Mot mt2=new Mot();
				mt2.mot=(Element)mots.get(i+1);
				if(EstunNomNominatif(mt2.ExtraireVGRad())){
					existe=true;
					pos=i;
				}
				else
					i=i-1;
			}
			else
				i=i-1;
		}
		return pos;
	}
	public static Boolean ExistSignePonct(String phrase_text, int num_mot){
		boolean exist=false;
		System.out.println(phrase_text+" "+num_mot);
		String[] List_mots=phrase_text.split(" ");
		String mot=List_mots[num_mot];		
		if(SignePonct(mot.substring(mot.length()-1)))
			exist= true;
		else if(List_mots.length>num_mot+1){
			if(SignePonct(List_mots[num_mot+1]))
				exist=true;
		}
		return exist;
	}
	public static boolean SignePonct(String ch){
		boolean trouve=false;
		if(ch.equals(",")||ch.equals(";")||ch.equals(":")||ch.equals("!")||ch.equals(".")||
				ch.equals("?"))
			trouve=true;
		return trouve;
	}
	public static String TypeVerbe(String VG){
		String type="";
		Integer vg=-1;
		if(!VG.equals(""))
			vg=Integer.parseInt(VG);
		if(vg==113||vg==114)
			type="verbe imperatif";
		else if(vg>=115 && vg<=121)
			type="verbe invariable";
		else if(vg==122||vg==123)
			type="verbe passe passif";
		else if(vg>=124 && vg<=127)
			type="verbe passe connu";
		else if(vg>=128 && vg<=131)
			type="verbe passe approche";
		else if(vg>=132 && vg<=135)
			type="verbe passe incomplet non conjugue";
		else if(vg>=136 && vg<=139)
			type="verbe passe incomplet conjugue";
		else if(vg>=140 && vg<=145)
			type="verbe present passif";
		else if(vg==146 && vg==147)
			type="verbe avec N lourd ou leger";
		else if(vg>=148 && vg<=159)
			type="verbe present connu";
		else if(vg>=160 && vg<=171)
			type="verbe present approche";
		else if(vg>=172 && vg<=179)
			type="verbe present complet conjugue";
		else if(vg>=180 && vg<=191)
			type="verbe present incomplet conjugue";
		return type;
	}
	public static boolean AppartientListe(List<String> ListMots, String Mot){
		boolean exist=false;
		int i=0;
		while(i<ListMots.size() && !exist){
			if(ListMots.get(i).equals(Mot))
				exist=true;
			else
				i++;
		}
		return exist;
	}
	public static boolean EstunNom(String VG){
		boolean x=false;
		if(!VG.equals("")){
				int vg=Integer.parseInt(VG);
			if ((vg>=19 && vg<=57)||(vg>=193 && vg<=197))
				x=true;
		}
		return x;
	}
	public static boolean EstunNomNominatif(String VG){
		boolean x=false;
		if(!VG.equals("")){
				int vg=Integer.parseInt(VG);
			if (vg==20||vg==23||vg==27||vg==30||vg==34||vg==37||vg==39||vg==40||vg==41
					||vg==44||vg==45||vg==49||vg==52||vg==56||vg==194)
				x=true;
		}
		return x;
	}
	public static boolean AccordGNP(Mot m, List mots, int pos){
		boolean test=false;
		boolean existVerb=false;
		int i=pos+1;
		Mot mc=new Mot();
		while(i<mots.size() && !existVerb ){
			mc=new Mot();
			mc.mot=(Element)mots.get(i);
			if(!mc.ExtraireVGRad().equals("")){
				if(EstunVerbe(mc.ExtraireVGRad()))
					existVerb=true;
			}
			i++;
		}
		if(existVerb){
			if((mc.ExtraireGenre().equals(m.ExtraireGenre()) && mc.ExtraireNombre().equals(m.ExtraireNombre()))||
					(mc.ExtraireGenre().equals(m.ExtraireGenreanaph()) && mc.ExtraireNombre().equals(m.ExtraireNbranaph())))
				test=true;
		}
		return test;
	}

	public static boolean isNumeric(String str)
	{
	    for (char c : str.toCharArray())
	    {
	        if (!Character.isDigit(c)) return false;
	    }
	    return true;
	}
	public static boolean EstuneParticule(String VG){
		boolean x=false;
		int vg=Integer.parseInt(VG);
		if ((vg>=72 && vg<=75)||(vg==70)||(vg==54)||(vg==18))
			x=true;
		return x;
	}
	public static boolean EstuneParticuleForContextWordEmbed(String ValGram){
		boolean test=false;
		int vg=0;
		if(!ValGram.equals("")){
			vg=Integer.parseInt(ValGram);
			if(vg==2 || vg==58 || vg==59|| (vg>=66 && vg<=93)|| vg==222||vg==223)
				test=true;
		}
		return test;
	}
	public static boolean EstunNombre(String VG){
		boolean x=false;
		int vg=Integer.parseInt(VG);
		if ((vg>=208 && vg<=213)||(vg>=107 && vg<=112))
			x=true;
		return x;
	}
	public static boolean Delimiter(String Sequence,  List<String> ListDelimiter){
		boolean test=false;
		int i=0;
		while(i<ListDelimiter.size() && test==false){
			////System.out.println(ListDelimiter.get(i).replaceAll("   ","").replaceAll("  ","").replaceAll(" ","")+"="+Sequence.replaceAll("\\s",""));
			if(ListDelimiter.get(i).replaceAll("   ","").replaceAll("  ","").replaceAll(" ","").equals(Sequence.replaceAll("\\s","")))
				test=true;
			i++;
		}
		return test;
	}
	public static boolean ListAdjDefini(String adj,List<String> ListAdj){
		boolean test=false;
		int i=0;
		while(i<ListAdj.size() && test==false){
			if(ListAdj.get(i).equals(adj))
				test=true;
			i++;
		}
		return test;
	}
	public static boolean EstunVerbe(String VG){
		boolean x=false;
		if (!VG.equals("")){
			int vg=Integer.parseInt(VG);
			if (vg>=113 && vg<=191)
				x=true;
		}
		return x;
	}
	public static String FiltreRad(String rad){
		String radical=new String();
		if(rad.contains(";"))
			radical=rad.substring(0, rad.indexOf(";"));
		else radical=rad;
		return radical;
	}
	public static boolean EstunModificateur(String rad, String VG){
		boolean test=false;
			if(VG.equals("58") || VG.equals("59")){
				if(rad.equals("éiNA")|| rad.equals("èaNA")||rad.equals("LakiNA")||
						rad.equals("LaYoTa")||rad.equals("LagaLA")){
					test=true;
				}
			}
		return test;
	}
	public static int[] PosModificateur(List syntagmes){
		int Pos=-1;
		Iterator s = syntagmes.iterator();
		int[] ArrayPos = new int[3];
	    int numMot=-1;
	    int numSyn=-1;
	    int wo=-1;
	    ArrayPos[0]=numMot;	//num mot dans la phrase
		ArrayPos[1]=numSyn;	//num syntagme dans la phrase
	    while(s.hasNext() && Pos==-1){
	    	wo=-1;
	      Syntagme syn = new Syntagme();
	      syn.syntagme = (Element)s.next();
	      numSyn++;
	      List mots = syn.ExtraireMots();
	      Iterator m = mots.iterator();
	        while(m.hasNext() && Pos==-1){
	        	 Mot w = new Mot();
	             w.mot=(Element)m.next(); 
	             numMot++;
	             wo++;
	             if(EstunModificateur(w.ExtraireRadE(),w.ExtraireVGRad2())){
	            	 Pos=numMot;
	            	 ArrayPos[0]=numMot;
	            	 ArrayPos[1]=numSyn;
	            	 ArrayPos[2]=wo;		//position du mot dans le syntagme
	             }    
	        }
	    }
		return ArrayPos;
	}

	public static int PosModificateur1(List mots){
		int Pos=-1;
		int i=0;
	    while(i<mots.size() && Pos==-1){
	      Mot mt = new Mot();
		  mt.mot=(Element)mots.get(i);
	             if(EstunModificateur(mt.ExtraireRadE(),mt.ExtraireVGRad())){
	            	 Pos=i;
	             } 
	        i++;
	     }
		return Pos;
	}
}
