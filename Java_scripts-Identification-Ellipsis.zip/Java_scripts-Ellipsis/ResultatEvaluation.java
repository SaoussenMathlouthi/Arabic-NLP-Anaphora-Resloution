package Detection_Resolution_Ellipse;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import org.jdom2.Element;

public class ResultatEvaluation {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//String NameFile="fichierResultat1Resolu.xml";
		String NameFile="fichierResultat4Resolu_FT_ContexImm.xml";
		//String NameFile="texteE6SegEtiqAnaphEllipResolu_FT_ConteImm.xml";
		//String NameFile="texteM3SegEtiqAnaphEllipResolu_FT_ContexImm.xml";
		//String NameFile="fichierResultat5V1Resolu.xml";
		//String NameFile="texteE6SegEtiqAnaphEllipResolu.xml";
		//String NameFile="texteM4SegEtiqAnaphEllipResolu.xml";
		Resultat(NameFile);
	}
	public static float Resultat(String NameFile){
		Texte txt=new Texte();
		Paragraphe parag=new Paragraphe();
		Phrase ph=new Phrase();
		Syntagme sy=new Syntagme();
		Mot mt=new Mot();
		Candidat ca=new Candidat();
		Candidat ant=new Candidat();
		List phs;
		List syntags;
		List mots;
		List ListCand;
		List ListAnt;
		List ListMeilleurCand;
		Antecedent MeillAnteced;
		String typeAnaph=new String();
		int NEBRes=0;
		int NERes=0;
		float TR=0;
		int NumPhr;
		int NumMot;
		float score1;
		boolean existe;
		float score;
		int a;
		int indexEllip=0;
		String NumMotMA;
		String NumPhrMA;
		float TRE=0;
		int Rg=-1;
		int Rg1=-1;
		int Rg2=-1;
		int Rang2=0;
		int Rang3=0;
		int Rang4=0;
		int Rang5=0;
		int Exact=0;
		List<String> listValCand=new ArrayList<String>();
		List<String> listValAnt=new ArrayList<String>();
		String meilleurCand=new String();
		String meilleurCand1=new String();
		List ListMotsPreEllipse=new ArrayList<String>();
		List<Ellipse> ListEllipses=new ArrayList<Ellipse>();
		List<Ellipse> ListEllipsesResol=new ArrayList<Ellipse>();
		Ellipse ellip=new Ellipse();
		Ellipse ellipResolu=new Ellipse();
		int NESansCand=0;
		String dist1=new String();
		String dist2=new String();
		double pos_moy=0;
		int position=0;
		
		txt.nomfichier= NameFile;
		String texte = txt.nomfichier.substring(0,txt.nomfichier.indexOf(".")); 
		System.out.println("texte analys�:"+texte);
		List parags=txt.ExtractParagraphe();
		for(int pa=0;pa<parags.size();pa++){	
			 parag.paragraphe=(Element)parags.get(pa);
			 phs = parag.ExtrairePhrases();
			 for(int i=0;i<phs.size();i++){
				 ph.phrase=(Element)phs.get(i);
				 ListMotsPreEllipse=MethodesDivers.ExtraireMotsPredEllipse(ph);
				 ListEllipses=ph.ExtraireEllipses();
				 ListEllipsesResol=ph.ExtraireEllipsesResolu();				 
					 mots = ph.ExtraireMots();
					 for(int k=0;k<mots.size();k++){
						 mt.mot=(Element)mots.get(k);
						 if(!MethodesDivers.TypeVerbe(mt.ExtraireVGRad()).equals("")){
							////System.out.println("mot courant:"+m.ExtraireValeur()+" indice mot:"+k+" vg courant:"+m.ExtraireVGRad());													
							if(MethodesDivers.AppartientListe(ListMotsPreEllipse,mt.ExtraireValeur())){							
								//System.out.println("******************nouvelle instance ellipse sujet");
				        		 indexEllip++;	
				        		 System.out.println("#######################################");
				        		 System.out.println("Ellipse "+indexEllip+" du verb gouv:"+mt.ExtraireValeur());
				        		 if(ListEllipsesResol.size()>0){
				        			 NERes++;
				        			 ellip=new Ellipse();				        				
					        		 ellip=ChercherEllipse(ListEllipses,mt.ExtraireValeur());
					        		 //System.out.println("ellip:"+ellip.ExtraireMotPrecedouAvant()+" mt:"+mt.ExtraireValeur()+" taille liste ellip:"+ListEllipses.size());
					        		 String dist=ellip.ExtraireDistance();					        		 
					        		 ellipResolu=new Ellipse();					        		 
					        		 if(ListEllipsesResol.size()!=0){
					        			 System.out.println("mt "+mt.ExtraireValeur()+" taille liste ellip resol:"+ListEllipsesResol.size());
					        			 ellipResolu=ChercherEllipseResol(ListEllipsesResol,mt.ExtraireValeur());
					        			 if(ellipResolu.ExtraireVerbGouv().equals(""))
						        			 NESansCand++;
					        			 //System.out.println("ellip:"+ellipResolu.ExtraireVerbGouv()+" taille liste ellip resol:"+ListEllipsesResol.size());
						        		 ListCand=ellipResolu.ExtraireListCandidats();	
						        		 //System.out.println("dist:"+dist+"/"+ellipResolu.ExtraireDistance());
						        		 if(!dist.contains("-")){
							        		 if(dist.equals(ellipResolu.ExtraireDistance())){
							        			 NEBRes++;
							        			 position=position+1;
							        		 }
							        		else{
							        			Rg=RangAntecedentEllipse(dist,ListCand);
							        			if(Rg==99)
							        				Exact++;
							        			position=position+Rg;
							        			if(Rg==2)
								        			 Rang2++;
								        		 else if(Rg==3)
								        			 Rang3++;
								        		 else if(Rg==4)
								        			 Rang4++;
								        		 else if(Rg==5)
								        			 Rang5++;
							        		}
						        		 }
						        		 else{
						        			 dist1=dist.substring(0, dist.indexOf("-"));
						        			 dist2=dist.substring(dist.indexOf("-")+1, dist.length());
						        			 if(dist1.equals(ellipResolu.ExtraireDistance())||dist2.equals(ellipResolu.ExtraireDistance())){
							        			 NEBRes++;
							        			 position=position+1;
							        		 }
							        		else{
							        			Rg1=RangAntecedentEllipse(dist1,ListCand);
							        			Rg2=RangAntecedentEllipse(dist2,ListCand);
							        			position=position+Rg1;
							        			if(Rg1==2||Rg2==2)
								        			 Rang2++;
								        		 else if(Rg1==3||Rg2==3)
								        			 Rang3++;
								        		 else if(Rg1==4||Rg2==4)
								        			 Rang4++;
								        		 else if(Rg1==5||Rg2==5)
								        			 Rang5++;
							        		}
						        		 }						        		 
					        		 }
				        		 }
							}
			        	 }
					 }
				 
			 }
		}
		//TR=(float)NABR/NA;
		TRE=(float)NEBRes/NERes;
		pos_moy=(double)position/NERes;
		DecimalFormat df = new DecimalFormat("#.##");
		System.out.println(" *****Nbr Ellip correctement R�solu******:"+NEBRes);
		System.out.println(	" Nbr Ellip resolu:"+NERes);
		System.out.println(" Taux de r�ussite exacte:"+TRE);
		System.out.println(" Nbr Ellip de rang 2:"+Rang2);
		System.out.println(" Nbr Ellip de rang 3:"+Rang3);
		System.out.println(" Nbr Ellip de rang 4:"+Rang4);
		System.out.println(" Nbr Ellip de rang 5:"+Rang5);
		System.out.println(	" Nbr Ellip total:"+indexEllip);
		System.out.println(	" Nbr Ellip sans cand:"+NESansCand);
		System.out.println(	" somme position:"+position);
		System.out.println(	" position moyenne:"+df.format(pos_moy));
		System.out.println(	"nbr fois antecedent n existe pas parmi les candidats:"+Exact);
		return TRE;			
	}
		public static int RangAntecedentEllipse(String distance,List ListCand){
			int rang=-1;
			boolean trouve=false;
			int i=0;
			while(i<ListCand.size()&&!trouve){
				Candidat ca=new Candidat();
				ca.cand=(Element)ListCand.get(i);
				if(ca.ExtraireDistance().equals(distance))
					trouve=true;
				i++;				
			}
			if(trouve)
				rang=i;
			return rang;
		}
		public static Ellipse ChercherEllipseResol(List ListEllipses, String verbGouv){
			Ellipse ellip=new Ellipse();
			boolean trouve=false;
			int i=0;
			while(i<ListEllipses.size()&&!trouve){
				ellip.ellipse=(Element)ListEllipses.get(i);
				if(ellip.ExtraireVerbGouv().equals(verbGouv))
					trouve=true;
				i++;
			}
			return ellip;
		}
	public static Ellipse ChercherEllipse(List ListEllipses, String verbGouv){
		Ellipse ellip=new Ellipse();
		boolean trouve=false;
		int i=0;
		while(i<ListEllipses.size()&&!trouve){
			ellip.ellipse=(Element)ListEllipses.get(i);
			if(ellip.ExtraireMotPrecedouAvant().equals(verbGouv))
				trouve=true;
			i++;
		}
		return ellip;
	}
public static int RangAntecedent(List<String> listValAnt,List<String> listValCand){
	int Rang=99;
	int Rangf=99;
	String ant=new String();
	for(int i=0;i<listValAnt.size();i++){
		ant=listValAnt.get(i);
		int j=0;
		while(j<listValCand.size()&&!ant.equals(listValCand.get(j))){	
			j++;
		}
		if(j<listValCand.size())
			Rang=j;
		if(Rang<Rangf)
			Rangf=Rang;
		
	}
	
	return Rangf;
	}
public static List<String> ValeurCandidat(List ListCand){
	List listValCand=new ArrayList<String>();
	Candidat cad=new Candidat();
	String val=new String();
	for(int i=0;i<ListCand.size();i++){
		cad.cand=(Element)ListCand.get(i);
		val=cad.ExtraireValeur();
		listValCand.add(val);
		if(val.contains(" ")){
			listValCand.add(val.substring(0, val.indexOf(" ")));
		}
			
	}
	return listValCand;
}
public static boolean ExisteAnteced(Candidat Ant,List ListCand){
	boolean existe=false;
	int i=0;
	int NumPhr=Ant.ExtraireNumPhrase();
	int NumMot=Ant.ExtraireNumMot();
	while(i<ListCand.size() && !existe){
		Candidat ca=new Candidat();
		ca.cand=(Element)ListCand.get(i);
		if(ca.ExtraireNumPhrase()==NumPhr && ca.ExtraireNumMot()==NumMot)
			existe=true;
		i++;
	}
	return existe;
}

public static List MeilleurCandidats(List ListCand){
	List Meilleurs=new ArrayList();
	Candidat ca1=new Candidat();
	ca1.cand=(Element)ListCand.get(0);
	float score1=Float.valueOf(ca1.ExtraireScore());
	Meilleurs.add(ca1);
	if(ListCand.size()>1){
		Candidat ca=new Candidat();
		ca.cand=(Element)ListCand.get(1);
		float score=Float.valueOf(ca.ExtraireScore());
		int i=1;
		while(i<ListCand.size() && score==score1){
			Meilleurs.add(ca);
			i++;
			ca.cand=(Element)ListCand.get(i);
			score=Float.valueOf(ca.ExtraireScore());
		}
	}
	return Meilleurs;
}
public static List MeilleurCandidats0(List ListCand){
	Candidat ca1=new Candidat();
	ca1.cand=(Element)ListCand.get(0);
	float score1=Float.valueOf(ca1.ExtraireScore());
	float score;
	for(int i=ListCand.size()-1;i>0;i--){
		Candidat ca=new Candidat();
		ca.cand=(Element)ListCand.get(i);
		score=Float.valueOf(ca.ExtraireScore());
		if(score!=score1)
			ListCand.remove(ca);
	}
	return ListCand;
}
public static void DisplayListCandidat(List<Element> ListCand,String cand){
	String val=new String();
	String score=new String();
	System.out.println(cand+":");
	for(int i=0;i<ListCand.size();i++){
		Candidat ca=new Candidat();
		ca.cand=(Element)ListCand.get(i);
		val=ca.ExtraireValeur();
		score=ca.ExtraireScore();
		System.out.println(val);
	}
}
public static void DisplayListValCand(List<String> ListCand,String cand){
	
	System.out.println(cand+":");
	for(int i=0;i<ListCand.size();i++){
		System.out.println(ListCand.get(i));
	}
}

}
