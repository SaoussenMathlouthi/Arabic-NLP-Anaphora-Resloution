package Detection_Resolution_Ellipse;

import java.util.*;

public class Ellipse_Candidat {
	
	InstanceEllipse Inst_Ellipse;
	List<Antecedent> listeAnteced = new ArrayList<Antecedent>();
	List<Antecedent> ListCandOrdonnees=new ArrayList<Antecedent>();
	Antecedent BestAntec;
	static CombinaisonCritere Res=new CombinaisonCritere();
	
	public Ellipse_Candidat(InstanceEllipse E, List<Antecedent> L, Antecedent BA){
		Inst_Ellipse=E;
		listeAnteced=L;
		BestAntec=BA;
		}

	public InstanceEllipse getInst_Ellipse() {
		return Inst_Ellipse;
	}

	public void setInst_Ellipse(InstanceEllipse ellipse) {
		this.Inst_Ellipse = ellipse;
	}

	
	public List<Antecedent> getListCandOrdonnees() {
		return ListCandOrdonnees;
	}

	public void setListCandOrdonnees(List<Antecedent> listCandOrdonnees) {
		ListCandOrdonnees = listCandOrdonnees;
	}

	public static CombinaisonCritere getRes() {
		return Res;
	}

	public static void setRes(CombinaisonCritere res) {
		Res = res;
	}

	public List<Antecedent> getListeAnteced() {
		return listeAnteced;
	}

	public void setListeAnteced(List<Antecedent> listeAnteced) {
		this.listeAnteced = listeAnteced;
	}

	public Antecedent getBestAntec() {
		return BestAntec;
	}

	public void setBestAntec(Antecedent bestAntec) {
		BestAntec = bestAntec;
	}
	

}
