package Detection_Resolution_Ellipse;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Combinaison {
	//public static int TailleCombinaisonMin=ValeurConstantes.tailleCombMin;
	public static void main(String[] args)
	{
	   //String[] ensemble = { "1", "2", "3" };
	  // int profondeur = 10;
		//System.out.println("taille comb "+ TailleCombinaisonMin);
	   ArrayList<String> SousEnsb=new ArrayList<String>();
	   SousEnsb=TouteslesCombinaison(13);
	   System.out.println("nombre d'element "+SousEnsb.size());
	  for(int i=0;i<SousEnsb.size();i++){
		   System.out.println("element "+i+":"+SousEnsb.get(i));
	   }
	  //System.out.println("combinaisons possibles");
	  //String[] ensemble={"2","4"};
	  //SousEnsb=CombinaisonPossibles(ensemble);
	  //for(int i=0;i<SousEnsb.size();i++){
		//   System.out.println("element "+i+":"+SousEnsb.get(i));
	   //}
	   //TrierEnsemble(SousEnsb);
	}
	public static ArrayList<String> TrierEnsemble(ArrayList<String> SousEnsb){
		ArrayList<Integer> SousEnsbTrie=new ArrayList<Integer>();
		ArrayList<String> SousEnsbTrie1=new ArrayList<String>();
		 
		for(int i=0;i<SousEnsb.size();i++){ 
			   SousEnsbTrie.add(Integer.parseInt(SousEnsb.get(i)));
		   }
		   Collections.sort(SousEnsbTrie);
		
		   for(int j=0;j<SousEnsbTrie.size();j++){ 
			   SousEnsbTrie1.add(String.valueOf((SousEnsbTrie.get(j))));
		   }
		   for(int i=0;i<SousEnsbTrie1.size();i++){
			   System.out.println("element "+i+" "+SousEnsbTrie1.get(i));
		   }
		return(SousEnsbTrie1);
	}
	public static ArrayList<String> FiltrerEnsemble(ArrayList<String> SousEnsb){
		
		ArrayList<String> ensb=new ArrayList<String>();
		for(int i=0;i<SousEnsb.size();i++){
			if(SousEnsb.get(i).length()>=1 && SousEnsb.get(i).length()<=5/*>=TailleCombinaisonMin*/){
				ensb.add(SousEnsb.get(i));
			}
		}
		return ensb;
	}
	
	
	
	public static ArrayList<String> TouteslesCombinaison(int NbCrit){
		 String[] ensemble=new String[NbCrit];
		 //String[] ensemble={"1","2","3","4","5","6","7","8","9"};
		 
		   //int profondeur = 10;
		   int profondeur = NbCrit;
		   for(int i=0;i<NbCrit;i++)
			   ensemble[i]=" "+Integer.toString(i+1);
		   
		   ArrayList<String> SousEnsb=new ArrayList<String>();
		   //ArrayList<String> SousEnsbFil=new ArrayList<String>();
		   //ArrayList<String> SousEnsbTrie=new ArrayList<String>();
		   
		   CombinEnsemble(ensemble, profondeur, 0, "", 0,SousEnsb);
		  //SousEnsbFil=FiltrerEnsemble(SousEnsb);
		   //Collections.sort(SousEnsbFil);
		   //SousEnsbTrie=TrierEnsemble(SousEnsbFil);
		   
		  Collections.sort(SousEnsb,stringLengthComparator);
		  SousEnsb=DeleteInitSpace(SousEnsb);
		   return SousEnsb;
	}
	public static ArrayList<String> CombinaisonPossibles(String[] ensemble){
		
		 
		   int profondeur = 10;
		   
		   for(int i=0;i<ensemble.length;i++)
			   ensemble[i]=" "+ensemble[i];
		   
		   ArrayList<String> SousEnsb=new ArrayList<String>();
		   //ArrayList<String> SousEnsbFil=new ArrayList<String>();
		   //ArrayList<String> SousEnsbTrie=new ArrayList<String>();
		   
		   CombinEnsemble(ensemble, profondeur, 0, "", 0,SousEnsb);
		  //SousEnsbFil=FiltrerEnsemble(SousEnsb);
		   //Collections.sort(SousEnsbFil);
		   //SousEnsbTrie=TrierEnsemble(SousEnsbFil);
		   
		  Collections.sort(SousEnsb,stringLengthComparator);
		  SousEnsb=DeleteInitSpace(SousEnsb);
		   return SousEnsb;
	}
	
	 public static ArrayList<String> DeleteInitSpace( ArrayList<String> SousEnsb){
		 ArrayList<String> SousEnsbf=new ArrayList<String>();
		 for(int i=0;i<SousEnsb.size();i++){
			 if(SousEnsb.get(i).startsWith(" "))
			 { SousEnsbf.add(SousEnsb.get(i).substring(1));//SousEnsb.get(i).equals(SousEnsb.get(i).substring(0));
			 	//System.out.println("espace initiale supprim�e");
				 }
			 }
		 
		 return SousEnsbf;
	 }
	static Comparator<String> stringLengthComparator = new Comparator<String>()
		    {
		        public int compare(String o1, String o2)
		        {
		            return Integer.compare(o1.length(), o2.length());
		        }
		    };
	public static ArrayList<String> ListCombinaison(String[] ensemble){
		 //String[] ensemble=new String[NbCrit];
		 //String[] ensemble={"1","2","3","4","5","6","7","8","9"};
		   int profondeur = 10;
		
		   
		   ArrayList<String> SousEnsb=new ArrayList<String>();
		   CombinEnsemble(ensemble, profondeur, 0, "", 0,SousEnsb);
		   Collections.sort(SousEnsb,stringLengthComparator);
		   return SousEnsb;
	}
	
	public static void CombinEnsemble(String[] ensemble, int profMax,
		      int profCourante, String prefix, int rang,ArrayList<String> SousEnsb)
		{
		   if (profCourante < profMax)
		   {
		      for (int i = rang; i < ensemble.length; i++)
		      {
		         //System.out.println(prefix + ensemble[i]);
		         SousEnsb.add(prefix + ensemble[i]);
		      }

		      for (int i = rang; i < ensemble.length; i++)
		      {
		        CombinEnsemble(ensemble, profMax, profCourante + 1, prefix
		               + ensemble[i], i + 1,SousEnsb);
		      }
		   }
		}
	
	public class MyComparator implements java.util.Comparator<String> {

	    private int referenceLength;

	    public MyComparator(String reference) {
	        super();
	        this.referenceLength = reference.length();
	    }

	    public int compare(String s1, String s2) {
	        int dist1 = Math.abs(s1.length() - referenceLength);
	        int dist2 = Math.abs(s2.length() - referenceLength);

	        return dist1 - dist2;
	    }
	}
	public static ArrayList<String> CombinCritere(int NbCrit){
		ArrayList<String> ListCombin=new ArrayList<String>();
		for(int i=1;i<=NbCrit;i++){
			for(int j=1;j<=NbCrit;j++){
				
			}
		}
		return ListCombin;
	}
    
}
