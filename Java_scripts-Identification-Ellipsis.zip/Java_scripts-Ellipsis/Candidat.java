package Detection_Resolution_Ellipse;

import org.jdom2.Element;

public class Candidat {

	static public Element cand = new Element("Candidat");
	public Candidat() {
		}
	public static String ExtraireDistance(){
		String val = new String();
		val = cand.getAttributeValue("dist");
		return val;
	}
	public static String ExtraireValeur(){
		String val = new String();
		val = cand.getAttributeValue("val");
		return val;
	}
	public static int ExtraireNumPhrase(){
		String Num=cand.getAttributeValue("numPhrase");
		if(Num.contains("+"))
			Num=Num.substring(0, Num.indexOf("+"));
		int num=Integer.parseInt(Num);
		return num;
	}
	public static int ExtraireNumMot(){
		String Num=cand.getAttributeValue("numMot");
		if(Num.contains("+"))
			Num=Num.substring(0, Num.indexOf("+"));
		int num=Integer.parseInt(Num);
		return num;
	}	  
	public static String ExtraireScore(){
		String val = new String();
		val = cand.getAttributeValue("Score");
		return val;
	}
	public static String ExtraireVg(){
		String val = new String();
		val = cand.getAttributeValue("vg");
		
		return val;
	}
		  /**
			 * @param args
			 */
			public static void main(String[] args) {
				// TODO Auto-generated method stub

			}

}
