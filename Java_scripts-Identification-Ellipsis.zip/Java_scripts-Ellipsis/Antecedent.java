package Detection_Resolution_Ellipse;

public class Antecedent {
	
	private int num;
	private String valeur;
	private String vg;
	private String numMot;
	private int numPh;
	private int numParag;
	private float score;
	private String Genre;
	private String Nombre;
	private String Radicale;
	private double FonctionValeur;
	private String CombinaisonCritere;
	private int numPhGlobal;
	private String type;
	private String lemme;
	private int distance;
	private float scorebase;
	private String CritVerif;
	private String bestCombinCrit;
	private double ValSimilarity;
	private int rang;
	private String DecoupRacine;
	private int vote1;
	private int vote2;
	private int vote;
	
	
	
	public Antecedent(int num, String valeur, String vg, String numMot, int numPh,int numParag,String Genre, String Nombre, String Radicale,String CombinCrit){
		this.num=num;
		this.valeur=valeur;
		this.vg=vg;
		this.numMot=numMot;
		this.numPh=numPh;
		this.numParag=numParag;
		this.Genre=Genre;
		this.Nombre=Nombre;
		this.Radicale=Radicale;
		this.CombinaisonCritere=CombinCrit;
		
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getValeur() {
		return valeur;
	}
	public void setValeur(String valeur) {
		this.valeur = valeur;
	}
	public String getVg() {
		return vg;
	}
	public void setVg(String vg) {
		this.vg = vg;
	}
	public int getNumPh() {
		return numPh;
	}
	public void setNumPh(int numPh) {
		this.numPh = numPh;
	}
	public String getNumMot() {
		return numMot;
	}
	
	public float getScore() {
		return score;
	}
	public void setScore(float score) {
		this.score = score;
	}
	public int getNumParag() {
		return numParag;
	}
	public void setNumParag(int numParag) {
		this.numParag = numParag;
	}
	public void setNumMot(String numMot) {
		this.numMot = numMot;
	}
	public String getGenre() {
		return Genre;
	}
	public void setGenre(String genre) {
		Genre = genre;
	}
	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	public String getRadicale() {
		return Radicale;
	}
	public void setRadicale(String radicale) {
		Radicale = radicale;
	}
	public double getFonctionValeur() {
		return FonctionValeur;
	}
	public void setFonctionValeur(double fonctionValeur) {
		FonctionValeur = fonctionValeur;
	}
	public String getCombinaisonCritere() {
		return CombinaisonCritere;
	}
	public void setCombinaisonCritere(String combinaisonCritere) {
		CombinaisonCritere = combinaisonCritere;
	}
	public int getNumPhGlobal() {
		return numPhGlobal;
	}
	public void setNumPhGlobal(int numPhGlobal) {
		this.numPhGlobal = numPhGlobal;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getLemme() {
		return lemme;
	}
	public void setLemme(String lemme) {
		this.lemme = lemme;
	}
	public int getDistance() {
		return distance;
	}
	public void setDistance(int distance) {
		this.distance = distance;
	}
	public float getScorebase() {
		return scorebase;
	}
	public void setScorebase(float scorebase) {
		this.scorebase = scorebase;
	}
	public String getCritVerif() {
		return CritVerif;
	}
	public void setCritVerif(String critVerif) {
		CritVerif = critVerif;
	}
	public String getBestCombinCrit() {
		return bestCombinCrit;
	}
	public void setBestCombinCrit(String bestCombinCrit) {
		this.bestCombinCrit = bestCombinCrit;
	}
	public double getValSimilarity() {
		return ValSimilarity;
	}
	public void setValSimilarity(double valSimilarity) {
		ValSimilarity = valSimilarity;
	}
	public int getRang() {
		return rang;
	}
	public void setRang(int rang) {
		this.rang = rang;
	}
	public String getDecoupRacine() {
		return DecoupRacine;
	}
	public void setDecoupRacine(String decoupRacine) {
		DecoupRacine = decoupRacine;
	}
	public int getVote1() {
		return vote1;
	}
	public void setVote1(int vote1) {
		this.vote1 = vote1;
	}
	public int getVote2() {
		return vote2;
	}
	public void setVote2(int vote2) {
		this.vote2 = vote2;
	}
	public int getVote() {
		return vote;
	}
	public void setVote(int vote) {
		this.vote = vote;
	}
	
	

}
