package Detection_Resolution_Ellipse;

import java.util.ArrayList;
import java.util.List;

import org.jdom2.Element;

public class Ellipse {

	static public Element ellipse = new Element("Ellipse");
	public Ellipse() {
		}
	public static List ExtraireListCandidats(){
		 List ListCand=new ArrayList();
		 if(ellipse.getChildren().size()>0)
			ListCand=ellipse.getChildren("Candidat");
		else
			System.out.println("List cand vide "+ellipse.getAttributeValue("Verbe_gouvernant"));
		 
		return ListCand;
	}
	public static String ExtraireVerbGouv(){
		String val = new String();
		if(ellipse.hasAttributes())
			val = ellipse.getAttributeValue("Verbe_gouvernant");
		else
			val="";
		return val;
	}
	public static String ExtraireDistance(){
		String val = new String();
		val = ellipse.getAttributeValue("distance");
		return val;
	}
	public static String ExtraireTaille(){
		String val = new String();
		val = ellipse.getAttributeValue("taille");
		return val;
	}
	public static String ExtraireMotPrecedouAvant(){
		String val = new String();
		val = ellipse.getAttributeValue("apres");
		if(val==null)
			val=ellipse.getAttributeValue("apresRad");
		if(val==null)
			val=ellipse.getAttributeValue("avant");
		if(val==null)
			val=ellipse.getAttributeValue("avantRad");
		if(val==null)
			val="";
		return val;
	}
	public static String ExtraireType(){
		String val = new String();
		val = ellipse.getAttributeValue("type");
		return val;
	}
	public static String ExtrairePosition(){
		String pos=new String();
		if(ellipse.getAttributeValue("apres")!=null)
			pos="apres";
		if(ellipse.getAttributeValue("avant")!=null)
			pos="avant";
		if(ellipse.getAttributeValue("apresRad")!=null)
			pos="apres";
		if(ellipse.getAttributeValue("avantRad")!=null)
			pos="avant";
		
		return pos;
	}
		  /**
			 * @param args
			 */
			public static void main(String[] args) {
				// TODO Auto-generated method stub

			}

}
