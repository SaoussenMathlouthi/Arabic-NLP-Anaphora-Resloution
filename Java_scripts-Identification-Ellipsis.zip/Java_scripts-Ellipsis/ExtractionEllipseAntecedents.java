package Detection_Resolution_Ellipse;

import java.util.ArrayList;
import java.util.List;

import org.jdom2.Element;

import weka.core.DenseInstance;
import weka.core.Instance;



public class ExtractionEllipseAntecedents {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String NameFile="fichierResultat5.xml";
		String NameFile="texteE6SegEtiqAnaphEllip.xml";
		List<Ellipse_Candidat> List_Ellip_Cand=Extraction(NameFile);
		int nbrCand=0;
		int nbrAmbigue=0;
		for(int i=0;i<List_Ellip_Cand.size();i++){
			System.out.println("verb gouvernant ellipse:"+List_Ellip_Cand.get(i).getInst_Ellipse().getValVerbGouv());
			System.out.print("liste candidat:");
			nbrCand=nbrCand+List_Ellip_Cand.get(i).getListeAnteced().size();
			if(nbrCand>1)
				nbrAmbigue++;
			for(int j=0;j<List_Ellip_Cand.get(i).getListeAnteced().size();j++){				
				System.out.print("cand:"+List_Ellip_Cand.get(i).getListeAnteced().get(j).getValeur()+
						" num mot:"+List_Ellip_Cand.get(i).getListeAnteced().get(j).getNumMot()+
						" num ph:"+List_Ellip_Cand.get(i).getListeAnteced().get(j).getNumPh()+
						" num parag"+List_Ellip_Cand.get(i).getListeAnteced().get(j).getNumParag()+
						" distance"+List_Ellip_Cand.get(i).getListeAnteced().get(j).getDistance()+" ");
			}
			System.out.println("");
			System.out.println("nbr cand:"+List_Ellip_Cand.get(i).getListeAnteced().size());
			
		}
		System.out.println("nbr d'ellipses:"+List_Ellip_Cand.size());
		System.out.println("nbr de candidats totale:"+nbrCand);
		float moyen=(float) nbrCand/List_Ellip_Cand.size();
		System.out.println("nbr de candidats moyens:"+moyen);
		System.out.println("nbr d'ellipse ambigue:"+nbrAmbigue);
	}

	public static List<Ellipse_Candidat> Extraction(String NameFile){
		  int TexteVoyelle=Integer.parseInt(LectureFichierTexte.LectureParametres("Input.txt").get(0));
		  int NbrMotsPrec=Integer.parseInt(LectureFichierTexte.LectureParametres("Input.txt").get(1));
		  int NbrPhrDebParag=Integer.parseInt(LectureFichierTexte.LectureParametres("Input.txt").get(2));
		  //System.out.println("nbr mot precedents ellipse:"+NbrMotsPrec);
		  boolean Texte_Voyelle;
		  if(TexteVoyelle==0)
			  Texte_Voyelle=false;
		  else
			  Texte_Voyelle=true;
		  boolean motsAnnexes=true;	//Considérer les mots annexes comme un seul candidat
		
		  List<Ellipse_Candidat> listes=new ArrayList<Ellipse_Candidat>();
		  
		  Texte txt = new Texte();
		  Phrase ph = new Phrase();
		  Paragraphe parag=new Paragraphe();
		  Mot m = new Mot();
		  Phrase phpreced=new Phrase();
		  Phrase phDebParag = new Phrase();
		  Mot mtpreced=new Mot();
		  Mot mtdeb=new Mot();
		  txt.nomfichier= NameFile;
		  String texte = txt.nomfichier.substring(0,txt.nomfichier.indexOf("."));
		  //System.out.println(texte);
		  List parags=txt.ExtractParagraphe();		  
		  List phs;
		  List mots;		 
		  List ListMotsPreEllipse=new ArrayList<String>();
		  String type_verb=new String();
		  int ident_ellip=0;
		  String pos=new String();
		  int numpos=-1;
		  String Pron=new String();
		  String Trans=new String();
		  String VgVerb=new String();
		  String ValVerb=new String();
		  int ca=0;
		  int nbrMtPrecedTot;
		  String type=new String();
		  int dist;
		  int nbrMotTot;
		  int u;
		  int nbrMotsTotalText=0;	//01/06/2020 calculer la taille du texte en nombre de mots
		  int nbrPhraseTotalText=0;	//05/06/2020 calculer la taille du texte en nombre de phrase
		  for(int pa=0;pa<parags.size();pa++){	//while(pa.hasNext()){	
			  parag=new Paragraphe();
			  parag.paragraphe=(Element)parags.get(pa);
			  phs = parag.ExtrairePhrases();
			  nbrMotTot=0;
			  // //System.out.println("nbr phrases "+phs.size());			  
			  //Iterator i =phs.iterator();
			  for(int i=0;i<phs.size();i++){	//while(i.hasNext()){	
				nbrPhraseTotalText++;
				ph = new Phrase();
			    ph.phrase=(Element)phs.get(i);			   
			    mots = ph.ExtraireMots();
			    //System.out.println("phrase "+ph.TextePhrase());
			    ListMotsPreEllipse=MethodesDivers.ExtraireMotsPredEllipse(ph);
			    Afficher_Liste(ListMotsPreEllipse);
			    //String[] dataWord =ph.TextePhrase().split(" ");			    
			    if(mots.size()==0){//cas particulier d'étiquetage de textes
			    	mots=ph.ExtraireMots2();
			    }
		    	for(int k=0;k<mots.size();k++){	//while(k.hasNext())		    		 
		    		nbrMotTot++;
		    		nbrMotsTotalText++;
		    		m = new Mot();
		    		m.mot=(Element)mots.get(k);
		        	type_verb=MethodesDivers.TypeVerbe(m.ExtraireVGRad());
					if(!MethodesDivers.TypeVerbe(m.ExtraireVGRad()).equals("")){
						//System.out.println("phrase courante:"+ph.TextePhrase()+" indice phrase:"+i);
						//System.out.println("mot courant:"+m.ExtraireValeur()+" indice mot:"+k+" vg courant:"+m.ExtraireVGRad());													
						if(MethodesDivers.AppartientListe(ListMotsPreEllipse,m.ExtraireValeur())){							
							System.out.println("******************nouvelle instance ellipse sujet");
							ident_ellip+=1;
							ca=0;
							ph.phrase=(Element)phs.get(i);
							//System.out.println("phrase courante:"+ph.TextePhrase()+" indice phrase:"+i);							
							pos=MethodesDivers.Position_Ellipse_VerbeGouvernant(ph, m.ExtraireValeur());
							//System.out.println("position verbe gouv:"+pos);
							if(pos.equals("apres"))
								numpos=k+1;
							else if(pos.equals("avant"))
								numpos=k-1;
							InstanceEllipse Ellip=new InstanceEllipse(ident_ellip,texte,pa,i,k,numpos);
							Pron=m.ExtrairePronom();
							Trans=m.ExtraireTransitivite();
							VgVerb=m.ExtraireVGRad();
							ValVerb=m.ExtraireValeur();
							Ellip.setPronVerbeGouv(Pron);
							Ellip.setTransVerbeGouv(Trans);
							Ellip.setVgVerbeGouv(VgVerb);
							Ellip.setValVerbGouv(ValVerb);
							List<Antecedent> lc = new ArrayList<Antecedent>();
							/*Ajout des candidats de la phrase courante*/	        				 
		        			u=k-1;		        			 
		        			//System.out.println("u="+u+" NbrMotsPrec="+NbrMotsPrec+" numpos="+numpos+" k="+k);
		        			int NMP=0;
			        		while(u>=0 && NMP<=NbrMotsPrec){
		        			 	Mot mc=new Mot();
		        			 	mc.mot=(Element)mots.get(u);
		        			 	//System.out.println("mot precedent de phrase courante:"+mc.ExtraireValeur());
		        			 	NMP++;			        			 	
		        			 	type=MethodesDivers.typeCandidat(mc);
		        			 	//System.out.println(type+" "+mc.ExtraireVGRad());
		        			 	if (!type.equals("")&&!MethodesDivers.EstUnePrepositionCirconst(mc.ExtraireRad())){
		        			 		//System.out.println(MethodesDivers.Accord_GNP(Pron,mc.ExtraireGenre(),mc.ExtraireNombre()));
		        			 		if(MethodesDivers.Accord_GNP(Pron,mc.ExtraireGenre(),mc.ExtraireNombre())){
		        			 			ca++;
				        				//System.out.println("ph courante "+mc.ExtraireValeur()+" num:"+mc.ExtraireNum()+" num phrase:"+i);				        				
				        				Antecedent Cand=new Antecedent(ca,mc.ExtraireDecoupRacine(),mc.ExtraireVGRad(),mc.ExtraireNum(),i,pa,
				        						 mc.ExtraireGenre(),mc.ExtraireNombre(),mc.ExtraireRad(),"");
				        				//Cand.setNumPhGlobal(numPhrGlobal);
				        				Cand.setType(type);
				        				Cand.setLemme(mc.ExtraireLem()); //Ajout 14/09/2015
				        				Cand.setDecoupRacine(mc.ExtraireDecoupRacine());
				        				//Cand.setDistance(numpos-Integer.parseInt(mc.ExtraireNum()));
				        				Cand.setDistance(numpos-u);
				        				//System.out.println("Ajout candidat:"+Cand.getValeur()+" dist="+Cand.getDistance());
				        				if(!ExisteCandidat(lc,Cand.getValeur()))
				        					 lc.add(Cand);
		        			 		}		        			 			
		        			 	}
		        			 	u--;
			        		 }
			        		/*Ajout des candidats des phrases pr�c�dentes du paragraphe courante*/
			        		 nbrMtPrecedTot=0;
			        		 int vp=1;
			        		 ////System.out.println("Nbr mots Prec courant:"+NMP);
			        		 while(i-vp>=0 && NMP<=NbrMotsPrec)
			        		 {
		        				 phpreced = new Phrase();
		        				 phpreced.phrase=(Element) phs.get(i-vp);
		        				 ////System.out.println("phr precd "+phpreced.TextePhrase());
		        				 
		        				 List ppreced= phpreced.ExtraireMots();	
		        				 //System.out.println("taille phrase precedente"+ppreced.size());
		        				 //Mot mtpreced=new Mot();
		        				 //int pr=0;
		        				 int pr=ppreced.size()-1;
		        				 while(pr>=0 && NMP<=NbrMotsPrec)
				        		 {
		        					 mtpreced=new Mot();
				        			 mtpreced.mot=(Element)ppreced.get(pr);
				        			 NMP++;
				        			 type=MethodesDivers.typeCandidat(mtpreced);
				        			 //System.out.println(mtpreced.ExtraireValeur());
				        			 if (!type.equals("")&& !MethodesDivers.EstUnePrepositionCirconst(mtpreced.ExtraireRad())){
				        				 //System.out.println("pronom verbe gouv:"+Pron+" mt preced "+mtpreced.ExtraireValeur()+" "+mtpreced.ExtraireGenre()+" "+mtpreced.ExtraireNombre());
				        				 if(MethodesDivers.Accord_GNP(Pron,mtpreced.ExtraireGenre(),mtpreced.ExtraireNombre())){
					        				 ca++;
					        				//System.out.println("ph precedente "+mtpreced.ExtraireValeur());					        				 
					        				 Antecedent Cand=new Antecedent(ca,mtpreced.ExtraireDecoupRacine(),mtpreced.ExtraireVGRad(),mtpreced.ExtraireNum(),
					        						 i-vp,pa,mtpreced.ExtraireGenre(),mtpreced.ExtraireNombre(),mtpreced.ExtraireRad(),"");
					        				 
					        				 Cand.setType(type);
					        				 Cand.setLemme(mtpreced.ExtraireLem());
					        				 Cand.setDecoupRacine((mtpreced.ExtraireDecoupRacine()));
					        				 //Cand.setDistance(numpos+nbrMtPrecedTot+(ppreced.size()-Integer.parseInt(mtpreced.ExtraireNum())));
					        				 Cand.setDistance(numpos+nbrMtPrecedTot+(ppreced.size()-pr));
					        				 //System.out.println("Ajout candidat:"+Cand.getValeur()+" dist="+Cand.getDistance());
					        				 if(!ExisteCandidat(lc,Cand.getValeur()))
					        					 lc.add(Cand);
				        				 }
				        			 }
				        			 pr--;
				        		 }
		        				 nbrMtPrecedTot=nbrMtPrecedTot+ppreced.size();
		        				 vp++;
			        		 }
			        		 /*Ajout des candidats des phrases au debut du paragraphe*/
				        	  //if(numPhrase>npre+nDebParag){
			        		 for(int v=0;v<NbrPhrDebParag;v++)
			        		 {
			        			  if(v<=phs.size()){
			        				 phDebParag = new Phrase();
			        				 phDebParag.phrase=(Element) phs.get(v);
				        			 //System.out.println("phrase au debut "+phDebParag.TextePhrase());
			        				 //List pdeb= phDebParag.ExtraireMots();
			        				 List pdeb= phDebParag.ExtraireMots();	//11/06/2019
			        				 //Mot mtdeb=new Mot();
			        				 int d=0;
			        				 while(d<pdeb.size())
					        		 {
			        					 mtdeb=new Mot();
					        			 mtdeb.mot=(Element)pdeb.get(d);
					        			 type=MethodesDivers.typeCandidat(mtdeb);
					        			 if (!type.equals("")&& !MethodesDivers.EstUnePrepositionCirconst(mtdeb.ExtraireRad())){
					        				 if(MethodesDivers.Accord_GNP(Pron,mtdeb.ExtraireGenre(),mtdeb.ExtraireNombre())){
					        					 //dist=nbrMotTot-Integer.parseInt(mtdeb.ExtraireNum());
					        					 dist=nbrMotTot-d;
					        					 if(dist>NbrMotsPrec){
					        						 //System.out.println("phrase au debut distance au deb="+dist);
							        				 ca++;								        				 
							        				 Antecedent Cand=new Antecedent(ca,mtdeb.ExtraireDecoupRacine(),mtdeb.ExtraireVGRad(),mtdeb.ExtraireNum(),
							        						 v,pa,mtdeb.ExtraireGenre(),mtdeb.ExtraireNombre(),
							        						 mtdeb.ExtraireRad(),"");
							        				 //Cand.setNumPhGlobal(num1erePhr+v);
							        				 Cand.setType(type);
							        				 Cand.setLemme(mtdeb.ExtraireLem());
							        				 Cand.setDistance(dist);
							        				 //System.out.println("Ajout candidat:"+Cand.getValeur()+" dist="+Cand.getDistance());
							        				 if(!ExisteCandidat(lc,Cand.getValeur()))
							        					 lc.add(Cand);
					        					 }
					        				 }
					        			 }
					        			 d++;
					        		 }
			        			  }
			        		 }
			        		 Ellipse_Candidat ac=new Ellipse_Candidat(Ellip,lc,null);
			        		 listes.add(ac);
			        		//System.out.println("************************extraction candidat terminee");
						}
					}
		    	}
			  }
		  }
		  System.out.println("le nombre de mots total dans le texte:"+nbrMotsTotalText);
		  System.out.println("le nombre de phrase total dans le texte:"+nbrPhraseTotalText);
		  return listes;
	}
	
	public static boolean ExisteCandidat(List<Antecedent> LC,String Candidat){
		boolean existe=false;
		int i=0;
		while(i<LC.size() && !existe){
			Antecedent Cand=LC.get(i);
			if(Cand.getValeur().equals(Candidat))
				existe=true;
			i++;
		}
		return existe;
	}
	public static void Afficher_Liste(List<String> ListMots){
		////System.out.println("Taille de la liste:"+ListMots.size());
		//System.out.println("Affichage");
		for(int a=0;a<ListMots.size();a++){
			//System.out.println(ListMots.get(a)+" ");
		}
	}
}
