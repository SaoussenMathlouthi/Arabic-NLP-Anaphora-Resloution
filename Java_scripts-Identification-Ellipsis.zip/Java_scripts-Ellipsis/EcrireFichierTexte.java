package Detection_Resolution_Ellipse;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

public class EcrireFichierTexte {
	public static void main(String[] args){
		String data="Precision0"+"\n";
		try {
			CreateWriteTxtFile("resulttest.txt",data);
			WriteToTxtFile("resulttest.txt",data);
			WriteToTxtFile("resulttest.txt",data);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	
	public static void WriteToTxtFile(String NameFile,String Data){
		File file = new File(NameFile);
	    FileWriter writer;
	    try {
	        writer = new FileWriter(file, true);
	        //PrintWriter printer = new PrintWriter(writer);
	        //printer.append(Data);
	        BufferedWriter bw = new BufferedWriter(writer);
	        bw.write(Data);
	        bw.newLine();
	        bw.close();
	        writer.close();
	    } catch (IOException e) {
	        // TODO Auto-generated catch block
	        e.printStackTrace();
	    }
     }
	public static void CreateWriteTxtFile(String NameFile,String Data) throws FileNotFoundException, UnsupportedEncodingException{
		PrintWriter writer = new PrintWriter(NameFile, "UTF-8");
		writer.println(Data);
		
		writer.close();
	}
	public static void CreateTxtFile(String NameFile) throws FileNotFoundException, UnsupportedEncodingException{
		PrintWriter writer = new PrintWriter(NameFile, "UTF-8");
		
	}
}
