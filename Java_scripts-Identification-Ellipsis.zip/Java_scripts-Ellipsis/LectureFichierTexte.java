package Detection_Resolution_Ellipse;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class LectureFichierTexte {
	public static void main(String[] args) throws IOException{
		List<String> chaines=new ArrayList<String>();
		//String fileName="AdjDefini.txt";
		//chaines=LectureChaines(fileName);
		String fileName="Connecteur.txt";
		 List<List<String>> Data=ReadFile(fileName);
		 //String[][] Params=ReadFile2(Data);
		 //System.out.println("Affichage");
		 //System.out.println(Data.size()+" "+Data.get(0).size());
		    /*for(int i=0; i<Data.size(); i++){
				for(int j=0;j<Data.get(i).size();j++){
					System.out.print(Data.get(i).get(j)+" ");
				}
				System.out.println();
			}*/
		 //System.out.println("Affichage des premi�res param�tres:");
		 //System.out.println(Data.size()+" "+Data.get(0).size());
		    /*for(int p=0; p<Parametre(Data,0).size(); p++){
					System.out.print(Parametre(Data,0).get(p)+" ");
				System.out.println();
			}*/
    }
	
	public static List<List<String>> ReadFile(String fileName){
	BufferedReader input = null;
	List<List<String>> txtData = new ArrayList<List<String>>();
	try 
	{
		input = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), "UTF-16"));
	    //input =  new BufferedReader(new FileReader(fileName));
	    String line = null;
	    while (( line = input.readLine()) != null)
	    {
	    	//System.out.println(line);
	    	line=line.substring(line.indexOf(":")+1,line.length());
	    	//System.out.println(line);
	        String[] data = line.split(",");
	        //System.out.println(data.length);
	        //System.out.printf(line);
	        txtData.add(Arrays.asList(data));
	    }
	   
	}
	
	catch (Exception ex)
	{
	      ex.printStackTrace();
	}
	finally 
	{
	    if(input != null)
	    {
	        try {
				input.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	}
	return txtData;
	}
	public static List<String> ReadParam(String fileName){
		BufferedReader input = null;
		List<String> txtData = new ArrayList<String>();
		try 
		{
			input = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), "UTF-16"));
		    //input =  new BufferedReader(new FileReader(fileName));
		    String line = null;
		    while (( line = input.readLine()) != null)
		    {
		    	System.out.println(line);
		    	line=line.substring(line.indexOf(":")+1,line.length());
		        txtData.add(line);
		    }
		   
		}
		
		catch (Exception ex)
		{
		      ex.printStackTrace();
		}
		finally 
		{
		    if(input != null)
		    {
		        try {
					input.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    }
		}
		return txtData;
		}
	public static List<String> LectureParametres(String fileName){
	       System.out.println("Reading File from Java code");
	       //Name of the file
	       List<String> Constantes=new ArrayList<String>();
	       //String fileName="Input.txt";
	       try{

	          //Create object of FileReader
	          FileReader inputFile = new FileReader(fileName);

	          //Instantiate the BufferedReader Class
	          BufferedReader bufferReader = new BufferedReader(inputFile);

	          //Variable to hold the one line data
	          String line;

	          // Read file line by line and print on the console
	          
	          while ((line = bufferReader.readLine()) != null)   {
	            String val=line.substring(line.indexOf(":")+1);
	            Constantes.add(val);
	          }
	          //Close the buffer reader
	          bufferReader.close();
	       }catch(Exception e){
	          System.out.println("Error while reading file line by line:" + e.getMessage());                      
	       }
	       return Constantes;
	     }
		public static List<String> LectureParametres1(String fileName){
		       System.out.println("Reading File from Java code");
		       //Name of the file
		       List<String> Constantes=new ArrayList<String>();
		       //String fileName="Parametres.txt";
		       try{

		          //Create object of FileReader
		          FileReader inputFile = new FileReader(fileName);

		          //Instantiate the BufferedReader Class
		          BufferedReader bufferReader = new BufferedReader(inputFile);

		          //Variable to hold the one line data
		          String line;

		          // Read file line by line and print on the console
		          
		          while ((line = bufferReader.readLine()) != null)   {
		            String val=line.substring(line.indexOf(":")+1);
		            Constantes.add(val);
		          }
		          //Close the buffer reader
		          bufferReader.close();
		       }catch(Exception e){
		          System.out.println("Error while reading file line by line:" + e.getMessage());                      
		       }
		       return Constantes;
		     }
		public static List<String> ReadText(String fileName){
		       System.out.println("Reading File from Java code");
		       //Name of the file
		       List<String> data=new ArrayList<String>();
		       //String fileName="Constantes.txt";
		       try{

		          //Create object of FileReader
		          FileReader inputFile = new FileReader(fileName);

		          //Instantiate the BufferedReader Class
		          BufferedReader bufferReader = new BufferedReader(inputFile);

		          //Variable to hold the one line data
		          String line;

		          // Read file line by line and print on the console
		          
		          while ((line = bufferReader.readLine()) != null)   {
		            data.add(line);
		          }
		          //Close the buffer reader
		          bufferReader.close();
		       }catch(Exception e){
		          System.out.println("Error while reading file line by line:" + e.getMessage());                      
		       }
		       return data;
		     }
	
}
