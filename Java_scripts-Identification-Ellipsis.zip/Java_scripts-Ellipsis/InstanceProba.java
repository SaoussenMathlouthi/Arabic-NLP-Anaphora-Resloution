package Detection_Resolution_Ellipse;

import java.util.*;

public class InstanceProba {
	
	int NumInstance;
	double ProbaDistrib0;
	double ProbaDistrib1;
	boolean InstChoisie;
	String Classe;
	double Cosinus;
	double Dist1;
	double Dist2;
	double ProbaDistrib;
	double PredictClass;
	
	
	public InstanceProba(int NumInst, double Proba0, double Proba1, boolean Choisie, String ClassChoisie,double cos, 
			double dist1, double dist2, double probadistrib, double predictclass){
		NumInstance=NumInst;
		ProbaDistrib0=Proba0;
		ProbaDistrib1=Proba1;
		InstChoisie=Choisie;
		Classe=ClassChoisie;
		Cosinus=cos;
		Dist1=dist1;
		Dist2=dist2;
		ProbaDistrib=probadistrib;
		PredictClass=predictclass;
		}


	public int getNumInstance() {
		return NumInstance;
	}


	public void setNumInstance(int numInstance) {
		NumInstance = numInstance;
	}


	public double getProbaDistrib0() {
		return ProbaDistrib0;
	}


	public void setProbaDistrib0(double probaDistrib0) {
		ProbaDistrib0 = probaDistrib0;
	}


	public double getProbaDistrib1() {
		return ProbaDistrib1;
	}


	public void setProbaDistrib1(double probaDistrib1) {
		ProbaDistrib1 = probaDistrib1;
	}


	public boolean isInstChoisie() {
		return InstChoisie;
	}


	public void setInstChoisie(boolean instChoisie) {
		InstChoisie = instChoisie;
	}


	public String getClasse() {
		return Classe;
	}


	public void setClasse(String class1) {
		Classe = class1;
	}


	public double getCosinus() {
		return Cosinus;
	}


	public void setCosinus(double cosinus) {
		Cosinus = cosinus;
	}


	public double getDist1() {
		return Dist1;
	}


	public void setDist1(double dist1) {
		Dist1 = dist1;
	}


	public double getDist2() {
		return Dist2;
	}


	public void setDist2(double dist2) {
		Dist2 = dist2;
	}


	public double getProbaDistrib() {
		return ProbaDistrib;
	}


	public void setProbaDistrib(double probaDistrib) {
		ProbaDistrib = probaDistrib;
	}


	public double getPredictClass() {
		return PredictClass;
	}


	public void setPredictClass(double predictClass) {
		PredictClass = predictClass;
	}


	
	
	
}
