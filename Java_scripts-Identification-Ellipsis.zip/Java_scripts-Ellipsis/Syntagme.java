package Detection_Resolution_Ellipse;
import java.util.*;

import org.jdom2.Element;

/**
 * <p>Titre : </p>
 * <p>Description : </p>
 * <p>Copyright : Copyright (c) 2010</p>
 * <p>Soci�t� : </p>
 * @author non attribuable
 * @version 1.0
 */

public class Syntagme {
  static Element syntagme;

  public Syntagme() {
  }

public static String ExtraireType(){
  String typ_syn= new String();
  typ_syn = syntagme.getName();
  return typ_syn;
}

public static List ExtraireMots(){
  List mots = new ArrayList();
  mots = syntagme.getChildren("Mot");
  return mots;

}

public static List ExtraireSousSyntagme(){
	List ssyntags=new ArrayList();
	ssyntags=syntagme.getChildren();
	return ssyntags;
}

public static void main(String[] args) {
	  
	  Texte txt = new Texte();
	  String texte1 = txt.nomfichier.substring(0,txt.nomfichier.indexOf("."));
	  System.out.println(texte1);
	  List phs = txt.ExtractPhrase();
	  for(int y=0;y<phs.size();y++){
		  Phrase phr=new Phrase();
		  phr.phrase=(Element) phs.get(y);
		  List syntags=phr.ExtraireSyntagmes();
		  for(int x=0;x<syntags.size();x++){
			  Syntagme syn=new Syntagme();
			  syn.syntagme=(Element) syntags.get(x);
			  List ssyntags=syn.ExtraireSousSyntagme();
			  for(int z=0;z<ssyntags.size();z++){
				  Syntagme ssyn=new Syntagme();
				  ssyn.syntagme=(Element) ssyntags.get(z);
				  List mots=ssyn.ExtraireMots();
				  for(int v=0;v<mots.size();v++){
					  Mot mt=new Mot();
					  mt.mot=(Element) mots.get(v);
					  System.out.println(mt.ExtraireLem()+" phrase num "+y);
				  }
			  }
		  }
	  }
}
	}



