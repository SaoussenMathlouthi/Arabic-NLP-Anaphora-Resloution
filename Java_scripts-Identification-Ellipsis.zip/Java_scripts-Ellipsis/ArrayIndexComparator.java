package Detection_Resolution_Ellipse;

import java.util.Comparator;

public class ArrayIndexComparator implements Comparator<Integer>{

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}
	
    private final float[] array;

    public ArrayIndexComparator(float[] array)
    {
        this.array = array;
    }

    public Integer[] createIndexArray()
    {
        Integer[] indexes = new Integer[array.length];
        for (int i = 0; i < array.length; i++)
        {
            indexes[i] = i; // Autoboxing
        }
        return indexes;
    }

    @Override
    public int compare(Integer index1, Integer index2)
    {
         // Autounbox from Integer to int to use as array indexes
    	System.out.println(index1+" "+index2);
    	if (Float.valueOf(array[index1])> Float.valueOf(array[index2])) {//sorted in descending
            return -1;
        } else if (Float.valueOf(array[index1])< Float.valueOf(array[index2])) {
            return 1;
        }    
         return 0;
        //return Float.valueOf(array[index1]).compareTo(Float.valueOf(array[index2]));
    }
	
}
